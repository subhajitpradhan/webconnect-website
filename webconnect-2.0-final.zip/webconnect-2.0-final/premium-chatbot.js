(() => {
  "use strict";

  // This script is loaded dynamically (sometimes from nested folders like
  // /states/ or /creator/), so asset paths must resolve relative to this
  // script's own URL, not relative to the page that loaded it.
  const CHATBOT_ROOT = (() => {
    const src = document.currentScript?.getAttribute("src") || "";
    return src.includes("../") ? "../" : "";
  })();

  const STORE = {
    chats: "wc_ai_chats_v1",
    active: "wc_ai_active_chat_v1",
    settings: "wc_ai_settings_v1",
    notes: "wc_ai_notes_v1",
    todos: "wc_ai_todos_v1",
    searches: "wc_ai_searches_v1",
    prompts: "wc_ai_recent_prompts_v1"
  };

  const defaultSettings = {
    mode: "productivity",
    answerStyle: "balanced",
    theme: "light",
    accent: "#0f9f79",
    voice: "",
    rate: 1,
    autoRead: false,
    folder: "General"
  };

  const assistantModes = {
    productivity: "Organize the answer into next actions and useful shortcuts.",
    study: "Teach clearly, add examples, and include follow-up questions.",
    coding: "Prioritize code, docs, debugging steps, and developer resources.",
    research: "Summarize findings, compare options, and suggest searches.",
    writing: "Improve clarity, tone, structure, and ready-to-use wording.",
    career: "Focus on jobs, resumes, interviews, and portfolio moves.",
    beginner: "Explain like a beginner with simple steps.",
    expert: "Give a detailed expert-level answer.",
    short: "Keep the answer short and direct."
  };

  const promptTemplates = [
    "Make a 7-day study plan for",
    "Find the best websites for",
    "Summarize this file and extract key points",
    "Explain this like I am a beginner",
    "Create a resume bullet for",
    "Brainstorm 10 ideas for",
    "Translate this to English:",
    "Format this answer as a table:"
  ];

  const legacyQuickMsg = window.quickMsg;

  let state = {
    chats: [],
    activeId: "",
    settings: { ...defaultSettings },
    streaming: false,
    lastBotForRegen: null,
    selectedFiles: [],
    idleTimer: null
  };

  const sessionMemory = {
    topics: [],
    preferences: {},
    lastIntent: "general",
    project: "",
    unanswered: []
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  function read(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key)) ?? fallback;
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function uid(prefix = "id") {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  }

  function text(value) {
    return String(value || "").replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    }[char]));
  }

  function plain(html) {
    const tmp = document.createElement("div");
    tmp.innerHTML = html || "";
    return tmp.textContent || tmp.innerText || "";
  }

  function slugify(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/&/g, " and ")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
  }

  function titleFromUrl(url) {
    return String(url || "")
      .split("/").pop()
      .replace(/\.html?$/i, "")
      .replace(/-/g, " ")
      .replace(/\b\w/g, char => char.toUpperCase()) || "Page";
  }

  function nowTime() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function activeChat() {
    let chat = state.chats.find(item => item.id === state.activeId);
    if (!chat) {
      chat = createChat("New Assistant Chat", false);
    }
    if (!Array.isArray(chat.messages)) chat.messages = [];
    return chat;
  }

  function saveState() {
    write(STORE.chats, state.chats);
    write(STORE.active, state.activeId);
    write(STORE.settings, state.settings);
  }

  function createChat(title = "New Assistant Chat", shouldRender = true) {
    const chat = {
      id: uid("chat"),
      title,
      folder: state.settings.folder || "General",
      pinned: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      summary: "",
      messages: []
    };
    state.chats.unshift(chat);
    state.activeId = chat.id;
    saveState();
    if (shouldRender) renderAll();
    return chat;
  }

  function ensureState() {
    state.settings = { ...defaultSettings, ...read(STORE.settings, {}) };
    state.chats = read(STORE.chats, []).filter(chat => chat && typeof chat === "object");
    state.chats.forEach(chat => {
      chat.id ||= uid("chat");
      chat.title ||= "Assistant Chat";
      chat.folder ||= state.settings.folder || "General";
      chat.createdAt ||= Date.now();
      chat.updatedAt ||= Date.now();
      chat.summary ||= "";
      chat.messages = Array.isArray(chat.messages) ? chat.messages.filter(Boolean) : [];
      chat.messages = chat.messages.filter(message => {
        const body = `${message.html || ""} ${message.raw || ""}`;
        return !/target=&quot;_blank|rel=&quot;noopener|127\.0\.0\.1:5500\/%3Ca|<a href="<a href=/i.test(body);
      });
      if (/target=&quot;_blank|rel=&quot;noopener|127\.0\.0\.1:5500\/%3Ca|<a href="<a href=/i.test(chat.summary || "")) {
        chat.summary = "";
      }
    });
    state.activeId = read(STORE.active, "");
    if (!state.chats.length) {
      createChat("Welcome to WebConnect AI", false);
      activeChat().messages.push({
        id: uid("msg"),
        role: "bot",
        html: welcomeMessage(),
        raw: plain(welcomeMessage()),
        at: Date.now(),
        favorite: false
      });
    }
    if (!state.chats.some(chat => chat.id === state.activeId)) {
      state.activeId = state.chats[0]?.id || "";
    }
    saveState();
  }

  function welcomeMessage() {
    return `
      <b>Hi, I am WebConnect AI.</b><br>
      I can help you search categories, plan study or career work, summarize files, manage notes and tasks, translate text, format answers, and open useful resources fast.
      <div class="bot-actions">
        <button class="bot-action" type="button" onclick="runChatPrompt('best AI tools for productivity')">AI tools</button>
        <button class="bot-action" type="button" onclick="runChatPrompt('make a job preparation plan')">Career plan</button>
        <button class="bot-action" type="button" onclick="runChatPrompt('summarize my current goal')">Summarize</button>
      </div>
    `;
  }

  function buildShell() {
    const chat = $("#chat-container");
    if (!chat || chat.dataset.premiumReady === "true") return;
    chat.dataset.premiumReady = "true";
    chat.innerHTML = `
      <div id="chat-header">
        <div class="header-left">
          <div class="avatar"><img src="${CHATBOT_ROOT}logo.svg" alt="WebConnect"><span class="status-dot"></span></div>
          <div class="text">
            <div class="chat-title">WebConnect AI</div>
            <div class="chat-subtitle" id="chatStatus">Website guide and smart assistant</div>
          </div>
        </div>
        <select id="chatLanguage" class="chat-language" onchange="setChatLanguage(this.value)" aria-label="Chat language">
          <option value="hinglish">Hinglish</option><option value="en">English</option><option value="hi">Hindi</option>
          <option value="bn">Bengali</option><option value="or">Odia</option><option value="ta">Tamil</option>
          <option value="te">Telugu</option><option value="mr">Marathi</option><option value="gu">Gujarati</option>
          <option value="es">Spanish</option><option value="fr">French</option><option value="de">German</option>
        </select>
        <button id="chatMoreBtn" class="chat-icon-btn" type="button" title="Assistant tools"><i class="fas fa-sliders"></i></button>
        <button id="closeChat" class="chat-icon-btn" type="button" title="Close"><i class="fas fa-xmark"></i></button>
      </div>

      <div class="chat-topbar">
        <button type="button" data-panel="history"><i class="fas fa-clock-rotate-left"></i><span>History</span></button>
        <button type="button" data-panel="notes"><i class="fas fa-note-sticky"></i><span>Notes</span></button>
        <button type="button" data-panel="tasks"><i class="fas fa-list-check"></i><span>Tasks</span></button>
        <button type="button" data-panel="settings"><i class="fas fa-gear"></i><span>Settings</span></button>
      </div>

      <div id="chatWorkspace" class="chat-workspace">
        <aside id="chatSidePanel" class="chat-side-panel" aria-hidden="true"></aside>
        <main class="chat-main-panel">
          <div class="quick-title">Smart prompts</div>
          <div class="slider-container"><div class="slider-track" id="sliderTrack"></div></div>
          <div id="chatDropZone" class="chat-drop-zone">Drop PDF, DOCX, TXT or images here for quick analysis</div>
          <div id="chat-messages"></div>
          <div id="chatFollowups" class="chat-followups"></div>
        </main>
      </div>

      <div class="chat-composer-tools">
        <select id="assistantMode" aria-label="Assistant mode">
          <option value="productivity">Productivity</option><option value="study">Study</option><option value="coding">Coding</option>
          <option value="research">Research</option><option value="writing">Writing</option><option value="career">Career</option>
        </select>
        <select id="answerStyle" aria-label="Answer style">
          <option value="balanced">Balanced</option><option value="short">Short</option><option value="beginner">Beginner</option><option value="expert">Expert</option>
        </select>
        <button type="button" data-quick-action="summarize">Summary</button>
        <button type="button" data-quick-action="translate">Translate</button>
        <button type="button" data-quick-action="research">Research</button>
      </div>

      <div id="chat-input-area">
        <button id="chatAttachBtn" type="button" title="Attach file"><i class="fas fa-paperclip"></i></button>
        <textarea id="userInput" rows="1" maxlength="2000" placeholder="Ask anything..."></textarea>
        <button id="mic-btn" type="button" title="Voice input"><i class="fas fa-microphone"></i></button>
        <button id="chatSendBtn" type="button" title="Send"><i class="fas fa-paper-plane"></i></button>
        <input id="chatFileInput" type="file" multiple accept=".pdf,.doc,.docx,.txt,.md,image/*" hidden>
      </div>
      <div class="chat-input-meta"><span id="chatFilePreview"></span><span id="charCounter">0 / 2000</span></div>
      <div id="suggestions-box"></div>
    `;
  }

  function renderAll() {
    renderMessages();
    renderPrompts();
    renderFollowups();
    renderPanel($(".chat-side-panel.is-open")?.dataset.panel || "");
    applySettings();
  }

  function formatMessageContent(message) {
    let html = message.html || text(message.raw || "");
    const hasHtml = /<\/?[a-z][\s\S]*>/i.test(html);
    html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, (_, lang, code) => codeBlock(code.trim(), lang || "text"));
    html = html.replace(/(?:^|\n)- ([^\n]+)/g, "<br>• $1");
    html = html.replace(/(?:^|\n)(\d+)\. ([^\n]+)/g, "<br>$1. $2");
    if (!hasHtml) {
      html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
    }
    if (/^\s*\|.+\|\s*$/m.test(html)) html = `<div class="chat-table-wrap">${html}</div>`;
    return html;
  }

  function renderMessages() {
    const box = $("#chat-messages");
    if (!box) return;
    const chat = activeChat();
    box.innerHTML = chat.messages.map(message => `
      <div class="chat-msg ${message.role === "user" ? "user-msg" : "bot-msg"}" data-message-id="${message.id}">
        <div class="msg-text">${formatMessageContent(message)}</div>
        <div class="msg-toolbar">
          <span class="msg-time">${new Date(message.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          <button type="button" data-msg-action="copy" title="Copy"><i class="fas fa-copy"></i></button>
          ${message.role === "user" ? '<button type="button" data-msg-action="edit" title="Edit and resend"><i class="fas fa-pen"></i></button>' : '<button type="button" data-msg-action="speak" title="Read aloud"><i class="fas fa-volume-high"></i></button><button type="button" data-msg-action="regen" title="Regenerate"><i class="fas fa-rotate-right"></i></button>'}
          <button type="button" data-msg-action="favorite" title="Favorite"><i class="${message.favorite ? "fas" : "far"} fa-bookmark"></i></button>
          <button type="button" data-msg-action="delete" title="Delete"><i class="fas fa-trash"></i></button>
        </div>
      </div>
    `).join("");
    box.scrollTop = box.scrollHeight;
  }

  function renderPrompts() {
    const strip = $("#sliderTrack");
    const suggestions = $("#suggestions-box");
    const lastUser = [...activeChat().messages].reverse().find(message => message.role === "user");
    const intent = sessionMemory.lastIntent || inferIntent(lastUser?.raw || "");
    const promptMap = {
      coding: [
        ["Debug", "debug my code step by step"],
        ["HTML/CSS", "best HTML CSS resources"],
        ["JavaScript", "explain JavaScript simply"],
        ["Developer", "open developer"]
      ],
      study: [
        ["Study Plan", "make a 7-day study plan"],
        ["Notes", "make revision notes"],
        ["Courses", "open online courses"],
        ["Universities", "open universities"]
      ],
      career: [
        ["Jobs", "open jobs"],
        ["Resume", "open resume builder"],
        ["Interview", "open interview prep"],
        ["Remote", "open remote jobs"]
      ],
      website: [
        ["Creator", "open creator"],
        ["All Pages", "open all"],
        ["Contact", "open contact"],
        ["Govt", "open govt"]
      ],
      research: [
        ["Summary", "summarize this topic"],
        ["Compare", "compare options"],
        ["Sources", "search reliable sources"],
        ["News", "open news"]
      ],
      writing: [
        ["Improve", "improve this writing:"],
        ["Email", "write a professional email"],
        ["Resume", "create a resume bullet"],
        ["Translate", "translate this to English:"]
      ],
      productivity: [
        ["AI Tools", "best AI tools for work"],
        ["Jobs", "open jobs"],
        ["Study", "make a study roadmap"],
        ["Creator", "open creator"],
        ["Govt", "open government services"]
      ]
    };
    const prompts = (promptMap[intent] || promptMap.productivity).map(([label, prompt]) => ({ label, prompt }));
    if (strip) {
      strip.innerHTML = prompts.map(item => `<button type="button" data-prompt="${text(item.prompt)}">${text(item.label)}</button>`).join("");
    }
    if (suggestions) {
      suggestions.innerHTML = "";
    }
  }

  function renderFollowups() {
    const box = $("#chatFollowups");
    if (!box) return;
    const lastUser = [...activeChat().messages].reverse().find(message => message.role === "user");
    const intent = sessionMemory.lastIntent || inferIntent(lastUser?.raw || "");
    const map = {
      coding: ["Debug this step by step", "Explain the code simply", "Optimize this solution"],
      study: ["Make revision notes", "Quiz me on this", "Give exam key points"],
      research: ["Create a comparison table", "Summarize with sources", "Give a conclusion"],
      writing: ["Make it professional", "Shorten this draft", "Create a final version"],
      career: ["Create resume bullets", "Practice interview Q&A", "Find job resources"],
      website: ["Open related category", "Suggest useful websites", "Search the web"],
      quick: ["Explain deeper", "Give an example", "Show next steps"],
      productivity: ["Turn into tasks", "Save as note", "Make a plan"]
    };
    const items = (map[intent] || map.productivity).slice(0, 3);
    box.innerHTML = items.map(item => `<button type="button" data-prompt="${text(item)}">${text(item)}</button>`).join("");
  }

  function addMessage(roleName, html, options = {}) {
    const chat = activeChat();
    const role = roleName === "You" || roleName === "user" ? "user" : "bot";
    const message = {
      id: options.id || uid("msg"),
      role,
      html,
      raw: options.raw || plain(html),
      at: options.at || Date.now(),
      favorite: false,
      sourcePrompt: options.sourcePrompt || ""
    };
    chat.messages.push(message);
    chat.updatedAt = Date.now();
    if (role === "user" && chat.title.startsWith("New")) chat.title = message.raw.slice(0, 42) || "Assistant Chat";
    saveState();
    renderMessages();
    renderFollowups();
    return message;
  }

  function showTyping(prompt = "") {
    const box = $("#chat-messages");
    if (!box || $("#typing")) return;
    const div = document.createElement("div");
    div.id = "typing";
    div.className = "chat-msg bot-msg typing-msg";
    div.innerHTML = `
      <div class="thinking-copy"><strong>WebConnect AI is thinking</strong><small>${text(getThinkingLabelSafe(prompt))}</small></div>
      <div class="thinking-dots"><i></i><i></i><i></i></div>
    `;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }

  function removeTyping() {
    $("#typing")?.remove();
  }

  function getThinkingLabelSafe(prompt) {
    if (typeof window.getThinkingLabel === "function") return window.getThinkingLabel(prompt);
    return "Preparing a helpful answer";
  }

  function inferIntent(prompt) {
    const clean = String(prompt || "").toLowerCase();
    const tests = [
      ["coding", /\b(code|coding|javascript|html|css|python|java|bug|error|debug|function|api|syntax|react|node|sql|program)\b/],
      ["study", /\b(study|exam|notes|revision|learn|explain|student|syllabus|question|answer|memory trick|example)\b/],
      ["research", /\b(research|compare|comparison|sources|web search|find information|summary|conclusion|report|analysis)\b/],
      ["writing", /\b(email|application|resume|cover letter|blog|caption|post|letter|rewrite|grammar|professional|report)\b/],
      ["career", /\b(job|career|internship|interview|linkedin|portfolio|salary|remote|freelance|hiring)\b/],
      ["website", /\b(open|website|category|webconnect|tools|resources|link|portal|site)\b/],
      ["quick", /\b(short|quick|brief|one line|direct answer|tl;dr)\b/]
    ];
    const found = tests.find(([, pattern]) => pattern.test(clean));
    if (found) return found[0];
    if (clean.endsWith("?") && clean.split(/\s+/).length < 10) return "quick";
    return state.settings.mode || "productivity";
  }

  function updateSessionMemory(prompt, intent) {
    const words = String(prompt || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .split(/\s+/)
      .filter(word => word.length > 3 && !["this", "that", "with", "from", "what", "help", "please"].includes(word));
    sessionMemory.topics = [...new Set([...words.slice(0, 5), ...sessionMemory.topics])].slice(0, 10);
    sessionMemory.lastIntent = intent;
    const projectMatch = String(prompt).match(/(?:project|website|app)\s+(?:is|called|named)?\s*([a-z0-9 -]{3,40})/i);
    if (projectMatch) sessionMemory.project = projectMatch[1].trim();
    if (/\b(short|brief|simple)\b/i.test(prompt)) sessionMemory.preferences.detail = "short";
    if (/\b(detailed|expert|advanced)\b/i.test(prompt)) sessionMemory.preferences.detail = "expert";
  }

  function memoryContext() {
    const parts = [];
    if (sessionMemory.project) parts.push(`Project: ${sessionMemory.project}`);
    if (sessionMemory.topics.length) parts.push(`Recent topics: ${sessionMemory.topics.slice(0, 4).join(", ")}`);
    if (sessionMemory.preferences.detail) parts.push(`Preferred detail: ${sessionMemory.preferences.detail}`);
    return parts.length ? `<small class="smart-memory"><b>Memory:</b> ${text(parts.join(" · "))}</small><br>` : "";
  }

  function needsClarification(prompt, intent) {
    const clean = String(prompt || "").trim();
    if (/^(hi|hii|hiii|hello|hey|hy|namaste|namaskar|helo|hola)$/i.test(clean)) return "";
    if (clean.length < 4) return "Can you add a little more detail so I can answer properly?";
    if (/^(help|do this|fix this|make it better)$/i.test(clean)) return "What exactly should I improve, and what result do you want?";
    if (intent === "coding" && /\b(error|bug|fix)\b/i.test(clean) && !/```|line|console|screenshot|message/i.test(clean)) {
      return "Please paste the error message or code snippet so I can debug it accurately.";
    }
    if (intent === "writing" && /\b(resume|cover letter|application)\b/i.test(clean) && !/\b(role|company|job|college|position)\b/i.test(clean)) {
      return "Tell me the role, company, or purpose and I will tailor it professionally.";
    }
    return "";
  }

  function list(items) {
    return `<ul class="smart-answer-list">${items.map(item => `<li>${item}</li>`).join("")}</ul>`;
  }

  function section(title, body) {
    return `<span class="smart-section-title">${title}</span>${body}`;
  }

  function codeBlock(code, lang = "text") {
    return `<pre class="smart-code-block"><code data-lang="${text(lang)}">${text(code)}</code></pre>`;
  }

  let siteDatabaseCache = null;

  function siteDatabase() {
    if (siteDatabaseCache) return siteDatabaseCache;
    const known = [
      ["Home", "index.html"], ["Features", "features.html"], ["About", "about.html"], ["Contact", "contact.html"],
      ["Creator", "creator/creator.html"], ["Creator Journey", "creator/journey.html"], ["Creator Projects", "creator/projects.html"], ["Feedback", "creator/feedback.html"],
      ["All Categories", "all.html"], ["More Categories", "more.html"], ["Popular", "popular.html"],
      ["AI Tools", "ai.html"], ["Jobs", "jobs.html"], ["Remote Jobs", "remote-jobs.html"], ["Internships", "internships.html"], ["Freelancing", "freelancing.html"], ["Resume Builder", "resume-builder.html"], ["Interview Prep", "interview-prep.html"], ["Career Guidance", "career-guidance.html"],
      ["Education", "education.html"], ["Universities", "universities.html"], ["Online Courses", "online-courses.html"], ["Tutorials", "tutorials.html"], ["Scholarships", "scholarships.html"], ["Exams", "exams.html"], ["Results", "results.html"], ["Question Papers", "question-papers.html"],
      ["Developer", "developer.html"], ["Coding", "coding.html"], ["Algorithms", "algorithms.html"], ["Data Structures", "data-structures.html"], ["Competitive Programming", "competitive-programming.html"], ["APIs", "apis.html"], ["Cloud", "cloud.html"], ["DevOps", "devops.html"], ["Testing", "testing.html"], ["Open Source", "opensource.html"], ["System Design", "system-design.html"],
      ["Design", "design.html"], ["UI UX", "ui-ux.html"], ["Photo Editing", "photo-editing.html"], ["Video Editing", "video-editing.html"], ["Animation", "animation.html"], ["3D Design", "3d-design.html"], ["Templates", "templates.html"],
      ["Government", "govt.html"], ["Government Schemes", "government-schemes.html"], ["Government Portals", "government-portals.html"], ["Public Utilities", "public-utilities.html"], ["Legal Help", "legal-help.html"], ["Police Services", "police-services.html"],
      ["Finance", "finance.html"], ["Banking", "banking.html"], ["Insurance", "insurance.html"], ["Stock Market", "stock-market.html"], ["Crypto", "crypto.html"], ["Business", "business.html"], ["Startups", "startups.html"],
      ["Shopping", "shopping.html"], ["Travel", "travel.html"], ["Health", "health.html"], ["Health Services", "health-services.html"], ["Hospitals", "hospitals.html"], ["Food", "food.html"], ["Weather", "weather.html"], ["Maps Navigation", "maps-navigation.html"], ["Local Services", "local-services.html"],
      ["News", "news.html"], ["Social", "social.html"], ["Entertainment", "entertainment.html"], ["Games", "games.html"], ["Music", "music.html"], ["Books", "books.html"], ["Podcasts", "podcasts.html"],
      ["Science", "science.html"], ["Mathematics", "mathematics.html"], ["History", "history.html"], ["Geography", "geography.html"], ["Languages", "languages.html"], ["Research", "research.html"],
      ["Privacy", "resources/privacy.html"], ["Terms", "resources/terms.html"], ["Help", "resources/help.html"], ["Updates", "resources/updates.html"], ["Sitemap", "resources/sitemap.html"]
    ];
    const states = [
      "andhra-pradesh", "andaman-and-nicobar-islands", "arunachal-pradesh", "assam", "bihar", "chandigarh", "chhattisgarh", "delhi", "goa", "gujarat", "haryana", "himachal", "jammu-and-kashmir", "jharkhand", "karnataka", "kerala", "ladakh", "lakshadweep", "madhya-pradesh", "maharashtra", "manipur", "meghalaya", "mizoram", "nagaland", "odisha", "puducherry", "punjab", "rajasthan", "sikkim", "tamil-nadu", "telangana", "tripura", "uttar-pradesh", "uttarakhand", "west-bengal"
    ];
    states.forEach(stateName => {
      const title = titleFromUrl(`${stateName}.html`);
      known.push([title, `states/${stateName}.html`], [`${title} Govt`, `states/${stateName}-govt.html`], [`${title} Private`, `states/${stateName}-private.html`]);
    });
    known.push(["State Hospitals", "states/hospitals.html"]);
    const fromDom = $$("a[href]").map(link => [link.textContent.trim() || titleFromUrl(link.getAttribute("href")), link.getAttribute("href") || ""])
      .filter(([, href]) => href && /\.html?(#.*)?$/i.test(href));
    const map = new Map();
    [...known, ...fromDom].forEach(([label, href]) => {
      const cleanHref = href.replace(/^\.?\//, "");
      const title = label.replace(/\s+/g, " ").trim() || titleFromUrl(cleanHref);
      if (!cleanHref || cleanHref.startsWith("http")) return;
      map.set(cleanHref, {
        title,
        href: cleanHref,
        keywords: [title, cleanHref, slugify(title), cleanHref.replace(/\.html?$/i, "").replace(/\//g, " ")].join(" ").toLowerCase()
      });
    });
    siteDatabaseCache = [...map.values()];
    return siteDatabaseCache;
  }

  function findSitePage(query) {
    const clean = slugify(query);
    if (!clean) return null;
    const aliases = {
      creator: "creator/creator.html",
      owner: "creator/creator.html",
      developer: "developer.html",
      contact: "contact.html",
      about: "about.html",
      home: "index.html",
      all: "all.html",
      more: "more.html",
      ai: "ai.html",
      "ai-tools": "ai.html",
      job: "jobs.html",
      jobs: "jobs.html",
      career: "career-guidance.html",
      resume: "resume-builder.html",
      interview: "interview-prep.html",
      university: "universities.html",
      universities: "universities.html",
      college: "universities.html",
      govt: "govt.html",
      government: "govt.html",
      coding: "coding.html",
      code: "coding.html",
      courses: "online-courses.html",
      learning: "education.html",
      study: "education.html"
    };
    if (aliases[clean]) {
      const href = aliases[clean];
      return siteDatabase().find(page => page.href === href) || { title: titleFromUrl(href), href };
    }
    const directHref = `${clean}.html`;
    const pages = siteDatabase();
    return pages.find(page => page.href === directHref)
      || pages.find(page => slugify(page.title) === clean)
      || pages.find(page => page.keywords.includes(clean.replace(/-/g, " ")))
      || null;
  }

  function openPageCard(page) {
    return `
      <div class="smart-open-card">
        <b>Opening ${text(page.title)}...</b>
        <span>WebConnect database me page mil gaya. Button tap karke direct open karo.</span>
        <button class="bot-action" type="button" onclick="window.location.href='${text(page.href)}'">Open now</button>
      </div>
    `;
  }

  function directKnowledgeReply(prompt) {
    const clean = String(prompt || "").toLowerCase().trim();
    if (/^(hi|hii|hiii|hello|hey|hy|namaste|namaskar|helo|hola)$/i.test(clean)) {
      return `
        <div class="smart-open-card assistant-greeting">
          <b>Hi! Main WebConnect AI hoon.</b>
          <span>Tum website page open karwa sakte ho, study/career/coding help le sakte ho, ya koi bhi question pooch sakte ho.</span>
          <div class="bot-actions">
            <button class="bot-action" type="button" data-prompt="open creator">Creator</button>
            <button class="bot-action" type="button" data-prompt="best AI tools">AI Tools</button>
            <button class="bot-action" type="button" data-prompt="make a study plan">Study Plan</button>
          </div>
        </div>
      `;
    }
    const facts = [
      [/\b(capital of india|india capital|bharat ki rajdhani)\b/, "India ki capital <b>New Delhi</b> hai."],
      [/\b(what is ai|ai kya hai|artificial intelligence)\b/, "<b>AI</b> computer systems ko learning, reasoning, writing, coding aur decision support jaise kaam karne ki ability deta hai."],
      [/\b(what is html|html kya hai)\b/, "<b>HTML</b> website ka structure banata hai: headings, text, links, images, forms aur sections."],
      [/\b(what is css|css kya hai)\b/, "<b>CSS</b> website ko design deta hai: colors, spacing, layout, responsive design aur animations."],
      [/\b(what is javascript|javascript kya hai|js kya hai)\b/, "<b>JavaScript</b> website ko interactive banata hai: buttons, search, chatbot, forms, animations aur dynamic data."],
      [/\b(what is webconnect|webconnect kya hai)\b/, "<b>WebConnect 2.0</b> ek smart web directory hai jahan AI tools, jobs, education, govt services, coding, finance aur daily websites fast milte hain."],
      [/\b(photosynthesis|prakash sanshleshan)\b/, "<b>Photosynthesis</b> process hai jisme plants sunlight, water aur carbon dioxide se glucose banate hain aur oxygen release karte hain."],
      [/\b(gravity|gurutvakarshan)\b/, "<b>Gravity</b> woh force hai jo objects ko ek dusre ki taraf attract karta hai. Earth ki gravity hume ground par rakhti hai."],
      [/\b(computer|kampyutar)\b/, "<b>Computer</b> ek electronic machine hai jo input leta hai, data process karta hai, output deta hai aur information store karta hai."],
      [/\b(internet kya hai|what is internet)\b/, "<b>Internet</b> connected computers aur servers ka global network hai jisse websites, apps, email, search aur online services chalti hain."]
    ];
    const fact = facts.find(([pattern]) => pattern.test(clean));
    if (fact) return section("Direct Answer", fact[1]);

    const math = clean
      .replace(/what is|calculate|solve|kitna|kya hai|equals|=/gi, "")
      .replace(/plus/gi, "+")
      .replace(/minus/gi, "-")
      .replace(/times|multiply|into/gi, "*")
      .replace(/divide|divided by/gi, "/")
      .trim();
    if (/^[\d+\-*/().\s%]+$/.test(math) && /\d/.test(math)) {
      try {
        const result = Function(`"use strict"; return (${math})`)();
        if (Number.isFinite(result)) return section("Answer", `<b>${text(result)}</b>`);
      } catch {}
    }

    if (/\b(time|date|today|aaj|samay)\b/.test(clean)) {
      const now = new Date();
      return section("Current Time", `Abhi <b>${now.toLocaleTimeString()}</b> hai, date <b>${now.toLocaleDateString()}</b> hai.`);
    }

    return "";
  }

  function helpfulOpenAnswer(prompt) {
    const clean = String(prompt || "").toLowerCase().trim();
    const directCategory = /^(ai|ai tools|jobs?|education|coding|developer|govt|government|universities|university|college|shopping|news|weather|banking|finance|tools)$/.test(clean);
    const wantsOpen = /\b(open|go to|show|page|website|site|category|mujhe|dikhao|kholo)\b/.test(clean);
    const directNamedPage = /^(creator|owner|contact|about|home|resume|interview|universities|university|college|all|more|popular)$/.test(clean);
    if (!directCategory && !wantsOpen && !directNamedPage) return "";
    const query = clean
      .replace(/\b(open|go to|show|page|website|site|category|please|pls|mujhe|dikhao|kholo)\b/g, "")
      .replace(/\s+/g, " ")
      .trim();
    const page = findSitePage(query || clean);
    return page ? openPageCard(page) : "";
  }

  function universalSmartAnswer(prompt, intent) {
    const safePrompt = text(prompt);
    const clean = String(prompt || "").toLowerCase();
    const direct = directKnowledgeReply(prompt);
    if (direct) return direct;

    const open = helpfulOpenAnswer(prompt);
    if (open) return open;

    if (/\b(best|suggest|recommend|resource|tools|chahiye|batao)\b/.test(clean)) {
      let topic = "AI and productivity";
      let picks = ["ChatGPT", "Gemini", "Perplexity", "Canva", "Notion AI"];
      if (/\b(job|career|intern|resume|remote)\b/.test(clean)) {
        topic = "career";
        picks = ["LinkedIn", "Naukri", "Indeed", "Internshala", "Remote OK"];
      } else if (/\b(study|education|course|exam|student|learn)\b/.test(clean)) {
        topic = "study";
        picks = ["Coursera", "Khan Academy", "NPTEL", "Swayam", "freeCodeCamp"];
      } else if (/\b(code|coding|developer|programming|web dev)\b/.test(clean)) {
        topic = "coding";
        picks = ["GitHub", "Stack Overflow", "MDN Web Docs", "freeCodeCamp", "GeeksforGeeks"];
      } else if (/\b(design|photo|video|ui|ux|canva|figma)\b/.test(clean)) {
        topic = "design";
        picks = ["Canva", "Figma", "Pixlr", "Behance", "Dribbble"];
      }
      return [
        section("Best Picks", `For <b>${text(topic)}</b>, ye options kaafi useful hain.`),
        `<div class="bot-mini-grid">${picks.map(name => `<button class="bot-mini-card" type="button" onclick="window.open('https://www.google.com/search?q=${encodeURIComponent(name)}','_blank')"><strong>${text(name)}</strong><small>Search resource</small></button>`).join("")}</div>`,
        section("How to choose", "Pehle free option test karo, phir jo tumhare workflow me fastest lage usko daily use me rakho.")
      ].join("");
    }

    if (/\b(how to|kaise|कैसे)\b/.test(clean)) {
      return [
        section("Short Answer", `Best way to handle <b>${safePrompt}</b> is to break it into small clear steps.`),
        section("Steps", list([
          "Goal exactly define karo.",
          "Required tools/resources identify karo.",
          "First small action start karo.",
          "Result check karke next step improve karo."
        ])),
        section("Smart Tip", "Agar tum topic, class/level, deadline ya exact problem bata doge to main tailored answer de dunga.")
      ].join("");
    }

    if (/\b(why|kyu|क्यों)\b/.test(clean)) {
      return [
        section("Reasoning", `<b>${safePrompt}</b> ka answer usually cause, effect aur example se clear hota hai.`),
        section("Simple Breakdown", list([
          "Cause: main reason kya hai.",
          "Effect: uska result kya hota hai.",
          "Example: real life me kaise dikhai deta hai.",
          "Conclusion: final takeaway kya hai."
        ]))
      ].join("");
    }

    if (/\b(compare|difference|vs|better|best)\b/.test(clean)) {
      return [
        section("Comparison", `Main <b>${safePrompt}</b> ko features, benefits, limits aur best use-case ke basis par compare karunga.`),
        section("Decision Rule", list([
          "Daily use ke liye simple option choose karo.",
          "Professional work ke liye reliable aur scalable option choose karo.",
          "Budget important ho to free/low-cost option pehle test karo."
        ]))
      ].join("");
    }

    return [
      section("Smart Reply", `Maine tumhara question samjha: <b>${safePrompt}</b>.`),
      section("Best Next Answer", list([
        "Agar ye study topic hai to main definition, key points aur example de sakta hoon.",
        "Agar ye website/resource query hai to main direct WebConnect page open kara sakta hoon.",
        "Agar ye personal/career/coding problem hai to exact steps bana sakta hoon."
      ])),
      section("Ask Better", "Ek line aur add karo: topic + goal + level. Example: 'Python beginner ke liye 7 day plan'.")
    ].join("");
  }

  function relatedResources(prompt, intent) {
    const links = [];
    const clean = encodeURIComponent(prompt);
    if (intent === "coding") {
      links.push(["Developer", "developer.html"], ["Coding", "coding.html"], ["Search docs", `https://www.google.com/search?q=${clean}+documentation`]);
    } else if (intent === "study") {
      links.push(["Education", "education.html"], ["Courses", "online-courses.html"], ["Revision search", `https://www.google.com/search?q=${clean}+notes`]);
    } else if (intent === "career") {
      links.push(["Jobs", "jobs.html"], ["Resume", "resume-builder.html"], ["Interview", "interview-prep.html"]);
    } else if (intent === "research") {
      links.push(["Research", "research.html"], ["Google results", `https://www.google.com/search?q=${clean}`], ["News", "news.html"]);
    } else {
      links.push(["All Categories", "all.html"], ["AI Tools", "ai.html"], ["Web search", `https://www.google.com/search?q=${clean}`]);
    }
    return `<div class="smart-reference-list">${links.map(([label, href]) => `<a href="${href}" target="${href.startsWith("http") ? "_blank" : "_self"}" rel="noopener">${label}</a>`).join("")}</div>`;
  }

  function smartLocalAnswer(prompt, intent) {
    const safePrompt = text(prompt);
    const universal = universalSmartAnswer(prompt, intent);
    if (universal && intent !== "coding" && intent !== "study" && intent !== "research" && intent !== "writing" && intent !== "career") return universal;

    if (intent === "coding") {
      const direct = directKnowledgeReply(prompt);
      if (direct) return direct;
      return [
        section("Coding Assistant", `I will treat this as a code task: <b>${safePrompt}</b>.`),
        section("Best approach", list([
          "Share the exact code or error if you want precise debugging.",
          "I will identify the issue, explain why it happens, and suggest a cleaner fix.",
          "For complete solutions, I will include implementation steps and best practices."
        ])),
        codeBlock("// Paste your code or error here\n// I will explain, fix, and optimize it.", "js")
      ].join("");
    }
    if (intent === "study") {
      const direct = directKnowledgeReply(prompt);
      if (direct) return direct;
      return [
        section("Easy Explanation", `This looks like a study question about <b>${safePrompt}</b>.`),
        section("Exam Notes", list([
          "Start with the definition or core idea.",
          "Add 3-5 key points in simple language.",
          "Use one example, then revise with a short summary.",
          "Memory trick: connect the topic to a real-life use case."
        ])),
        section("Revision Line", "If you want, I can turn this into short notes, flashcards, or quiz questions.")
      ].join("");
    }
    if (intent === "research") {
      return [
        section("Research Summary", `For <b>${safePrompt}</b>, I would organize the answer into overview, key points, comparison, and conclusion.`),
        section("Research Structure", list([
          "Background: what the topic means.",
          "Important points: facts, causes, benefits, risks, or examples.",
          "Comparison: options, pros and cons, or before vs after.",
          "Conclusion: clear final takeaway and next search terms."
        ])),
        section("Sources", "Use the web search action below to open fresh results in a new tab.")
      ].join("");
    }
    if (intent === "writing") {
      return [
        section("Writing Assistant", `I can format this professionally: <b>${safePrompt}</b>.`),
        section("Recommended Format", list([
          "Clear subject or title.",
          "Short opening with purpose.",
          "Main points in clean paragraphs or bullets.",
          "Polite closing with action requested."
        ])),
        section("Next Step", "Paste your draft and I will rewrite it with a polished tone.")
      ].join("");
    }
    if (intent === "career") {
      return [
        section("Career Plan", `For <b>${safePrompt}</b>, focus on profile, preparation, applications, and follow-up.`),
        section("Action Steps", list([
          "Update resume and LinkedIn with measurable achievements.",
          "Shortlist roles and required skills.",
          "Practice interview answers and projects.",
          "Track applications and follow up professionally."
        ]))
      ].join("");
    }
    if (intent === "quick") {
      return universal || `<b>Quick answer:</b> ${safePrompt}. I can expand this into steps, examples, or resources if needed.`;
    }
    return universal;
  }

  function buildAssistantReply(prompt) {
    try {
      const intent = inferIntent(prompt);
      updateSessionMemory(prompt, intent);
      const chosenMode = state.settings.answerStyle === "balanced" ? intent : state.settings.answerStyle;
      const mode = chosenMode === "quick" ? "short" : chosenMode;
      const clean = prompt.toLowerCase();
      const clarification = needsClarification(prompt, intent);
      let base = "";

      if (clarification) {
        sessionMemory.unanswered.unshift(prompt);
        base = `${section("Quick clarification", text(clarification))}${section("What I can do next", list([
          "Answer directly once you add the missing detail.",
          "Create a draft or plan from the context already available.",
          "Search related WebConnect resources if you want a broad starting point."
        ]))}`;
      } else if (clean.includes("summarize this chat") || clean.includes("summary")) {
        base = summarizeConversation();
      } else if (clean.includes("translate")) {
        base = `${section("Translation Mode", "Paste the text and target language. I will translate it cleanly, preserve meaning, and keep the tone natural.")}`;
      } else if (clean.includes("remind")) {
        base = createReminderFromText(prompt);
      } else if (clean.includes("todo") || clean.includes("task")) {
        base = addTodoFromText(prompt);
      } else if (state.selectedFiles.length) {
        base = analyzeSelectedFiles(prompt);
      } else if (typeof window.getReply === "function") {
        const local = smartLocalAnswer(prompt, intent);
        let legacy = "";
        try {
          legacy = window.getReply(prompt) || "";
        } catch (error) {
          console.warn("Legacy chatbot reply failed:", error);
        }
        base = local || legacy;
        if (local && legacy && !local.includes("smart-open-card") && !plain(legacy).includes("exact match")) {
          base += section("WebConnect Match", legacy);
        }
      } else {
        base = smartLocalAnswer(prompt, intent) || `I can help with "${text(prompt)}". Try asking for resources, a plan, a summary, translation, coding help, or research suggestions.`;
      }

      if (base.includes("smart-open-card")) return base;

      const actions = smartActionRow(prompt);
      const references = relatedResources(prompt, intent);
      return `${base}${actions}${references}`;
    } catch (error) {
      console.error("Assistant reply failed:", error);
      return `${section("WebConnect AI", `Main tumhara message samajh gaya: <b>${text(prompt)}</b>. Abhi local assistant mode me hoon, isliye main tumhe clear next steps aur useful WebConnect resources de sakta hoon.`)}${section("Try this", list([
        "AI tools, jobs, study, coding, government services ya shopping jaise keyword bhejo.",
        "Agar code issue hai to exact error paste karo.",
        "Agar plan chahiye to goal aur deadline batao."
      ]))}${smartActionRow(prompt)}${relatedResources(prompt, "productivity")}`;
    }
  }

  function smartActionRow(prompt) {
    const q = encodeURIComponent(prompt);
    return `
      <div class="bot-actions">
        <button class="bot-action" type="button" onclick="window.open('https://www.google.com/search?q=${q}', '_blank')">Web search</button>
        <button class="bot-action" type="button" data-prompt="explain like beginner: ${text(prompt)}">Beginner</button>
        <button class="bot-action" type="button" data-prompt="give expert detail: ${text(prompt)}">Expert</button>
      </div>
    `;
  }

  function streamBotMessage(html, prompt) {
    const chat = activeChat();
    const message = {
      id: uid("msg"),
      role: "bot",
      html: "",
      raw: plain(html),
      at: Date.now(),
      favorite: false,
      sourcePrompt: prompt
    };
    chat.messages.push(message);
    state.lastBotForRegen = { prompt, id: message.id };
    saveState();
    renderMessages();
    const box = $("#chat-messages");
    const liveText = $(`[data-message-id="${message.id}"] .msg-text`);

    const words = html.split(/(\s+)/);
    let index = 0;
    state.streaming = true;
    $("#chat-container")?.classList.add("is-chatting");
    const timer = setInterval(() => {
      message.html += words.slice(index, index + 3).join("");
      index += 3;
      if (liveText) liveText.innerHTML = formatMessageContent(message);
      if (box) box.scrollTop = box.scrollHeight;
      if (index >= words.length) {
        clearInterval(timer);
        message.html = html;
        chat.updatedAt = Date.now();
        compressLongConversation();
        saveState();
        state.streaming = false;
        $("#chat-container")?.classList.remove("is-chatting");
        scheduleIdleMode();
        renderAll();
        if (state.settings.autoRead) speakText(message.raw);
      }
    }, 38);
  }

  function scheduleIdleMode() {
    window.clearTimeout(state.idleTimer);
    state.idleTimer = window.setTimeout(() => {
      if (!state.streaming) $("#chat-container")?.classList.remove("is-chatting");
    }, 24000);
  }

  function sendMessage() {
    if (state.streaming) return;
    const input = $("#userInput");
    const raw = input?.value.trim() || "";
    if (!raw && !state.selectedFiles.length) return;
    const prompt = raw || "Analyze the uploaded files";
    $("#chat-container")?.classList.add("is-chatting");
    addMessage("You", text(prompt), { raw: prompt });
    rememberPrompt(prompt);
    if (input) {
      input.value = "";
      resizeInput();
    }
    updateCounter();
    showTyping(prompt);
    setTimeout(() => {
      removeTyping();
      streamBotMessage(buildAssistantReply(prompt), prompt);
      state.selectedFiles = [];
      renderFilePreview();
    }, Math.min(900, Math.max(250, prompt.length * 10)));
  }

  function rememberPrompt(prompt) {
    const prompts = read(STORE.prompts, []).filter(item => item !== prompt);
    prompts.unshift(prompt);
    write(STORE.prompts, prompts.slice(0, 10));
  }

  function summarizeConversation() {
    const lines = activeChat().messages.slice(-10).map(message => `${message.role}: ${message.raw || plain(message.html)}`);
    const summary = lines.join(" ").slice(0, 520);
    activeChat().summary = summary;
    return `<b>Conversation summary</b><br>${text(summary || "No conversation yet.")}`;
  }

  function compressLongConversation() {
    const chat = activeChat();
    if (chat.messages.length < 18) return;
    chat.summary = chat.messages.slice(0, -12).map(message => message.raw || plain(message.html)).join(" ").slice(-900);
    chat.messages = chat.messages.slice(-12);
  }

  function createReminderFromText(prompt) {
    const reminders = read("wc_ai_reminders_v1", []);
    reminders.unshift({ id: uid("rem"), text: prompt, at: Date.now() });
    write("wc_ai_reminders_v1", reminders.slice(0, 20));
    return `Reminder saved locally. I will keep it in your assistant memory panel for this browser.`;
  }

  function addTodoFromText(prompt) {
    const todos = read(STORE.todos, []);
    todos.unshift({ id: uid("todo"), text: prompt.replace(/^(add|create)?\s*(todo|task)\s*/i, "").trim() || prompt, done: false });
    write(STORE.todos, todos);
    renderPanel("tasks");
    return `Task added to your to-do list.`;
  }

  function analyzeSelectedFiles(prompt) {
    const list = state.selectedFiles.map(file => `${file.name} (${Math.ceil(file.size / 1024)} KB, ${file.type || "file"})`).join("<br>");
    return `<b>Uploaded file analysis</b><br>${list}<br><br>I can summarize, extract key points, make notes, or prepare questions from these files. ${text(prompt)}`;
  }

  function renderPanel(panel) {
    const side = $("#chatSidePanel");
    if (!side) return;
    if (!panel) {
      side.classList.remove("is-open");
      side.setAttribute("aria-hidden", "true");
      return;
    }
    side.dataset.panel = panel;
    side.classList.add("is-open");
    side.setAttribute("aria-hidden", "false");
    const renderers = { history: historyPanel, notes: notesPanel, tasks: tasksPanel, settings: settingsPanel };
    side.innerHTML = renderers[panel]?.() || "";
  }

  function historyPanel() {
    const query = text($("#historySearch")?.value || "");
    const chats = [...state.chats]
      .filter(chat => !query || `${chat.title} ${chat.folder} ${chat.summary}`.toLowerCase().includes(query.toLowerCase()))
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
    return `
      <div class="panel-head"><strong>Conversation history</strong><button type="button" data-close-panel><i class="fas fa-xmark"></i></button></div>
      <input id="historySearch" class="panel-input" placeholder="Search chats..." value="${query}">
      <div class="panel-actions">
        <button type="button" data-new-chat>New</button><button type="button" data-clear-chat>Clear Chat</button><button type="button" data-copy-all>Copy All</button>
      </div>
      <div class="history-list">${chats.map(chat => `
        <button type="button" class="${chat.id === state.activeId ? "active" : ""}" data-chat-id="${chat.id}">
          <span>${chat.pinned ? "Pinned" : chat.folder}</span><strong>${text(chat.title)}</strong><small>${new Date(chat.updatedAt).toLocaleString()}</small>
        </button>
      `).join("")}</div>
      <div class="panel-actions">
        <button type="button" data-pin-chat>${activeChat().pinned ? "Unpin" : "Pin"}</button>
        <button type="button" data-export="txt">TXT</button><button type="button" data-export="md">MD</button><button type="button" data-export="pdf">PDF</button>
        <button type="button" data-import-chat>Import</button>
      </div>
    `;
  }

  function notesPanel() {
    const notes = read(STORE.notes, []);
    return `
      <div class="panel-head"><strong>Notes</strong><button type="button" data-close-panel><i class="fas fa-xmark"></i></button></div>
      <textarea id="noteDraft" class="panel-textarea" placeholder="Save an important note..."></textarea>
      <div class="panel-actions"><button type="button" data-save-note>Save Note</button><button type="button" data-note-from-chat>From Chat</button></div>
      <div class="note-list">${notes.map(note => `<article><p>${text(note.text)}</p><button type="button" data-delete-note="${note.id}">Delete</button></article>`).join("") || '<div class="panel-empty">No saved notes yet.</div>'}</div>
    `;
  }

  function tasksPanel() {
    const todos = read(STORE.todos, []);
    return `
      <div class="panel-head"><strong>To-do and reminders</strong><button type="button" data-close-panel><i class="fas fa-xmark"></i></button></div>
      <div class="panel-row"><input id="todoDraft" class="panel-input" placeholder="Add task..."><button type="button" data-add-todo>Add</button></div>
      <div class="todo-list">${todos.map(todo => `
        <label><input type="checkbox" data-toggle-todo="${todo.id}" ${todo.done ? "checked" : ""}><span>${text(todo.text)}</span><button type="button" data-delete-todo="${todo.id}">Delete</button></label>
      `).join("") || '<div class="panel-empty">No tasks yet.</div>'}</div>
    `;
  }

  function settingsPanel() {
    return `
      <div class="panel-head"><strong>Assistant settings</strong><button type="button" data-close-panel><i class="fas fa-xmark"></i></button></div>
      <label>Theme<select id="themeSetting" class="panel-input"><option value="auto">Auto</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
      <label>Accent<input id="accentSetting" type="color" value="${text(state.settings.accent)}"></label>
      <label>Voice<select id="voiceSetting" class="panel-input"></select></label>
      <label>Speech speed<input id="rateSetting" type="range" min="0.7" max="1.4" step="0.1" value="${state.settings.rate}"></label>
      <label class="panel-check"><input id="autoReadSetting" type="checkbox" ${state.settings.autoRead ? "checked" : ""}> Auto-read responses</label>
      <div class="panel-actions"><button type="button" data-stop-speech>Stop Voice</button><button type="button" data-save-settings>Save</button></div>
    `;
  }

  function applySettings() {
    const chat = $("#chat-container");
    if (!chat) return;
    chat.dataset.theme = state.settings.theme;
    chat.style.setProperty("--chat-accent", state.settings.accent);
    $("#assistantMode") && ($("#assistantMode").value = state.settings.mode);
    $("#answerStyle") && ($("#answerStyle").value = state.settings.answerStyle);
    $("#chatLanguage") && typeof window.getChatLanguage === "function" && ($("#chatLanguage").value = window.getChatLanguage());
    populateVoices();
  }

  function populateVoices() {
    const select = $("#voiceSetting");
    if (!select || !("speechSynthesis" in window)) return;
    const voices = speechSynthesis.getVoices();
    select.innerHTML = `<option value="">System default</option>${voices.map(voice => `<option value="${text(voice.name)}">${text(voice.name)}</option>`).join("")}`;
    select.value = state.settings.voice || "";
  }

  function speakText(content) {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(plain(content));
    const voice = speechSynthesis.getVoices().find(item => item.name === state.settings.voice);
    if (voice) utterance.voice = voice;
    utterance.rate = Number(state.settings.rate) || 1;
    speechSynthesis.speak(utterance);
  }

  function quickMsg(type) {
    const clean = String(type || "").toLowerCase().trim();
    addMessage("You", text(type), { raw: type });
    const page = findSitePage(clean);
    if (page) {
      streamBotMessage(openPageCard(page), type);
    } else {
      streamBotMessage(buildAssistantReply(type), type);
    }
  }

  function runChatPrompt(prompt) {
    const input = $("#userInput");
    if (!input) return;
    input.value = prompt;
    resizeInput();
    updateCounter();
    sendMessage();
  }

  function exportChat(type) {
    const chat = activeChat();
    const body = chat.messages.map(message => `${message.role.toUpperCase()} ${new Date(message.at).toLocaleString()}\n${message.raw || plain(message.html)}`).join("\n\n");
    if (type === "pdf") {
      const printWindow = window.open("", "_blank");
      printWindow.document.write(`<title>${text(chat.title)}</title><pre style="font:14px/1.6 Arial;white-space:pre-wrap">${text(body)}</pre>`);
      printWindow.document.close();
      printWindow.print();
      return;
    }
    const blob = new Blob([type === "md" ? `# ${chat.title}\n\n${body}` : body], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${chat.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase() || "chat"}.${type}`;
    link.click();
    URL.revokeObjectURL(link.href);
  }

  function copyAll() {
    const body = activeChat().messages.map(message => `${message.role}: ${message.raw || plain(message.html)}`).join("\n");
    navigator.clipboard?.writeText(body);
  }

  function resizeInput() {
    const input = $("#userInput");
    if (!input) return;
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 130)}px`;
  }

  function updateCounter() {
    const input = $("#userInput");
    const counter = $("#charCounter");
    if (input && counter) counter.textContent = `${input.value.length} / ${input.maxLength || 2000}`;
  }

  function renderFilePreview() {
    const preview = $("#chatFilePreview");
    if (!preview) return;
    preview.textContent = state.selectedFiles.length ? `${state.selectedFiles.length} file(s) ready` : "";
  }

  function handleFiles(files) {
    state.selectedFiles = [...files].slice(0, 5);
    renderFilePreview();
    if (state.selectedFiles.length) $("#userInput")?.focus();
  }

  function wireEvents() {
    const chat = $("#chat-container");
    if (!chat || chat.dataset.eventsReady === "true") return;
    chat.dataset.eventsReady = "true";

    $("#closeChat")?.addEventListener("click", () => {
      chat.style.display = "none";
      localStorage.setItem("chatHidden", "true");
    });
    $("#chatMoreBtn")?.addEventListener("click", () => {
      const side = $("#chatSidePanel");
      renderPanel(side?.classList.contains("is-open") ? "" : "settings");
    });
    $("#chatSendBtn")?.addEventListener("click", sendMessage);
    $("#chatAttachBtn")?.addEventListener("click", () => $("#chatFileInput")?.click());
    $("#chatFileInput")?.addEventListener("change", event => handleFiles(event.target.files));
    $("#assistantMode")?.addEventListener("change", event => {
      state.settings.mode = event.target.value;
      saveState();
    });
    $("#answerStyle")?.addEventListener("change", event => {
      state.settings.answerStyle = event.target.value;
      saveState();
    });
    $("#userInput")?.addEventListener("input", () => {
      resizeInput();
      updateCounter();
    });
    $("#userInput")?.addEventListener("keydown", event => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
      }
    });

    const drop = $("#chatDropZone");
    ["dragenter", "dragover"].forEach(name => drop?.addEventListener(name, event => {
      event.preventDefault();
      drop.classList.add("is-active");
    }));
    ["dragleave", "drop"].forEach(name => drop?.addEventListener(name, event => {
      event.preventDefault();
      drop.classList.remove("is-active");
      if (event.dataTransfer?.files?.length) handleFiles(event.dataTransfer.files);
    }));
    document.addEventListener("paste", event => {
      const files = [...(event.clipboardData?.files || [])];
      if (files.length && chat.style.display !== "none") handleFiles(files);
    });

    chat.addEventListener("click", event => {
      const panelButton = event.target.closest("[data-panel]");
      if (panelButton) renderPanel(panelButton.dataset.panel);
      if (event.target.closest("[data-close-panel]")) renderPanel("");
      const prompt = event.target.closest("[data-prompt]")?.dataset.prompt;
      if (prompt) runChatPrompt(prompt);
      const template = event.target.closest("[data-template]")?.dataset.template;
      if (template) {
        const input = $("#userInput");
        input.value = `${template} `;
        input.focus();
        resizeInput();
        updateCounter();
      }
      const quick = event.target.closest("[data-quick-action]")?.dataset.quickAction;
      if (quick) runChatPrompt(`${quick} this conversation`);

      const msgButton = event.target.closest("[data-msg-action]");
      if (msgButton) handleMessageAction(msgButton);
      const chatButton = event.target.closest("[data-chat-id]");
      if (chatButton) {
        state.activeId = chatButton.dataset.chatId;
        saveState();
        renderAll();
      }
      if (event.target.closest("[data-new-chat]")) createChat();
      if (event.target.closest("[data-clear-chat]")) {
        activeChat().messages = [];
        saveState();
        renderAll();
      }
      if (event.target.closest("[data-copy-all]")) copyAll();
      if (event.target.closest("[data-pin-chat]")) {
        activeChat().pinned = !activeChat().pinned;
        saveState();
        renderAll();
      }
      const exportBtn = event.target.closest("[data-export]");
      if (exportBtn) exportChat(exportBtn.dataset.export);
      if (event.target.closest("[data-import-chat]")) importChat();
      if (event.target.closest("[data-save-note]")) saveNote($("#noteDraft")?.value || "");
      if (event.target.closest("[data-note-from-chat]")) saveNote(summarizeConversation().replace(/<[^>]+>/g, " "));
      const deleteNote = event.target.closest("[data-delete-note]")?.dataset.deleteNote;
      if (deleteNote) {
        write(STORE.notes, read(STORE.notes, []).filter(note => note.id !== deleteNote));
        renderPanel("notes");
      }
      if (event.target.closest("[data-add-todo]")) {
        const value = $("#todoDraft")?.value.trim();
        if (value) addTodoFromText(value);
      }
      const deleteTodo = event.target.closest("[data-delete-todo]")?.dataset.deleteTodo;
      if (deleteTodo) {
        write(STORE.todos, read(STORE.todos, []).filter(todo => todo.id !== deleteTodo));
        renderPanel("tasks");
      }
      const toggleTodo = event.target.closest("[data-toggle-todo]")?.dataset.toggleTodo;
      if (toggleTodo) {
        const todos = read(STORE.todos, []).map(todo => todo.id === toggleTodo ? { ...todo, done: !todo.done } : todo);
        write(STORE.todos, todos);
        renderPanel("tasks");
      }
      if (event.target.closest("[data-save-settings]")) saveSettingsFromPanel();
      if (event.target.closest("[data-stop-speech]")) window.speechSynthesis?.cancel();
    });

    chat.addEventListener("input", event => {
      if (event.target.id === "historySearch") renderPanel("history");
    });

    initVoiceInput();
  }

  function handleMessageAction(button) {
    const row = button.closest("[data-message-id]");
    const message = activeChat().messages.find(item => item.id === row?.dataset.messageId);
    if (!message) return;
    const action = button.dataset.msgAction;
    if (action === "copy") navigator.clipboard?.writeText(message.raw || plain(message.html));
    if (action === "delete") {
      activeChat().messages = activeChat().messages.filter(item => item.id !== message.id);
      saveState();
      renderAll();
    }
    if (action === "favorite") {
      message.favorite = !message.favorite;
      saveState();
      renderAll();
    }
    if (action === "edit") {
      const input = $("#userInput");
      input.value = message.raw || plain(message.html);
      input.focus();
      resizeInput();
      updateCounter();
    }
    if (action === "regen") {
      const prompt = message.sourcePrompt || [...activeChat().messages].reverse().find(item => item.role === "user")?.raw || "Regenerate";
      activeChat().messages = activeChat().messages.filter(item => item.id !== message.id);
      saveState();
      streamBotMessage(buildAssistantReply(prompt), prompt);
    }
    if (action === "speak") speakText(message.raw || plain(message.html));
  }

  function saveNote(value) {
    if (!value.trim()) return;
    const notes = read(STORE.notes, []);
    notes.unshift({ id: uid("note"), text: value.trim(), at: Date.now() });
    write(STORE.notes, notes.slice(0, 40));
    renderPanel("notes");
  }

  function saveSettingsFromPanel() {
    state.settings.theme = $("#themeSetting")?.value || state.settings.theme;
    state.settings.accent = $("#accentSetting")?.value || state.settings.accent;
    state.settings.voice = $("#voiceSetting")?.value || "";
    state.settings.rate = Number($("#rateSetting")?.value || 1);
    state.settings.autoRead = Boolean($("#autoReadSetting")?.checked);
    saveState();
    applySettings();
  }

  function importChat() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,.txt,.md";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        createChat(file.name.replace(/\.[^.]+$/, ""), false);
        addMessage("Bot", `<b>Imported chat file</b><br>${text(String(reader.result).slice(0, 4000))}`);
        renderAll();
      };
      reader.readAsText(file);
    };
    input.click();
  }

  function initVoiceInput() {
    const mic = $("#mic-btn");
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!mic || !SpeechRecognition) return;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = "en-IN";
    mic.onclick = () => {
      recognition.start();
      mic.classList.add("is-listening");
    };
    recognition.onresult = event => {
      $("#userInput").value = event.results[0][0].transcript;
      resizeInput();
      updateCounter();
      sendMessage();
    };
    recognition.onend = () => mic.classList.remove("is-listening");
    recognition.onerror = () => mic.classList.remove("is-listening");
  }

  function enhanceLauncher() {
    const toggle = $("#chat-toggle");
    const chat = $("#chat-container");
    if (!toggle || !chat) return;
    toggle.onclick = () => {
      const open = chat.style.display === "grid" || chat.style.display === "flex";
      chat.style.display = open ? "none" : "grid";
      if (!open) {
        localStorage.removeItem("chatHidden");
        chat.classList.remove("wc-chat-clean");
        renderAll();
        setTimeout(() => $("#userInput")?.focus(), 80);
      }
    };
  }

  function init() {
    ensureState();
    buildShell();
    wireEvents();
    enhanceLauncher();
    renderAll();
    window.addMessage = addMessage;
    window.sendMessage = sendMessage;
    window.quickMsg = quickMsg;
    window.runChatPrompt = runChatPrompt;
    window.showTyping = showTyping;
    window.removeTyping = removeTyping;
    if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = populateVoices;
    window.addEventListener("online", () => $("#chatStatus") && ($("#chatStatus").textContent = "Back online"));
    window.addEventListener("offline", () => $("#chatStatus") && ($("#chatStatus").textContent = "Offline mode: local assistant active"));
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
