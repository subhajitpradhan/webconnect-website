(function () {
  "use strict";

  const STORE = {
    recent: "wc_recent_searches_v2",
    favorites: "wc_platform_favorites_v1"
  };

  const intentBundles = [
    {
      intent: "instagram",
      terms: ["inst", "insta", "instagram", "ig", "reel", "story"],
      suggestions: [
        ["Instagram", "https://instagram.com", "Social"],
        ["Instagram Downloader", "https://www.google.com/search?q=Instagram+downloader", "Tool search"],
        ["Instagram Story Viewer", "https://www.google.com/search?q=Instagram+story+viewer", "Tool search"],
        ["Instagram Reels Downloader", "https://www.google.com/search?q=Instagram+reels+downloader", "Tool search"]
      ]
    },
    {
      intent: "ai chat",
      terms: ["chat", "chatbot", "ai chat", "ask ai", "gpt"],
      suggestions: [
        ["ChatGPT", "https://chat.openai.com", "AI"],
        ["Claude", "https://claude.ai", "AI"],
        ["Gemini", "https://gemini.google.com", "AI"],
        ["AI Chatbots", "ai.html", "Category"]
      ]
    },
    {
      intent: "career",
      terms: ["job", "jobs", "career", "intern", "resume", "interview", "remote"],
      suggestions: [
        ["Jobs", "jobs.html", "Category"],
        ["Remote Jobs", "remote-jobs.html", "Category"],
        ["Internships", "internships.html", "Category"],
        ["Resume Builder", "resume-builder.html", "Career"]
      ]
    },
    {
      intent: "learning",
      terms: ["learn", "course", "study", "exam", "scholar", "python", "notes"],
      suggestions: [
        ["Education", "education.html", "Category"],
        ["Online Courses", "online-courses.html", "Learning"],
        ["Scholarships", "scholarships.html", "Learning"],
        ["Python Learning", "https://www.google.com/search?q=learn+python", "Web search"]
      ]
    },
    {
      intent: "government",
      terms: ["gov", "govt", "government", "scheme", "portal", "certificate", "form"],
      suggestions: [
        ["Government Services", "govt.html", "Category"],
        ["Government Portals", "government-portals.html", "Official"],
        ["Government Schemes", "government-schemes.html", "Official"],
        ["Public Utilities", "public-utilities.html", "Official"]
      ]
    }
  ];

  let activeIndex = -1;
  let activeResults = [];

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    }[char]));
  }

  function normalize(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/https?:\/\//g, " ")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function read(key, fallback) {
    try {
      return JSON.parse(localStorage.getItem(key)) || fallback;
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }

  function siteDomain(url) {
    try {
      return new URL(url, window.location.href).hostname.replace(/^www\./, "");
    } catch {
      return String(url || "").replace(/^https?:\/\//, "").split("/")[0];
    }
  }

  function pageCatalog() {
    const pageMap = typeof pages !== "undefined" && pages ? pages : (window.pages || {});
    const siteList = typeof websites !== "undefined" && Array.isArray(websites)
      ? websites
      : (Array.isArray(window.websites) ? window.websites : []);

    const fromPages = pageMap && typeof pageMap === "object"
      ? Object.entries(pageMap).map(([name, url]) => ({
          name: title(name),
          url,
          category: url.endsWith(".html") ? "WebConnect Page" : "Website",
          keywords: [name]
        }))
      : [];

    const fromSites = siteList
      .map(site => ({
          name: site.name,
          url: site.url,
          category: site.category || "Website",
          keywords: [site.name, site.category, site.url]
        }))
      ;

    const unique = new Map();
    [...fromSites, ...fromPages].forEach(item => {
      if (!item.name || !item.url) return;
      unique.set(`${normalize(item.name)}|${item.url}`, item);
    });
    return [...unique.values()];
  }

  function title(value) {
    return String(value || "")
      .replace(/[-_]+/g, " ")
      .replace(/\b\w/g, char => char.toUpperCase());
  }

  function editDistance(a, b) {
    if (!a || !b) return Math.max(a.length, b.length);
    const dp = Array.from({ length: b.length + 1 }, (_, row) => [row]);
    for (let col = 0; col <= a.length; col += 1) dp[0][col] = col;
    for (let row = 1; row <= b.length; row += 1) {
      for (let col = 1; col <= a.length; col += 1) {
        dp[row][col] = b[row - 1] === a[col - 1]
          ? dp[row - 1][col - 1]
          : Math.min(dp[row - 1][col - 1], dp[row][col - 1], dp[row - 1][col]) + 1;
      }
    }
    return dp[b.length][a.length];
  }

  function fuzzyScore(text, query) {
    const source = normalize(text);
    const q = normalize(query);
    if (!source || !q) return 0;
    if (source === q) return 1000;
    if (source.startsWith(q)) return 860;
    if (source.includes(q)) return 690;

    const words = source.split(" ");
    if (q.split(" ").every(word => source.includes(word))) return 560;
    if (words.some(word => editDistance(word, q) <= Math.max(1, Math.floor(q.length / 4)))) return 430;

    let qIndex = 0;
    let gaps = 0;
    for (const char of source) {
      if (char === q[qIndex]) qIndex += 1;
      else if (qIndex > 0) gaps += 1;
      if (qIndex === q.length) return Math.max(120, 330 - gaps * 8);
    }
    return 0;
  }

  function intentResults(query) {
    const q = normalize(query);
    if (!q) return [];
    return intentBundles
      .filter(bundle => bundle.terms.some(term => normalize(term).startsWith(q) || q.includes(normalize(term)) || editDistance(normalize(term), q) <= 1))
      .flatMap(bundle => bundle.suggestions.map(([name, url, category], index) => ({
        name,
        url,
        category,
        type: url.endsWith(".html") ? "page" : "intent",
        reason: `Matched ${bundle.intent}`,
        score: 940 - index
      })));
  }

  function recentResults(query) {
    return read(STORE.recent, [])
      .map(item => item.query || item.name || "")
      .filter(Boolean)
      .filter(item => fuzzyScore(item, query) > 0)
      .slice(0, 4)
      .map((name, index) => ({
        name,
        url: `https://www.google.com/search?q=${encodeURIComponent(name)}`,
        category: "Recent search",
        type: "recent",
        reason: "From your recent searches",
        score: 900 - index
      }));
  }

  function rankedResults(query, limit = 9) {
    const q = normalize(query);
    if (!q) return [];
    const results = pageCatalog()
      .map(item => {
        const haystack = `${item.name} ${item.category} ${(item.keywords || []).join(" ")} ${siteDomain(item.url)}`;
        const score = Math.max(
          fuzzyScore(item.name, q),
          fuzzyScore(item.category, q) - 40,
          fuzzyScore(siteDomain(item.url), q) - 20,
          fuzzyScore(haystack, q) - 80
        );
        return { ...item, type: item.url.endsWith(".html") ? "page" : "site", reason: "Catalog match", score };
      })
      .filter(item => item.score > 0);

    const merged = [...intentResults(query), ...recentResults(query), ...results];
    const seen = new Set();
    return merged
      .filter(item => {
        const key = `${normalize(item.name)}|${item.url}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      .slice(0, limit);
  }

  function rememberSearch(query) {
    const clean = String(query || "").trim();
    if (!clean) return;
    const next = [{ query: clean, at: Date.now() }, ...read(STORE.recent, []).filter(item => normalize(item.query) !== normalize(clean))].slice(0, 12);
    write(STORE.recent, next);
  }

  function isFavorite(url) {
    return read(STORE.favorites, []).some(item => item.url === url);
  }

  function toggleFavorite(item) {
    const list = read(STORE.favorites, []);
    const next = isFavorite(item.url)
      ? list.filter(saved => saved.url !== item.url)
      : [{ name: item.name, url: item.url, category: item.category, at: Date.now() }, ...list].slice(0, 30);
    write(STORE.favorites, next);
  }

  function openResult(item, query) {
    if (!item) return;
    rememberSearch(query || item.name);
    if (typeof window.recordSmartVisit === "function" && item.type !== "recent") {
      window.recordSmartVisit({ name: item.name, url: item.url, category: item.category });
    }
    window.location.href = item.url;
  }

  function renderSearch() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    if (!input || !box) return;

    const query = input.value.trim();
    activeIndex = -1;
    box.setAttribute("role", "listbox");
    box.setAttribute("aria-label", "Search suggestions");
    box.classList.add("wc-launch-search");
    box.innerHTML = "";

    if (!query) {
      activeResults = [];
      const recent = read(STORE.recent, []).slice(0, 4);
      box.innerHTML = `
        <div class="wc-search-empty">
          <strong>Start with a task, tool, or category</strong>
          <span>Try Instagram, ChatGPT, jobs, scholarships, Python, government services, finance, or shopping.</span>
          <div class="wc-search-chips">
            ${["ChatGPT", "Instagram", "Jobs", "Scholarships", "Python", "Govt Services"].map(item => `<button type="button" data-query="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join("")}
          </div>
          ${recent.length ? `<small>Recent: ${recent.map(item => escapeHtml(item.query)).join(", ")}</small>` : ""}
        </div>
      `;
      box.style.display = "grid";
      wireSearchBox();
      return;
    }

    box.innerHTML = `<div class="wc-search-loading"><span></span>Ranking the best matches...</div>`;
    box.style.display = "grid";

    window.clearTimeout(renderSearch.timer);
    renderSearch.timer = window.setTimeout(() => {
      activeResults = rankedResults(query, 10);
      if (!activeResults.length) {
        box.innerHTML = `
          <div class="wc-search-empty">
            <strong>No clean match found</strong>
            <span>Check the spelling or run a web search for this exact phrase.</span>
            <button type="button" data-open="https://www.google.com/search?q=${encodeURIComponent(query)}">Search Google for "${escapeHtml(query)}"</button>
          </div>
        `;
        wireSearchBox();
        return;
      }

      box.innerHTML = activeResults.map((item, index) => `
        <button class="suggestion-item wc-launch-result" type="button" role="option" data-index="${index}" data-open="${escapeHtml(item.url)}">
          <span class="suggestion-icon"><i class="fas ${item.type === "page" ? "fa-file-lines" : item.type === "recent" ? "fa-clock" : "fa-globe"}"></i></span>
          <span class="suggestion-copy">
            <strong>${highlight(item.name, query)}</strong>
            <small>${escapeHtml(item.category)} - ${escapeHtml(item.reason)} - ${escapeHtml(siteDomain(item.url))}</small>
          </span>
          <span class="suggestion-action">${item.url.endsWith(".html") ? "Open page" : "Open"}</span>
          ${item.type !== "recent" ? `<span class="suggestion-fav" data-fav="${index}" aria-label="Save result">${isFavorite(item.url) ? "Saved" : "Save"}</span>` : ""}
        </button>
      `).join("");
      wireSearchBox();
    }, 120);
  }

  function highlight(text, query) {
    const safe = escapeHtml(text);
    const q = String(query || "").trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return q ? safe.replace(new RegExp(`(${q})`, "ig"), "<mark>$1</mark>") : safe;
  }

  function wireSearchBox() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    if (!input || !box) return;
    box.onclick = event => {
      const fav = event.target.closest("[data-fav]");
      if (fav) {
        event.preventDefault();
        event.stopPropagation();
        const item = activeResults[Number(fav.dataset.fav)];
        if (item) {
          toggleFavorite(item);
          fav.textContent = isFavorite(item.url) ? "Saved" : "Save";
        }
        return;
      }
      const query = event.target.closest("[data-query]")?.dataset.query;
      if (query) {
        input.value = query;
        input.focus();
        renderSearch();
        return;
      }
      const row = event.target.closest("[data-index]");
      if (row) {
        openResult(activeResults[Number(row.dataset.index)], input.value);
        return;
      }
      const url = event.target.closest("[data-open]")?.dataset.open;
      if (url) openResult({ name: input.value, url, category: "Web search", type: "google" }, input.value);
    };
  }

  function moveActive(next) {
    const rows = $$("#suggestionBox .wc-launch-result");
    if (!rows.length) return;
    activeIndex = (next + rows.length) % rows.length;
    rows.forEach((row, index) => {
      row.classList.toggle("active", index === activeIndex);
      row.setAttribute("aria-selected", String(index === activeIndex));
    });
    rows[activeIndex].scrollIntoView({ block: "nearest" });
  }

  function installSearch() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    if (!input || !box) return;
    input.removeAttribute("onkeyup");
    input.removeAttribute("onkeypress");
    input.setAttribute("autocomplete", "off");
    input.setAttribute("aria-autocomplete", "list");
    input.setAttribute("aria-controls", "suggestionBox");
    window.showSuggestions = renderSearch;
    window.searchWebsite = function () {
      const query = input.value.trim();
      if (!query) return;
      openResult(activeIndex >= 0 ? activeResults[activeIndex] : (rankedResults(query, 1)[0] || {
        name: query,
        url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
        category: "Web search",
        type: "google"
      }), query);
    };
    input.addEventListener("input", renderSearch);
    input.addEventListener("focus", renderSearch);
    input.addEventListener("keydown", event => {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        moveActive(activeIndex + 1);
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        moveActive(activeIndex - 1);
      } else if (event.key === "Enter") {
        event.preventDefault();
        window.searchWebsite();
      } else if (event.key === "Escape") {
        box.style.display = "none";
      }
    });
    document.addEventListener("click", event => {
      if (!event.target.closest(".search-wrapper")) box.style.display = "none";
    });
  }

  function removeFakeSignals() {
    const count = pageCatalog().length;
    const categoryCount = new Set(pageCatalog().map(item => item.category).filter(Boolean)).size;
    const proof = $$(".hero-proof span");
    if (proof[0]) proof[0].innerHTML = `<strong>${count}</strong> catalog entries`;
    if (proof[1]) proof[1].innerHTML = `<strong>${categoryCount}</strong> resource groups`;
    if (proof[2]) proof[2].innerHTML = `<strong>Intent</strong> ranked search`;
    if (proof[3]) proof[3].innerHTML = `<strong id="heroLiveClock">Local</strong> saved history`;
    $$(".wc-stat-badge, .wc-card-badges, .wc-result-badges, .premium-badge, .badge").forEach(node => node.remove());
    $$(".home-priority small, .hero-ai-card small").forEach(node => {
      node.textContent = node.textContent.replace(/100\+|1000\+|500\+|1K\+/g, "curated");
    });
  }

  function simplifyFooter() {
    const footer = $(".footer");
    if (!footer) return;
    const year = new Date().getFullYear();
    footer.classList.remove("wc-launch-footer");
    footer.classList.add("wc-simple-footer");
    $("#footerParticles", footer)?.remove();
    $(".supported-rail", footer)?.remove();
    $(".footer-stats", footer)?.remove();
    $$(".footer-bottom-bar", footer).forEach(node => node.remove());
    const bottom = $(".footer-bottom", footer);
    if (bottom) bottom.innerHTML = `Copyright ${year} WebConnect 2.0. All rights reserved.`;
  }

  function removeVisualClutter() {
    $$("#wcPreviewBubble, #wcQuickActions, #wcBackToTop, #wcHeroCategoryPills, #wcFavoritesSection, #wcDailyUpgrade, #wcSearchFilters, .quick-dock, #journeyDock, .wc-preview-bubble").forEach(node => node.remove());
    $$("[data-preview-url]").forEach(node => node.removeAttribute("data-preview-url"));
  }

  function hardenLinksAndMedia() {
    $$("a[target='_blank']").forEach(link => {
      const rel = new Set((link.getAttribute("rel") || "").split(/\s+/).filter(Boolean));
      rel.add("noopener");
      rel.add("noreferrer");
      link.setAttribute("rel", [...rel].join(" "));
    });
    $$("img").forEach(img => {
      if (!img.hasAttribute("loading")) img.loading = "lazy";
      img.decoding = "async";
      if (!img.alt && !img.closest(".supported-rail")) img.alt = "";
    });
  }

  function installChatPolish() {
    const chat = $("#chat-container");
    if (!chat) return;
    chat.classList.add("wc-launch-chat");
    const status = $("#chatStatus") || $(".chat-subtitle");
    if (status) status.textContent = "Context-aware local assistant";
    const observerTarget = $("#chat-messages");
    if (observerTarget && !observerTarget.dataset.launchObserver) {
      observerTarget.dataset.launchObserver = "true";
      new MutationObserver(() => {
        observerTarget.scrollTop = observerTarget.scrollHeight;
        $$("#chat-container a[target='_blank']").forEach(link => link.setAttribute("rel", "noopener noreferrer"));
      }).observe(observerTarget, { childList: true, subtree: true });
    }
  }

  function init() {
    document.documentElement.classList.add("wc-launch-ready");
    installSearch();
    removeFakeSignals();
    simplifyFooter();
    removeVisualClutter();
    hardenLinksAndMedia();
    installChatPolish();
    window.setTimeout(() => {
      removeFakeSignals();
      removeVisualClutter();
    }, 700);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
