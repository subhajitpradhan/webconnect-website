/* =========================================================
   WEBCONNECT 2.0 — SERVICE WORKER
   Adds offline support and faster repeat loads on top of the
   existing site. Registered from page-enhancer.js on every page;
   this file always resolves to the site root, so its scope is "/".
   ========================================================= */

const CACHE_VERSION = "wc-cache-v1";
const OFFLINE_URL = "/offline.html";

// A small, safe set of assets shared by (almost) every page.
// Individual category pages are cached on the fly as people visit them
// (see the fetch handler below), so this list is intentionally short.
const CORE_ASSETS = [
  "/",
  "/index.html",
  "/style.css",
  "/script.js",
  "/page-enhancer.js",
  "/premium-chatbot.js",
  "/webconnect-pro-upgrade.js",
  "/webconnect-launch.js",
  "/webconnect-product.js",
  "/websites.js",
  "/logo.svg",
  "/logo.png",
  "/offline.html",
  "/manifest.webmanifest"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .catch(() => null) // never block install on one missing asset
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_VERSION)
          .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;

  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // never cache cross-origin (CDN/Firebase) traffic

  // Page navigations: try the network first (so content stays fresh),
  // fall back to cache, then to the offline page as a last resort.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy)).catch(() => null);
          return response;
        })
        .catch(() =>
          caches.match(request).then((cached) => cached || caches.match(OFFLINE_URL))
        )
    );
    return;
  }

  // Static assets (css/js/images/fonts): cache-first, update in the background.
  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy)).catch(() => null);
          }
          return response;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
