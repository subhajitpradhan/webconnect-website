/* =========================================================
   WEBCONNECT 2.0 — PAGE ENHANCER
   Corporate / Premium / Responsive Edition
   ========================================================= */

(function () {
  "use strict";

  /* =========================================================
     01 — GLOBAL NAVIGATION
     ========================================================= */

  window.toggleMenu = function () {
    const nav =
      document.getElementById("navbar") ||
      document.getElementById("navMenu") ||
      document.querySelector("header nav");

    if (!nav) return;
    nav.classList.toggle("active");
  };

  document.addEventListener("click", function (event) {
    const nav =
      document.getElementById("navbar") ||
      document.getElementById("navMenu") ||
      document.querySelector("header nav");

    const toggle = document.querySelector(".menu-toggle");

    if (!nav || !toggle || !nav.classList.contains("active")) return;

    if (nav.contains(event.target) || toggle.contains(event.target)) return;

    nav.classList.remove("active");
  });


  /* =========================================================
     02 — FIREBASE CONFIG
     ========================================================= */

  const FIREBASE_CONFIG = {
    apiKey: "AIzaSyDSm0RTj_-tvldd0WvL8n13hTYRQPaqN0Q",
    authDomain: "webconnect-c3fa0.firebaseapp.com",
    projectId: "webconnect-c3fa0",
    storageBucket: "webconnect-c3fa0.firebasestorage.app",
    messagingSenderId: "939049509561",
    appId: "1:939049509561:web:d66398762d6c6c0e427168",
    measurementId: "G-MPWM1BG4E7"
  };


  /* =========================================================
     03 — ROOT PATH
     ========================================================= */

  const enhancerSrc =
    document.currentScript?.getAttribute("src") || "";

  const root = enhancerSrc.startsWith("../") ? "../" : "";


  /* =========================================================
     04 — PREMIUM INTERNAL CSS
     ========================================================= */

  function injectCorporateStyles() {

    if (document.getElementById("wc-corporate-styles")) return;

    const style = document.createElement("style");
    style.id = "wc-corporate-styles";

    style.textContent = `

    /* =========================================
       CORPORATE STATIC PAGE SYSTEM
       ========================================= */

    .wc-corporate-page .page-section {
      max-width: 1240px !important;
      margin: 0 auto !important;
      padding: 54px 24px 90px !important;
    }

    .wc-corporate-page .wc-page-hero {
      position: relative;
      display: grid;
      grid-template-columns: minmax(0, 1fr) 300px;
      gap: 34px;
      align-items: stretch;

      padding: 58px 58px;

      border-radius: 34px;

      background:
        radial-gradient(
          circle at 0% 0%,
          rgba(34,197,94,.10),
          transparent 34%
        ),
        radial-gradient(
          circle at 100% 100%,
          rgba(59,130,246,.10),
          transparent 38%
        ),
        rgba(255,255,255,.88);

      border: 1px solid rgba(255,255,255,.85);

      box-shadow:
        0 30px 70px rgba(30,64,175,.10),
        0 8px 28px rgba(15,23,42,.06);

      overflow: hidden;
    }

    .wc-corporate-page .wc-page-hero::before {
      content: "";
      position: absolute;
      width: 240px;
      height: 240px;
      border-radius: 50%;
      background: rgba(34,197,94,.08);
      top: -125px;
      left: -80px;
      pointer-events: none;
    }

    .wc-corporate-page .wc-page-hero-copy {
      position: relative;
      z-index: 2;
    }

    .wc-corporate-page .wc-kicker {
      display: inline-flex;
      align-items: center;
      gap: 8px;

      padding: 11px 17px;

      border-radius: 999px;

      background: rgba(16,185,129,.09);
      border: 1px solid rgba(16,185,129,.16);

      color: #059669;

      font-size: 13px;
      font-weight: 800;

      letter-spacing: .05em;
      text-transform: uppercase;
    }

    .wc-corporate-page .wc-page-hero h2 {
      margin: 25px 0 16px;

      font-size: clamp(42px, 5vw, 70px);
      line-height: 1.02;

      letter-spacing: -2.8px;

      color: #102033;

      max-width: 900px;
    }

    .wc-corporate-page .wc-page-hero h2::after {
      content: ".";
      color: #1689d7;
    }

    .wc-corporate-page .wc-page-hero p {
      max-width: 820px;

      margin: 0;

      font-size: 18px;
      line-height: 1.85;

      color: #607795;
    }

    .wc-corporate-page .wc-chip-row {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;

      margin-top: 26px;
    }

    .wc-corporate-page .wc-chip-row span {
      display: inline-flex;
      align-items: center;

      padding: 10px 15px;

      border-radius: 999px;

      background: #f5f9fd;

      border: 1px solid #e4edf6;

      color: #294562;

      font-size: 13px;
      font-weight: 700;
    }

    .wc-corporate-page .wc-hero-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;

      margin-top: 30px;
    }

    .wc-corporate-page .wc-hero-actions button {
      border: 0;
      cursor: pointer;

      padding: 14px 21px;

      border-radius: 999px;

      font-weight: 800;
      font-size: 14px;

      transition:
        transform .25s ease,
        box-shadow .25s ease;
    }

    .wc-corporate-page .wc-hero-actions button:first-child {
      color: white;

      background:
        linear-gradient(
          135deg,
          #10a98b,
          #1689df
        );

      box-shadow:
        0 12px 28px rgba(16,169,139,.22);
    }

    .wc-corporate-page .wc-hero-actions button:last-child {
      background: white;

      color: #203a57;

      border: 1px solid #dfe9f3;
    }

    .wc-corporate-page .wc-hero-actions button:hover {
      transform: translateY(-3px);
    }


    /* =========================================
       HERO SIDE PANEL
       ========================================= */

    .wc-corporate-page .wc-page-hero-panel {
      position: relative;
      z-index: 2;

      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;

      min-height: 300px;

      padding: 30px;

      text-align: center;

      border-radius: 28px;

      background:
        linear-gradient(
          145deg,
          rgba(255,255,255,.96),
          rgba(247,252,255,.90)
        );

      border: 1px solid #e7eef5;

      box-shadow:
        0 20px 45px rgba(32,64,96,.09);
    }

    .wc-corporate-page .wc-page-hero-panel strong {
      display: block;

      font-size: 45px;
      line-height: 1;

      font-weight: 900;

      background:
        linear-gradient(
          135deg,
          #0e9f78,
          #2388df
        );

      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
    }

    .wc-corporate-page .wc-page-hero-panel span {
      margin-top: 12px;

      color: #5d7188;

      font-weight: 800;
      font-size: 15px;
    }


    /* =========================================
       CORPORATE STATIC CARDS
       ========================================= */

    .wc-corporate-page .about-card,
    .wc-corporate-page .wc-static-card {

      position: relative;

      margin-top: 24px;

      padding: 32px 34px;

      border-radius: 24px;

      background:
        linear-gradient(
          145deg,
          rgba(255,255,255,.96),
          rgba(249,252,255,.94)
        );

      border: 1px solid rgba(225,234,243,.9);

      box-shadow:
        0 18px 45px rgba(37,73,107,.07);

      overflow: hidden;

      transition:
        transform .3s ease,
        box-shadow .3s ease,
        border-color .3s ease;
    }

    .wc-corporate-page .about-card::before,
    .wc-corporate-page .wc-static-card::before {

      content: "";

      position: absolute;

      top: 0;
      left: 0;

      width: 5px;
      height: 100%;

      background:
        linear-gradient(
          180deg,
          #0fa987,
          #258de0
        );

      opacity: .85;
    }

    .wc-corporate-page .about-card:hover,
    .wc-corporate-page .wc-static-card:hover {

      transform: translateY(-5px);

      border-color: rgba(22,137,215,.20);

      box-shadow:
        0 26px 55px rgba(37,73,107,.11);
    }

    .wc-corporate-page .about-card h3,
    .wc-corporate-page .wc-static-card h3 {

      margin: 0 0 12px;

      color: #13253a;

      font-size: 21px;

      letter-spacing: -.3px;
    }

    .wc-corporate-page .about-card p,
    .wc-corporate-page .wc-static-card p {

      color: #647a92;

      font-size: 15.5px;

      line-height: 1.8;

      margin: 8px 0;
    }

    .wc-corporate-page .wc-card-number {

      position: absolute;

      top: 22px;
      right: 25px;

      display: flex;
      align-items: center;
      justify-content: center;

      width: 42px;
      height: 42px;

      border-radius: 50%;

      background: #f1f7fb;

      color: #1689d7;

      font-size: 12px;
      font-weight: 900;

      border: 1px solid #e2edf5;
    }


    /* =========================================
       CORPORATE SUPPORT / INSIGHT BLOCK
       ========================================= */

    .wc-corporate-page .wc-corporate-strip {

      display: grid;

      grid-template-columns:
        repeat(3, minmax(0, 1fr));

      gap: 18px;

      margin-top: 34px;
    }

    .wc-corporate-page .wc-corporate-strip article {

      padding: 25px;

      border-radius: 22px;

      background:
        rgba(255,255,255,.86);

      border: 1px solid #e5edf5;

      box-shadow:
        0 14px 35px rgba(40,70,100,.06);
    }

    .wc-corporate-page .wc-corporate-strip span {

      display: block;

      margin-bottom: 9px;

      color: #059669;

      font-size: 11px;

      font-weight: 900;

      text-transform: uppercase;

      letter-spacing: .12em;
    }

    .wc-corporate-page .wc-corporate-strip strong {

      display: block;

      color: #16283d;

      font-size: 18px;
    }

    .wc-corporate-page .wc-corporate-strip p {

      margin: 8px 0 0;

      color: #70839a;

      line-height: 1.65;

      font-size: 14px;
    }


    /* =========================================
       CATEGORY / RESOURCE CARDS
       ========================================= */

    .wc-directory-page .wc-enriched {

      position: relative;

      display: flex;
      flex-direction: column;

      min-height: 220px;

      padding: 24px !important;

      border-radius: 22px !important;

      background:
        linear-gradient(
          145deg,
          rgba(255,255,255,.96),
          rgba(248,252,255,.94)
        ) !important;

      border: 1px solid #e2ebf4 !important;

      box-shadow:
        0 14px 34px rgba(31,66,101,.07) !important;

      transition:
        transform .28s ease,
        box-shadow .28s ease,
        border-color .28s ease;
    }

    .wc-directory-page .wc-enriched:hover {

      transform: translateY(-6px);

      border-color: rgba(22,137,215,.22) !important;

      box-shadow:
        0 24px 48px rgba(31,66,101,.12) !important;
    }

    .wc-directory-page .wc-card-icon {

      width: 48px;
      height: 48px;

      display: flex;

      align-items: center;
      justify-content: center;

      border-radius: 15px;

      background: #f2f8fc;

      border: 1px solid #e4edf5;

      margin-bottom: 17px;
    }

    .wc-directory-page .wc-site-icon img {

      width: 28px;
      height: 28px;

      object-fit: contain;
    }

    .wc-directory-page .wc-enriched strong {

      font-size: 18px;

      color: #14283e;

      line-height: 1.3;
    }

    .wc-directory-page .wc-enriched small {

      margin-top: 6px;

      color: #1689d7;

      font-size: 12px;

      font-weight: 700;
    }

    .wc-directory-page .wc-enriched p {

      margin-top: 13px;

      color: #71859b;

      font-size: 13.5px;

      line-height: 1.65;
    }

    .wc-directory-page .wc-enriched::after {

      content: "↗";

      position: absolute;

      right: 20px;
      top: 20px;

      width: 31px;
      height: 31px;

      display: flex;

      align-items: center;
      justify-content: center;

      border-radius: 50%;

      background: #f2f8fc;

      color: #1689d7;

      font-weight: 900;
    }


    /* =========================================
       MOBILE
       ========================================= */

    @media (max-width: 900px) {

      .wc-corporate-page .wc-page-hero {

        grid-template-columns: 1fr;

        padding: 40px 30px;

      }

      .wc-corporate-page .wc-page-hero-panel {

        min-height: 190px;

      }

      .wc-corporate-page .wc-corporate-strip {

        grid-template-columns: 1fr;

      }

    }


    @media (max-width: 600px) {

      .wc-corporate-page .page-section {

        padding:
          28px 15px 65px !important;
      }

      .wc-corporate-page .wc-page-hero {

        padding: 30px 22px;

        border-radius: 25px;

        gap: 24px;
      }

      .wc-corporate-page .wc-page-hero h2 {

        font-size: 40px;

        letter-spacing: -1.7px;
      }

      .wc-corporate-page .wc-page-hero p {

        font-size: 15px;

        line-height: 1.7;
      }

      .wc-corporate-page .wc-page-hero-panel {

        min-height: 160px;

        border-radius: 22px;
      }

      .wc-corporate-page .wc-page-hero-panel strong {

        font-size: 38px;
      }

      .wc-corporate-page .about-card,
      .wc-corporate-page .wc-static-card {

        padding: 26px 24px;

        border-radius: 20px;
      }

      .wc-directory-page .wc-enriched {

        min-height: 190px;

        padding: 20px !important;

      }

    }

    `;

    document.head.appendChild(style);
  }


  /* =========================================================
     05 — HEADER NORMALIZATION
     ========================================================= */

  function normalizeHeaderBrand() {

    const header = document.querySelector("header");

    if (!header || header.dataset.wcBrandReady === "true") return;

    header.dataset.wcBrandReady = "true";

    const homeHref = `${root}index.html`;

    const currentBrand =
      header.querySelector(
        ".logo-box, .logo-link, .logo"
      );

    /*
      Creator page:
      Do not destroy existing creator header structure.
    */

    if (
      document.body.classList.contains(
        "creator-page"
      )
    ) {

      const creatorBrand =
        currentBrand?.closest?.("a") ||
        currentBrand;

      if (
        creatorBrand &&
        creatorBrand.tagName === "A"
      ) {

        creatorBrand.href = homeHref;

        creatorBrand.classList.add(
          "logo-link"
        );

        creatorBrand.setAttribute(
          "aria-label",
          "WebConnect 2.0 Home"
        );

        const logoText =
          creatorBrand.querySelector(".logo") ||
          creatorBrand;

        logoText.textContent =
          "WebConnect 2.0";
      }

      return;
    }

    /*
      Preserve already-correct logo.
    */

    if (
      currentBrand &&
      currentBrand.querySelector?.("img")
    ) {

      const anchor =
        currentBrand.closest("a") ||
        currentBrand;

      if (anchor.tagName === "A") {

        anchor.href = homeHref;

        anchor.setAttribute(
          "aria-label",
          "WebConnect 2.0 Home"
        );
      }

      return;
    }

    /*
      Build standard logo only when needed.
    */

    const brand =
      document.createElement("a");

    brand.href = homeHref;

    brand.className =
      "logo-box wc-site-brand";

    brand.setAttribute(
      "aria-label",
      "WebConnect 2.0 Home"
    );

    const existingImg =
      currentBrand?.querySelector?.("img");

    const imgSrc =
      existingImg?.getAttribute("src") ||
      `${root}logo.svg`;

    brand.innerHTML = `
      <img
        src="${imgSrc}"
        alt="WebConnect 2.0"
        class="logo"
        width="44"
        height="44"
      >

      <div class="logo-text">
        <span class="main-text">
          WebConnect <b>2.0</b>
        </span>
      </div>
    `;

    if (currentBrand) {

      currentBrand.replaceWith(brand);

    } else {

      header.insertBefore(
        brand,
        header.firstElementChild
      );
    }

    header
      .querySelectorAll(
        'nav a[href$="index.html"], nav a[href="index.html"], nav a[href="../index.html"]'
      )
      .forEach(link => {

        link.href = homeHref;

      });
  }


  /* =========================================================
     06 — PAGE PROFILES
     ========================================================= */

  const pageProfiles = {

    "ai.html": {
      label: "AI Lab",
      description:
        "Explore practical AI tools, assistants, creative platforms, research resources, and automation services gathered into one focused discovery experience.",
      icon: "🤖",
      chips: [
        "AI Tools",
        "Automation",
        "Research",
        "Creative"
      ]
    },

    "jobs.html": {
      label: "Career Desk",
      description:
        "Discover job platforms, internships, company career pages, freelance opportunities, remote work resources, and practical career tools.",
      icon: "💼",
      chips: [
        "Jobs",
        "Internships",
        "Remote",
        "Career"
      ]
    },

    "education.html": {
      label: "Learning Desk",
      description:
        "Find courses, tutorials, examinations, certifications, practice platforms, study resources, and learning tools in one organized destination.",
      icon: "🎓",
      chips: [
        "Courses",
        "Exams",
        "Practice",
        "Skills"
      ]
    },

    "developer.html": {
      label: "Developer Stack",
      description:
        "A focused collection of coding platforms, documentation, APIs, cloud services, testing tools, open-source resources, and developer utilities.",
      icon: "💻",
      chips: [
        "Coding",
        "Docs",
        "APIs",
        "Cloud"
      ]
    },

    "shopping.html": {
      label: "Shopping Finder",
      description:
        "Explore shopping, fashion, electronics, deals, daily essentials, product discovery, and useful commerce platforms from one organized place.",
      icon: "🛒",
      chips: [
        "Shopping",
        "Deals",
        "Fashion",
        "Electronics"
      ]
    },

    "news.html": {
      label: "News Desk",
      description:
        "Discover trusted news and information platforms covering current affairs, business, technology, world events, culture, and everyday updates.",
      icon: "📰",
      chips: [
        "Current Affairs",
        "Business",
        "Technology",
        "World"
      ]
    },

    "resources/updates.html": {
      label: "Release Notes",
      description:
        "Explore WebConnect improvements, interface upgrades, category additions, usability refinements, fixes, and ongoing product development.",
      icon: "✨",
      chips: [
        "New",
        "Improved",
        "Fixed",
        "Planned"
      ]
    },

    "resources/help.html": {
      label: "Help Center",
      description:
        "Find practical guidance for searching, browsing categories, reporting problems, understanding resources, using WebConnect, and staying safe online.",
      icon: "❔",
      chips: [
        "Search",
        "Guidance",
        "Support",
        "Safety"
      ]
    },

    "resources/privacy.html": {
      label: "Privacy Overview",
      description:
        "Understand the privacy principles behind WebConnect, including forms, analytics, external websites, account features, and user choices.",
      icon: "🔐",
      chips: [
        "Privacy",
        "Control",
        "Analytics",
        "Transparency"
      ]
    },

    "resources/terms.html": {
      label: "Use Policy",
      description:
        "Review the basic terms and responsible-use principles that help keep WebConnect useful, respectful, transparent, and practical.",
      icon: "📜",
      chips: [
        "Fair Use",
        "Accuracy",
        "External Sites",
        "Updates"
      ]
    },

    "more.html": {
      label: "Mega Resource Map",
      description:
        "Explore a broader collection of useful internet destinations spanning education, career, technology, finance, business, government, creativity, travel, and daily tools.",
      icon: "🧭",
      chips: [
        "Career",
        "Learning",
        "Technology",
        "Daily Tools"
      ]
    },

    "creator/creator.html": {
      label: "Creator Studio",
      description:
        "Discover the people, learning journey, project work, ideas, principles, and long-term vision behind WebConnect 2.0.",
      icon: "🚀",
      chips: [
        "Story",
        "Creators",
        "Projects",
        "Vision"
      ]
    },

    "creator/projects.html": {
      label: "Projects Showcase",
      description:
        "A curated showcase of practical digital projects created through learning, experimentation, problem solving, and continuous improvement.",
      icon: "🧩",
      chips: [
        "Projects",
        "Build",
        "Design",
        "Innovation"
      ]
    },

    "creator/learning.html": {
      label: "Learning Journey",
      description:
        "A transparent journey through learning, experimentation, projects, technical growth, and the consistent effort behind each stage of development.",
      icon: "📚",
      chips: [
        "Learning",
        "Practice",
        "Projects",
        "Growth"
      ]
    },

    "creator/feedback.html": {
      label: "Feedback",
      description:
        "Share suggestions, corrections, ideas, and practical feedback that can help make WebConnect more useful, clearer, and easier to navigate.",
      icon: "💬",
      chips: [
        "Feedback",
        "Ideas",
        "Suggestions",
        "Improvement"
      ]
    }

  };


  /* =========================================================
     07 — PATH HELPERS
     ========================================================= */

  function pathKey() {

    return location.pathname
      .replace(/\\/g, "/")
      .split("/")
      .slice(-2)
      .join("/")
      .replace(
        /^webconnect2\.0\//,
        ""
      );
  }


  function pageCandidates() {

    const key = pathKey();

    const one =
      key.split("/").pop();

    return [
      key,
      one
    ].filter(Boolean);
  }


  /* =========================================================
     08 — FALLBACK PROFILE
     ========================================================= */

  function fallbackProfile(title) {

    const clean =
      title
        .replace(
          /\s*\|\s*WebConnect.*$/i,
          ""
        )
        .replace(
          /\s*-\s*WebConnect.*$/i,
          ""
        )
        .trim() ||
      "WebConnect";

    return {

      label: clean,

      description:
        `Explore the ${clean.toLowerCase()} experience through a clear, organized, and practical WebConnect interface.`,

      icon: "🌐",

      chips: [
        "Curated",
        "Useful",
        "Accessible",
        "Updated"
      ]
    };
  }


  function currentProfile() {

    const key = pathKey();

    const one =
      key.split("/").pop();

    return (
      pageProfiles[key] ||
      pageProfiles[one] ||
      fallbackProfile(
        document.title
      )
    );
  }


  /* =========================================================
     09 — DETECT PAGE TYPE
     ========================================================= */

  function isDirectoryPage(section) {

    if (!section) return false;

    /*
      A real resource/category page has
      .grid .card links.

      Static corporate pages use .about-card.
    */

    return !!section.querySelector(
      ".grid .card"
    );
  }


  /* =========================================================
     10 — HERO
     ========================================================= */

  function createHero(
    section,
    profile,
    count,
    corporateMode
  ) {

    if (
      section.querySelector(
        ".wc-page-hero"
      )
    ) return;

    const title =
      section.querySelector("h1");

    const hero =
      document.createElement("div");

    hero.className =
      "wc-page-hero";

    hero.innerHTML = `

      <div class="wc-page-hero-copy">

        <span class="wc-kicker">
          ${profile.icon}
          ${profile.label}
        </span>

        <h2>
          ${
            title
              ? title.textContent.trim()
              : profile.label
          }
        </h2>

        <p>
          ${profile.description}
        </p>

        <div class="wc-chip-row">

          ${profile.chips
            .map(
              chip =>
                `<span>${chip}</span>`
            )
            .join("")}

        </div>

        <div class="wc-hero-actions">

          <button
            type="button"
            data-wc-focus-search
          >
            ${
              corporateMode
                ? "Explore Page"
                : "Search Page"
            }
          </button>

          <button
            type="button"
            data-wc-open-first
          >
            ${
              corporateMode
                ? "Start Exploring"
                : "Open Top Pick"
            }
          </button>

        </div>

      </div>

      <div class="wc-page-hero-panel">

        <strong>
          ${
            count
              ? count + "+"
              : "Smart+"
          }
        </strong>

        <span>
          ${
            count
              ? "resources listed"
              : "resource paths"
          }
        </span>

      </div>

    `;

    if (title) {

      title.style.display =
        "none";
    }

    section.insertBefore(
      hero,
      section.firstElementChild
    );
  }


  /* =========================================================
     11 — DIRECTORY TOOLBAR
     ========================================================= */

  function insertBeforeGrid(
    section,
    node,
    grid,
    fallback
  ) {

    if (grid?.parentElement) {

      grid.parentElement.insertBefore(
        node,
        grid
      );

      return;
    }

    const safeFallback =
      fallback &&
      fallback.parentElement === section
        ? fallback
        : null;

    section.insertBefore(
      node,
      safeFallback
    );
  }


  function addToolbar(
    section,
    cards
  ) {

    if (
      !cards.length ||
      section.querySelector(
        ".wc-page-toolbar"
      )
    ) return;

    const toolbar =
      document.createElement("div");

    toolbar.className =
      "wc-page-toolbar";

    toolbar.innerHTML = `

      <input
        type="search"
        placeholder="Search this page..."
        aria-label="Search this page"
      >

      <button
        type="button"
        data-filter="all"
        class="active"
      >
        All
      </button>

      <button
        type="button"
        data-filter="popular"
      >
        Popular
      </button>

      <button
        type="button"
        data-filter="external"
      >
        Websites
      </button>

      <button
        type="button"
        data-filter="page"
      >
        Pages
      </button>

    `;

    const grid =
      section.querySelector(".grid");

    insertBeforeGrid(
      section,
      toolbar,
      grid,
      section.children[1] || null
    );

    const input =
      toolbar.querySelector("input");

    const buttons =
      [
        ...toolbar.querySelectorAll(
          "button"
        )
      ];

    let activeFilter = "all";

    function applyFilter() {

      const query =
        input.value
          .toLowerCase()
          .trim();

      cards.forEach(
        (card, index) => {

          const href =
            card.getAttribute(
              "href"
            ) || "";

          const text =
            card.textContent
              .toLowerCase();

          const isPage =
            href.includes(".html");

          const matchText =
            !query ||
            text.includes(query) ||
            href
              .toLowerCase()
              .includes(query);

          const matchFilter =
            activeFilter === "all" ||
            (
              activeFilter ===
              "popular" &&
              index < 12
            ) ||
            (
              activeFilter ===
              "external" &&
              !isPage
            ) ||
            (
              activeFilter ===
              "page" &&
              isPage
            );

          card.classList.toggle(
            "wc-hidden",
            !(
              matchText &&
              matchFilter
            )
          );

        }
      );
    }

    input.addEventListener(
      "input",
      applyFilter
    );

    buttons.forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            activeFilter =
              button.dataset.filter;

            buttons.forEach(
              btn =>
                btn.classList.toggle(
                  "active",
                  btn === button
                )
            );

            applyFilter();
          }
        );

      }
    );
  }


  /* =========================================================
     12 — DIRECTORY COMMAND DOCK
     ========================================================= */

  function addCommandDock(
    section,
    cards,
    profile
  ) {

    if (
      !cards.length ||
      section.querySelector(
        ".wc-command-dock"
      )
    ) return;

    const dock =
      document.createElement("div");

    dock.className =
      "wc-command-dock";

    dock.innerHTML = `

      <div>

        <span>
          Smart Web Route
        </span>

        <strong>
          ${profile.label}
          organized for faster discovery
        </strong>

      </div>

      <button
        type="button"
        data-wc-filter-popular
      >
        Top Picks
      </button>

      <button
        type="button"
        data-wc-copy-page
      >
        Copy Page
      </button>

      <button
        type="button"
        data-wc-open-random
      >
        Surprise
      </button>

    `;

    const grid =
      section.querySelector(".grid");

    insertBeforeGrid(
      section,
      dock,
      grid,
      section.children[1] || null
    );


    dock
      .querySelector(
        "[data-wc-filter-popular]"
      )
      ?.addEventListener(
        "click",
        () => {

          section
            .querySelector(
              '.wc-page-toolbar button[data-filter="popular"]'
            )
            ?.click();

          section
            .querySelector(
              ".wc-page-toolbar"
            )
            ?.scrollIntoView({
              behavior: "smooth",
              block: "center"
            });
        }
      );


    dock
      .querySelector(
        "[data-wc-copy-page]"
      )
      ?.addEventListener(
        "click",
        async () => {

          try {

            await navigator.clipboard.writeText(
              location.href
            );

            dock.classList.add(
              "copied"
            );

            setTimeout(
              () =>
                dock.classList.remove(
                  "copied"
                ),
              1400
            );

          } catch (error) {

            prompt(
              "Copy this page:",
              location.href
            );

          }

        }
      );


    dock
      .querySelector(
        "[data-wc-open-random]"
      )
      ?.addEventListener(
        "click",
        () => {

          const visible =
            cards.filter(
              card =>
                !card.classList.contains(
                  "wc-hidden"
                )
            );

          const item =
            visible[
              Math.floor(
                Math.random() *
                visible.length
              )
            ] ||
            cards[0];

          item?.click();

        }
      );
  }


  /* =========================================================
     13 — DIRECTORY CARD DESCRIPTIONS
     ========================================================= */

  function specificDescription(
    name,
    href,
    profile
  ) {

    const text =
      `${name} ${href}`.toLowerCase();

    const known = [

      [
        /chatgpt|claude|gemini|perplexity|poe|copilot/,
        "AI assistant for writing, research, coding support, summaries, ideas, and everyday productivity."
      ],

      [
        /midjourney|dall|stable|leonardo|runway|firefly|canva/,
        "Creative platform for visual design, images, video, branding, presentations, and content workflows."
      ],

      [
        /linkedin|naukri|indeed|glassdoor|internshala|wellfound|remote/,
        "Career platform for jobs, internships, remote opportunities, company discovery, and applications."
      ],

      [
        /coursera|udemy|edx|khan|nptel|swayam|unacademy|byju|codecademy/,
        "Learning platform for courses, practice, certifications, structured learning, and skill development."
      ],

      [
        /github|gitlab|stackoverflow|mdn|w3schools|freecodecamp|geeksforgeeks|leetcode/,
        "Developer resource for coding, documentation, debugging, practice, collaboration, and project building."
      ],

      [
        /amazon|flipkart|myntra|ajio|meesho|nykaa|ebay|etsy/,
        "Shopping platform for product discovery, comparisons, offers, fashion, electronics, and everyday needs."
      ],

      [
        /paytm|phonepe|zerodha|groww|upstox|razorpay/,
        "Digital finance platform for payments, investing, business services, or personal financial workflows."
      ],

      [
        /bbc|ndtv|reuters|hindu|times|guardian|bloomberg|al jazeera/,
        "News source for current affairs, business, world events, technology, and daily information."
      ],

      [
        /youtube|instagram|facebook|reddit|discord|telegram|pinterest|tiktok/,
        "Social and media platform for communities, creators, content, communication, learning, and updates."
      ],

      [
        /netflix|prime|hotstar|spotify|sony|zee5|twitch|steam|epic/,
        "Entertainment platform for streaming, music, games, shows, communities, and digital content."
      ],

      [
        /irctc|makemytrip|booking|skyscanner|goibibo|uber|ola|maps/,
        "Travel and navigation resource for routes, bookings, transport, places, and everyday movement."
      ],

      [
        /figma|dribbble|behance|uizard|framer|webflow/,
        "Design resource for interfaces, prototypes, creative inspiration, websites, and digital production."
      ]

    ];

    const match =
      known.find(
        ([pattern]) =>
          pattern.test(text)
      );

    if (match)
      return match[1];

    if (href.includes(".html"))
      return `${name} opens a focused WebConnect page with related resources and useful shortcuts.`;

    return `${name} is a useful ${profile.label.toLowerCase()} resource for focused discovery and everyday workflow.`;
  }


  /* =========================================================
     14 — ENRICH DIRECTORY CARDS
     ========================================================= */

  function enrichCards(
    cards,
    profile
  ) {

    cards.forEach(
      (card, index) => {

        if (
          card.classList.contains(
            "wc-enriched"
          )
        ) return;

        const href =
          card.getAttribute(
            "href"
          ) || "";

        const raw =
          card.textContent.trim();

        if (!raw) return;

        const domain =
          href.startsWith("http")
            ? href
                .replace(
                  /^https?:\/\//,
                  ""
                )
                .replace(
                  /^www\./,
                  ""
                )
                .split("/")[0]
            : href;

        card.classList.add(
          "wc-enriched"
        );

        card.dataset.smartTier =
          index < 8
            ? "top"
            : index < 24
              ? "strong"
              : "deep";

        let iconMarkup = "";

        if (
          href.startsWith("http")
        ) {

          iconMarkup = `

            <span
              class="wc-card-icon wc-site-icon"
            >

              <img
                src="https://www.google.com/s2/favicons?sz=64&domain=${domain}"
                alt=""
                loading="lazy"
              >

            </span>

          `;

        } else {

          iconMarkup = `

            <span
              class="wc-card-icon wc-page-icon"
            >
              📄
            </span>

          `;
        }

        card.innerHTML = `

          ${iconMarkup}

          <strong>
            ${raw}
          </strong>

          <small>
            ${domain}
          </small>

          <p>
            ${specificDescription(
              raw,
              href,
              profile
            )}
          </p>

        `;
      }
    );
  }


  /* =========================================================
     15 — DIRECTORY INSIGHT BAND
     ========================================================= */

  function addInsightBand(
    section,
    cards,
    profile
  ) {

    if (
      section.querySelector(
        ".wc-insight-band"
      )
    ) return;

    if (!cards.length) return;

    const band =
      document.createElement("div");

    band.className =
      "wc-insight-band";

    band.innerHTML = `

      <article>

        <span>
          BEST START
        </span>

        <strong>
          ${profile.chips[0] || "Explore"}
        </strong>

        <p>
          Start with the first curated resources
          to reach useful destinations faster.
        </p>

      </article>


      <article>

        <span>
          SMART TIP
        </span>

        <strong>
          Search inside page
        </strong>

        <p>
          Use the page search to quickly narrow
          down long resource collections.
        </p>

      </article>


      <article>

        <span>
          SAFETY NOTE
        </span>

        <strong>
          Verify official links
        </strong>

        <p>
          External websites may change.
          Always verify important information
          before sharing personal details.
        </p>

      </article>

    `;

    const grid =
      section.querySelector(
        ".grid"
      );

    insertBeforeGrid(
      section,
      band,
      grid,
      section.children[1] || null
    );
  }


  /* =========================================================
     16 — STATIC CORPORATE CARDS
     ========================================================= */

  function enhanceStaticCards(
    section
  ) {

    const cards =
      [
        ...section.querySelectorAll(
          ".about-card"
        )
      ];

    cards.forEach(
      (card, index) => {

        card.classList.add(
          "wc-static-card"
        );

        if (
          !card.querySelector(
            ".wc-card-number"
          )
        ) {

          const badge =
            document.createElement(
              "span"
            );

          badge.className =
            "wc-card-number";

          badge.textContent =
            String(index + 1)
              .padStart(2, "0");

          card.prepend(
            badge
          );
        }

      }
    );


    /*
      Add a polished closing strip
      only when there are static cards.
    */

    if (
      cards.length >= 2 &&
      !section.querySelector(
        ".wc-corporate-strip"
      )
    ) {

      const strip =
        document.createElement(
          "div"
        );

      strip.className =
        "wc-corporate-strip";

      strip.innerHTML = `

        <article>

          <span>
            BUILT WITH PURPOSE
          </span>

          <strong>
            Useful by design
          </strong>

          <p>
            Every section is structured to
            make information easier to understand
            and actions easier to take.
          </p>

        </article>


        <article>

          <span>
            USER FIRST
          </span>

          <strong>
            Clear. Practical. Accessible.
          </strong>

          <p>
            WebConnect focuses on reducing
            unnecessary searching and keeping
            important paths easy to discover.
          </p>

        </article>


        <article>

          <span>
            ALWAYS EVOLVING
          </span>

          <strong>
            Better with every iteration
          </strong>

          <p>
            Feedback, learning, testing and
            continuous improvement remain part
            of the WebConnect journey.
          </p>

        </article>

      `;

      section.appendChild(
        strip
      );
    }
  }


  /* =========================================================
     17 — SMART COLLECTIONS
     ========================================================= */

  function addSmartCollections(
    section,
    cards
  ) {

    if (
      !cards.length ||
      section.querySelector(
        ".wc-smart-collections"
      )
    ) return;

    const groups = [

      [
        "Fast Start",
        cards.slice(0, 4)
      ],

      [
        "Power Picks",
        cards.slice(4, 8)
      ],

      [
        "Explore More",
        cards.slice(8, 12)
      ]

    ].filter(
      ([, items]) =>
        items.length
    );

    if (!groups.length) return;

    const wrap =
      document.createElement(
        "div"
      );

    wrap.className =
      "wc-smart-collections";

    wrap.innerHTML =
      groups
        .map(
          ([title, items]) => `

            <article>

              <span>
                ${title}
              </span>

              ${items
                .map(
                  card => {

                    const href =
                      card.getAttribute(
                        "href"
                      ) || "#";

                    const text =
                      card.textContent.trim();

                    const target =
                      card.getAttribute(
                        "target"
                      ) || "";

                    return `

                      <a
                        href="${href}"
                        ${
                          target
                            ? `target="${target}" rel="noopener"`
                            : ""
                        }
                      >
                        ${text}
                      </a>

                    `;
                  }
                )
                .join("")}

            </article>

          `
        )
        .join("");

    const grid =
      section.querySelector(
        ".grid"
      );

    insertBeforeGrid(
      section,
      wrap,
      grid,
      section.children[1] || null
    );
  }


  /* =========================================================
     18 — HERO BUTTONS
     ========================================================= */

  function setupHeroActions(
    section,
    cards,
    corporateMode
  ) {

    const searchButton =
      section.querySelector(
        "[data-wc-focus-search]"
      );

    const firstButton =
      section.querySelector(
        "[data-wc-open-first]"
      );


    searchButton?.addEventListener(
      "click",
      () => {

        if (corporateMode) {

          const firstCard =
            section.querySelector(
              ".about-card"
            );

          firstCard?.scrollIntoView({
            behavior: "smooth",
            block: "center"
          });

          return;
        }

        const input =
          section.querySelector(
            ".wc-page-toolbar input"
          );

        if (input) {

          input.focus();

          input.scrollIntoView({
            behavior: "smooth",
            block: "center"
          });
        }
      }
    );


    firstButton?.addEventListener(
      "click",
      () => {

        if (corporateMode) {

          const firstCard =
            section.querySelector(
              ".about-card"
            );

          firstCard?.scrollIntoView({
            behavior: "smooth",
            block: "center"
          });

          return;
        }

        cards[0]?.click();

      }
    );
  }


  /* =========================================================
     19 — FIREBASE SCRIPT LOADER
     ========================================================= */

  function loadScript(src) {

    return new Promise(
      (resolve, reject) => {

        const existing =
          document.querySelector(
            `script[src="${src}"]`
          );

        if (existing) {

          if (
            existing.dataset.loaded ===
            "true"
          ) {

            resolve();

          } else {

            existing.addEventListener(
              "load",
              () => resolve(),
              { once: true }
            );

            existing.addEventListener(
              "error",
              () =>
                reject(
                  new Error(
                    `Failed to load ${src}`
                  )
                ),
              { once: true }
            );
          }

          return;
        }


        const script =
          document.createElement(
            "script"
          );

        script.src = src;

        script.async = true;

        script.onload = () => {

          script.dataset.loaded =
            "true";

          resolve();

        };

        script.onerror = () => {

          reject(
            new Error(
              `Failed to load ${src}`
            )
          );

        };

        document.head.appendChild(
          script
        );

      }
    );
  }


  /* =========================================================
     20 — FIREBASE
     ========================================================= */

  async function ensureFirebase() {

    try {

      if (
        typeof firebase ===
          "undefined" ||
        !firebase.firestore
      ) {

        await loadScript(
          "https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"
        );

        await loadScript(
          "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore-compat.js"
        );
      }


      if (
        typeof firebase ===
          "undefined" ||
        !firebase.firestore
      ) {

        return null;
      }


      if (!firebase.apps.length) {

        firebase.initializeApp(
          FIREBASE_CONFIG
        );
      }


      return firebase.firestore();

    } catch (error) {

      console.warn(
        "Firebase unavailable:",
        error
      );

      return null;
    }
  }


  /* =========================================================
     21 — CMS BLOCKS
     ========================================================= */

  function createCmsBlock(
    block
  ) {

    const wrap =
      document.createElement(
        "section"
      );

    wrap.className =
      "wc-cms-block";

    const cards =
      Array.isArray(block.cards)
        ? block.cards
        : [];

    wrap.innerHTML = `

      <h3>
        ${block.title || ""}
      </h3>

      <p>
        ${block.body || ""}
      </p>

      ${
        cards.length
          ? `
            <div class="wc-chip-row">

              ${cards
                .map(
                  card =>
                    `<span>${card}</span>`
                )
                .join("")}

            </div>
          `
          : ""
      }

    `;

    return wrap;
  }


  async function loadCmsBlocks(
    section
  ) {

    const db =
      await ensureFirebase();

    if (!db || !section) return;

    try {

      const keys =
        pageCandidates();

      const blocks = [];

      for (
        const key of keys
      ) {

        const snap =
          await db
            .collection(
              "page_content_blocks"
            )
            .where(
              "pageKey",
              "==",
              key
            )
            .where(
              "active",
              "==",
              true
            )
            .orderBy(
              "order",
              "asc"
            )
            .get();

        snap.docs.forEach(
          doc =>
            blocks.push({
              id: doc.id,
              ...doc.data()
            })
        );
      }


      if (!blocks.length)
        return;


      const seen =
        new Set();


      blocks

        .filter(
          block => {

            const uniq =
              `${block.pageKey}::${block.blockKey}`;

            if (
              seen.has(uniq)
            )
              return false;

            seen.add(uniq);

            return true;
          }
        )

        .forEach(
          block =>
            section.appendChild(
              createCmsBlock(
                block
              )
            )
        );

    } catch (error) {

      console.warn(
        "CMS load failed:",
        error
      );
    }
  }


  /* =========================================================
     GLOBAL CHATBOT
     ========================================================= */

  function ensureGlobalChatbotShell() {

    if (!document.getElementById("chat-wrapper")) {

      const wrapper =
        document.createElement("div");

      wrapper.id =
        "chat-wrapper";

      wrapper.innerHTML = `
        <div id="chat-notification">Need help? Ask me!</div>
        <div id="chat-toggle" role="button" tabindex="0" aria-label="Open WebConnect AI">AI</div>
      `;

      document.body.appendChild(
        wrapper
      );
    }

    if (!document.getElementById("chat-container")) {

      const container =
        document.createElement("div");

      container.id =
        "chat-container";

      document.body.appendChild(
        container
      );
    }
  }


  function ensureChatbotAssets() {

    const hasFontAwesome =
      [...document.styleSheets].some(sheet =>
        String(sheet.href || "").includes("font-awesome") ||
        String(sheet.href || "").includes("fontawesome")
      ) ||
      document.querySelector('link[href*="font-awesome"], link[href*="fontawesome"]');

    if (!hasFontAwesome) {

      const icons =
        document.createElement("link");

      icons.rel =
        "stylesheet";

      icons.href =
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css";

      document.head.appendChild(
        icons
      );
    }
  }


  function ensureGlobalChatbot() {

    ensureGlobalChatbotShell();
    ensureChatbotAssets();
    document.body.classList.add(
      "wc-chatbot-ready"
    );

    const wrapper =
      document.getElementById("chat-wrapper");

    const toggle =
      document.getElementById("chat-toggle");

    const chat =
      document.getElementById("chat-container");

    if (wrapper) {
      wrapper.style.display =
        "block";
      wrapper.style.visibility =
        "visible";
      wrapper.style.opacity =
        "1";
    }

    if (toggle && chat && toggle.dataset.wcHomeChatGuard !== "true") {

      toggle.dataset.wcHomeChatGuard =
        "true";

      toggle.addEventListener("click", event => {

        event.preventDefault();
        event.stopImmediatePropagation();

        const isOpen =
          chat.style.display === "grid" ||
          chat.style.display === "flex";

        chat.style.display =
          isOpen ? "none" : "grid";

        if (!isOpen) {
          localStorage.removeItem(
            "chatHidden"
          );
          window.setTimeout(() =>
            document.getElementById("userInput")?.focus(),
          80);
        }
      }, true);
    }

    window.setTimeout(() => {

      const alreadyLoaded =
        document.querySelector(
          'script[src$="premium-chatbot.js"], script[src*="/premium-chatbot.js"]'
        );

      if (alreadyLoaded) return;

      const script =
        document.createElement("script");

      script.src =
        `${root}premium-chatbot.js`;

      script.defer =
        true;

      document.body.appendChild(
        script
      );
    }, 0);
  }


  /* =========================================================
     22 — ANALYTICS
     ========================================================= */

  async function trackEvent(
    payload
  ) {

    const db =
      await ensureFirebase();

    if (!db) return;

    try {

      await db
        .collection(
          "analytics_events"
        )
        .add({

          ...payload,

          createdAt:
            firebase.firestore
              .FieldValue
              .serverTimestamp()

        });

    } catch (error) {

      console.warn(
        "Analytics track failed:",
        error
      );
    }
  }


  /* =========================================================
     23 — LINK DIAGNOSTICS
     ========================================================= */

  function setupLinkDiagnostics(
    section
  ) {

    if (!section) return;

    section.addEventListener(
      "click",
      event => {

        const link =
          event.target.closest(
            "a[href]"
          );

        if (!link) return;

        const href =
          String(
            link.getAttribute(
              "href"
            ) || ""
          ).trim();

        if (!href) return;

        try {

          const absolute =
            new URL(
              href,
              location.href
            );


          if (
            !/^https?:/.test(
              absolute.protocol
            )
          ) {

            trackEvent({

              type:
                "broken_link",

              page:
                pathKey(),

              url:
                href,

              reason:
                "Unsupported protocol"

            });

          }

        } catch (error) {

          trackEvent({

            type:
              "broken_link",

            page:
              pathKey(),

            url:
              href,

            reason:
              "Invalid URL"

          });

        }

      }
    );
  }


  /* =========================================================
     24 — VISIT TRACKING
     ========================================================= */

  function trackVisitOnce() {

    const key =
      `wc_visit_${pathKey()}`;

    if (
      sessionStorage.getItem(
        key
      )
    ) return;

    sessionStorage.setItem(
      key,
      "1"
    );

    trackEvent({

      type:
        "visit",

      page:
        pathKey(),

      title:
        document.title || "",

      referrer:
        document.referrer || ""

    });
  }


  /* =========================================================
     25 — MAIN ENHANCER
     ========================================================= */

  function enhance() {

    injectCorporateStyles();

    normalizeHeaderBrand();

    const section =
      document.querySelector(
        ".page-section"
      );

    if (!section) return;

    if (
      document.body.dataset.wcEnhanced ===
      "true"
    ) return;

    document.body.dataset.wcEnhanced =
      "true";


    const profile =
      currentProfile();


    /*
      IMPORTANT:

      .grid .card = directory page

      .about-card = corporate/static page
    */

    const directoryMode =
      isDirectoryPage(
        section
      );


    if (directoryMode) {

      /*
        CATEGORY / RESOURCE PAGE
      */

      document.body.classList.add(
        "wc-directory-page"
      );


      const cards =
        [
          ...section.querySelectorAll(
            ".grid .card"
          )
        ];


      createHero(
        section,
        profile,
        cards.length,
        false
      );


      addInsightBand(
        section,
        cards,
        profile
      );


      addCommandDock(
        section,
        cards,
        profile
      );


      addSmartCollections(
        section,
        cards
      );


      addToolbar(
        section,
        cards
      );


      enrichCards(
        cards,
        profile
      );


      setupHeroActions(
        section,
        cards,
        false
      );


    } else {

      /*
        CORPORATE STATIC PAGE

        Contact
        About
        Features
        Creator
        Projects
        Learning
        Feedback
        Help
        Privacy
        Terms
        etc.
      */

      document.body.classList.add(
        "wc-corporate-page"
      );


      const cards =
        [
          ...section.querySelectorAll(
            ".about-card"
          )
        ];


      createHero(
        section,
        profile,
        0,
        true
      );


      enhanceStaticCards(
        section
      );


      setupHeroActions(
        section,
        cards,
        true
      );

    }

  }


  /* =========================================================
     26 — START
     ========================================================= */

  async function start() {

    enhance();

    ensureGlobalChatbot();

    const section =
      document.querySelector(
        ".page-section"
      );

    setupLinkDiagnostics(
      section
    );

    trackVisitOnce();

    await loadCmsBlocks(
      section
    );
  }


  if (
    document.readyState ===
    "loading"
  ) {

    document.addEventListener(
      "DOMContentLoaded",
      start
    );

  } else {

    start();

  }

})();


/* =========================================================
   WEBCONNECT 2.0 — POWER HUB (v1)
   Sitewide productivity add-ons layered on top of the existing
   design. Nothing below this line changes any existing markup,
   class name or CSS rule — it only *adds* a self-contained
   floating widget that works the same way on all 245 pages.
   ========================================================= */
(function () {
  "use strict";

  if (window.__wcPowerHubLoaded) return;
  window.__wcPowerHubLoaded = true;

  /* ---------- paths & storage ---------- */

  const enhancerSrc2 =
    document.currentScript?.getAttribute("src") || "";
  const ROOT = enhancerSrc2.startsWith("../") ? "../" : "";

  const LS = {
    favorites: "wc_platform_favorites_v1",
    notes: "wc_power_notes_v1",
    theme: "wc_power_theme_v1",
    streak: "wc_power_streak_v1",
    tip: "wc_power_tip_seen_v1",
    recent: "wc_power_recent_pages_v1",
    panel: "wc_power_last_tab_v1"
  };

  function read(key, fallback) {
    try {
      const v = JSON.parse(localStorage.getItem(key));
      return v === null || v === undefined ? fallback : v;
    } catch (e) { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) {}
  }
  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[c]));
  }
  const todayKey = () => new Date().toISOString().slice(0, 10);

  /* ---------- category index (for Quick Jump / Ctrl+K) ---------- */

  const CATEGORIES = [{"label":"3D Design","url":"3d-design.html"},{"label":"Admit Cards","url":"admit-cards.html"},{"label":"Agriculture","url":"agriculture.html"},{"label":"AI Tools","url":"ai.html"},{"label":"Algorithms","url":"algorithms.html"},{"label":"All","url":"all.html"},{"label":"Animation","url":"animation.html"},{"label":"APIs","url":"apis.html"},{"label":"AR/VR","url":"ar-vr.html"},{"label":"Art & Craft","url":"art-craft.html"},{"label":"Astronomy","url":"astronomy.html"},{"label":"Banking","url":"banking.html"},{"label":"Blockchain","url":"blockchain.html"},{"label":"Blogging","url":"blogging.html"},{"label":"Books","url":"books.html"},{"label":"Business","url":"business.html"},{"label":"Career Guidance","url":"career-guidance.html"},{"label":"Certifications","url":"certifications.html"},{"label":"Cloud","url":"cloud.html"},{"label":"Coding","url":"coding.html"},{"label":"Communication","url":"communication.html"},{"label":"Communities","url":"communities.html"},{"label":"Competitive Programming","url":"competitive-programming.html"},{"label":"Cooking","url":"cooking.html"},{"label":"Crypto","url":"crypto.html"},{"label":"Cyber","url":"cyber.html"},{"label":"Data Structures","url":"data-structures.html"},{"label":"Delivery Services","url":"delivery-services.html"},{"label":"Design","url":"design.html"},{"label":"Developer","url":"developer.html"},{"label":"DevOps","url":"devops.html"},{"label":"DIY","url":"diy.html"},{"label":"Donations","url":"donations.html"},{"label":"Downloads","url":"downloads.html"},{"label":"Ebooks","url":"ebooks.html"},{"label":"Economics","url":"economics.html"},{"label":"Education","url":"education.html"},{"label":"Electronics","url":"electronics.html"},{"label":"Entertainment","url":"entertainment.html"},{"label":"Environment","url":"environment.html"},{"label":"Events","url":"events.html"},{"label":"Exams","url":"exams.html"},{"label":"Fashion","url":"fashion.html"},{"label":"Finance","url":"finance.html"},{"label":"Food","url":"food.html"},{"label":"Forums","url":"forums.html"},{"label":"Freelance Tools","url":"freelance-tools.html"},{"label":"Freelancing","url":"freelancing.html"},{"label":"Games","url":"games.html"},{"label":"Geography","url":"geography.html"},{"label":"Govt Portals","url":"government-portals.html"},{"label":"Govt Schemes","url":"government-schemes.html"},{"label":"Government Services","url":"govt.html"},{"label":"Hardware","url":"hardware.html"},{"label":"Health Services","url":"health-services.html"},{"label":"Health","url":"health.html"},{"label":"History","url":"history.html"},{"label":"Home Decor","url":"home-decor.html"},{"label":"Hospitals","url":"hospitals.html"},{"label":"Images","url":"images.html"},{"label":"Insurance","url":"insurance.html"},{"label":"Internships","url":"internships.html"},{"label":"Interview Prep","url":"interview-prep.html"},{"label":"IoT","url":"iot.html"},{"label":"Jobs","url":"jobs.html"},{"label":"Kids","url":"kids.html"},{"label":"Languages","url":"languages.html"},{"label":"Legal Help","url":"legal-help.html"},{"label":"Lifestyle","url":"lifestyle.html"},{"label":"Local Services","url":"local-services.html"},{"label":"Maps & Navigation","url":"maps-navigation.html"},{"label":"Mathematics","url":"mathematics.html"},{"label":"Memes","url":"memes.html"},{"label":"More","url":"more.html"},{"label":"Motivation","url":"motivation.html"},{"label":"Music","url":"music.html"},{"label":"Networking","url":"networking.html"},{"label":"News","url":"news.html"},{"label":"NGO","url":"ngo.html"},{"label":"Online Courses","url":"online-courses.html"},{"label":"Open Data","url":"open-data.html"},{"label":"Opensource","url":"opensource.html"},{"label":"Parenting","url":"parenting.html"},{"label":"Personality Development","url":"personality-development.html"},{"label":"Photo Editing","url":"photo-editing.html"},{"label":"Photography","url":"photography.html"},{"label":"Podcasting Tools","url":"podcasting-tools.html"},{"label":"Podcasts","url":"podcasts.html"},{"label":"Police Services","url":"police-services.html"},{"label":"Popular","url":"popular.html"},{"label":"Printing","url":"printing.html"},{"label":"Productivity","url":"productivity.html"},{"label":"Public Speaking","url":"public-speaking.html"},{"label":"Public Utilities","url":"public-utilities.html"},{"label":"Question Papers","url":"question-papers.html"},{"label":"Quotes","url":"quotes.html"},{"label":"Real Estate","url":"real-estate.html"},{"label":"Religion & Spirituality","url":"religion-spiritual.html"},{"label":"Remote Jobs","url":"remote-jobs.html"},{"label":"Research","url":"research.html"},{"label":"Results","url":"results.html"},{"label":"Resume Builder","url":"resume-builder.html"},{"label":"Robotics","url":"robotics.html"},{"label":"Scholarships","url":"scholarships.html"},{"label":"Science","url":"science.html"},{"label":"Shopping","url":"shopping.html"},{"label":"Social","url":"social.html"},{"label":"Soft Skills","url":"soft-skills.html"},{"label":"Sports","url":"sports.html"},{"label":"Start Learning","url":"start-learning.html"},{"label":"Startups","url":"startups.html"},{"label":"Stock Market","url":"stock-market.html"},{"label":"System Design","url":"system-design.html"},{"label":"Templates","url":"templates.html"},{"label":"Testing","url":"testing.html"},{"label":"Tools","url":"tools.html"},{"label":"Travel","url":"travel.html"},{"label":"Tutorials","url":"tutorials.html"},{"label":"UI/UX Design","url":"ui-ux.html"},{"label":"Universities","url":"universities.html"},{"label":"Video Editing","url":"video-editing.html"},{"label":"Videography","url":"videography.html"},{"label":"Vlogging","url":"vlogging.html"},{"label":"Weather","url":"weather.html"}];

  /* ---------- favorites (shared with homepage favorites bar) ---------- */

  function favorites() { return read(LS.favorites, []); }
  function favId(item) { return item.url || item.name; }
  function currentPageEntry() {
    return {
      name: document.title.replace(/\s*\|\s*WebConnect.*$/i, "").trim() || location.pathname,
      url: ROOT ? location.pathname.split("/").slice(-2).join("/") : location.pathname.split("/").pop() || "index.html",
      category: "Page",
      at: Date.now()
    };
  }
  function isCurrentPageSaved() {
    const id = currentPageEntry().url;
    return favorites().some(f => (f.url || "").endsWith(id));
  }
  function toggleCurrentPage() {
    const entry = currentPageEntry();
    const list = favorites();
    const exists = list.some(f => (f.url || "").endsWith(entry.url));
    const next = exists
      ? list.filter(f => !(f.url || "").endsWith(entry.url))
      : [entry, ...list].slice(0, 40);
    write(LS.favorites, next);
    renderPanel();
    updateFabBadge();
  }

  /* ---------- recently visited ---------- */

  function trackRecent() {
    const entry = currentPageEntry();
    const list = read(LS.recent, []).filter(p => p.url !== entry.url);
    list.unshift(entry);
    write(LS.recent, list.slice(0, 12));
  }

  /* ---------- streak ---------- */

  function updateStreak() {
    const state = read(LS.streak, { last: "", count: 0, best: 0 });
    const today = todayKey();
    if (state.last === today) return state;
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const count = state.last === yesterday ? (state.count + 1) : 1;
    const best = Math.max(count, state.best || 0);
    const next = { last: today, count, best };
    write(LS.streak, next);
    return next;
  }

  /* ---------- notes ---------- */

  function notes() { return read(LS.notes, []); }
  function addNote(text) {
    if (!text.trim()) return;
    const list = notes();
    list.unshift({ id: Date.now(), text: text.trim(), at: Date.now() });
    write(LS.notes, list.slice(0, 50));
    renderPanel("notes");
  }
  function removeNote(id) {
    write(LS.notes, notes().filter(n => n.id !== id));
    renderPanel("notes");
  }

  /* ---------- theme (reversible filter-based dark mode) ---------- */

  function applyTheme() {
    const on = read(LS.theme, false);
    document.documentElement.classList.toggle("wc-power-dark", !!on);
  }
  function toggleTheme() {
    write(LS.theme, !read(LS.theme, false));
    applyTheme();
  }

  /* ---------- daily tip ---------- */

  const TIPS = [
    "Press Ctrl+K (or tap the Jump button) anywhere on WebConnect to search all 120+ categories instantly.",
    "Save any page as a favorite with the ⭐ button in the Power Hub — your list follows you across the whole site.",
    "Scholarship and admit-card deadlines move fast — bookmark the Scholarships and Admit Cards pages so you don't miss one.",
    "Use the Notes tab in the Power Hub as a quick scratchpad for links, ideas or reminders while you browse.",
    "Keep your daily streak alive — visit WebConnect once a day to build your exploration streak.",
    "Feeling stuck? Hit Surprise Category in the Tools tab for a random useful destination.",
    "Government portals, schemes and services are all organised under the Government Services hub.",
    "Your recently visited pages are saved automatically so you can pick up where you left off."
  ];

  function dailyTip() {
    const dayIndex = Math.floor(Date.now() / 86400000);
    return TIPS[dayIndex % TIPS.length];
  }

  function maybeShowTip() {
    if (read(LS.tip, "") === todayKey()) return;
    const bar = document.createElement("div");
    bar.className = "wc-power-tip";
    bar.innerHTML = `
      <i class="fas fa-lightbulb" aria-hidden="true"></i>
      <span>${esc(dailyTip())}</span>
      <button type="button" aria-label="Dismiss tip">&times;</button>
    `;
    document.body.appendChild(bar);
    requestAnimationFrame(() => bar.classList.add("show"));
    const close = () => {
      bar.classList.remove("show");
      setTimeout(() => bar.remove(), 300);
      write(LS.tip, todayKey());
    };
    bar.querySelector("button").addEventListener("click", close);
    setTimeout(close, 9000);
  }

  /* ---------- styles ---------- */

  function injectStyles() {
    if (document.getElementById("wc-power-hub-styles")) return;
    const style = document.createElement("style");
    style.id = "wc-power-hub-styles";
    style.textContent = `
      #wc-power-fab{position:fixed;left:22px;bottom:25px;width:56px;height:56px;border-radius:50%;
        background:linear-gradient(135deg,#0f9f79,#2f80ed);color:#fff;border:none;cursor:pointer;
        box-shadow:0 12px 28px rgba(15,159,121,.35);font-size:22px;display:flex;align-items:center;
        justify-content:center;z-index:2147483000;transition:transform .25s ease;}
      #wc-power-fab:hover{transform:scale(1.08) rotate(-4deg);}
      #wc-power-fab .wc-streak-badge{position:absolute;top:-6px;right:-6px;background:#f4a62a;color:#101828;
        font-size:10px;font-weight:800;padding:2px 6px;border-radius:999px;box-shadow:0 2px 6px rgba(0,0,0,.25);
        min-width:18px;text-align:center;}
      #wc-power-panel{position:fixed;left:22px;bottom:92px;width:330px;max-width:calc(100vw - 44px);
        max-height:70vh;background:#fff;color:#102033;border-radius:18px;box-shadow:0 30px 70px rgba(15,23,42,.25),
        0 2px 10px rgba(15,23,42,.08);border:1px solid rgba(16,32,51,.08);z-index:2147483000;display:none;
        flex-direction:column;overflow:hidden;font-family:inherit;}
      #wc-power-panel.open{display:flex;animation:wcPowerIn .22s ease;}
      @keyframes wcPowerIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
      .wc-power-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;
        background:linear-gradient(135deg,#0f9f79,#2f80ed);color:#fff;}
      .wc-power-head strong{font-size:14px;}
      .wc-power-head small{display:block;font-weight:500;opacity:.85;font-size:11px;margin-top:2px;}
      .wc-power-head button{background:rgba(255,255,255,.18);border:none;color:#fff;width:26px;height:26px;
        border-radius:50%;cursor:pointer;font-size:14px;line-height:1;}
      .wc-power-tabs{display:flex;border-bottom:1px solid rgba(16,32,51,.08);background:#f5f7fa;}
      .wc-power-tabs button{flex:1;padding:10px 4px;background:none;border:none;font-size:11px;font-weight:700;
        color:#60758b;cursor:pointer;border-bottom:2px solid transparent;}
      .wc-power-tabs button.active{color:#0f9f79;border-color:#0f9f79;background:#fff;}
      .wc-power-body{padding:12px 14px;overflow-y:auto;flex:1;}
      .wc-power-search{width:100%;box-sizing:border-box;padding:9px 12px;border-radius:10px;
        border:1px solid rgba(16,32,51,.15);font-size:13px;margin-bottom:10px;}
      .wc-power-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px;
        max-height:280px;overflow-y:auto;}
      .wc-power-list li{display:flex;align-items:center;gap:8px;}
      .wc-power-list a{flex:1;text-decoration:none;color:#102033;font-size:12.5px;font-weight:600;
        padding:8px 10px;border-radius:9px;background:#f5f7fa;transition:background .15s;}
      .wc-power-list a:hover{background:#e7f6f0;}
      .wc-power-list button.wc-remove{background:none;border:none;color:#ef4444;cursor:pointer;font-size:14px;
        padding:4px 6px;}
      .wc-power-empty{font-size:12px;color:#60758b;text-align:center;padding:18px 6px;}
      .wc-power-row{display:flex;gap:8px;}
      .wc-power-row textarea{flex:1;resize:vertical;min-height:54px;border-radius:10px;
        border:1px solid rgba(16,32,51,.15);padding:8px 10px;font-size:12.5px;font-family:inherit;}
      .wc-power-row button.wc-add{background:#0f9f79;color:#fff;border:none;border-radius:10px;
        padding:0 14px;font-size:12px;font-weight:700;cursor:pointer;}
      .wc-power-note{background:#f5f7fa;border-radius:10px;padding:8px 10px;font-size:12px;position:relative;}
      .wc-power-note time{display:block;font-size:10px;color:#60758b;margin-top:4px;}
      .wc-tool-btn{width:100%;display:flex;align-items:center;gap:10px;background:#f5f7fa;border:none;
        border-radius:10px;padding:10px 12px;font-size:12.5px;font-weight:700;color:#102033;cursor:pointer;
        margin-bottom:8px;text-align:left;}
      .wc-tool-btn i{color:#0f9f79;width:16px;text-align:center;}
      .wc-tool-btn:hover{background:#e7f6f0;}
      .wc-power-stats{display:flex;gap:8px;margin-bottom:12px;}
      .wc-power-stat{flex:1;background:#f5f7fa;border-radius:10px;padding:10px;text-align:center;}
      .wc-power-stat strong{display:block;font-size:16px;color:#0f9f79;}
      .wc-power-stat span{font-size:10px;color:#60758b;font-weight:700;text-transform:uppercase;}
      .wc-power-tip{position:fixed;top:0;left:50%;transform:translate(-50%,-120%);transition:transform .3s ease;
        background:#101828;color:#fff;padding:10px 16px;border-radius:0 0 14px 14px;display:flex;
        align-items:center;gap:10px;font-size:12.5px;max-width:min(520px,92vw);z-index:2147483100;
        box-shadow:0 12px 30px rgba(0,0,0,.25);}
      .wc-power-tip.show{transform:translate(-50%,0);}
      .wc-power-tip i{color:#f4a62a;}
      .wc-power-tip button{background:none;border:none;color:#fff;font-size:16px;cursor:pointer;opacity:.7;}
      html.wc-power-dark{filter:invert(1) hue-rotate(180deg);background:#111 !important;}
      html.wc-power-dark img,html.wc-power-dark svg,html.wc-power-dark video,
      html.wc-power-dark iframe,html.wc-power-dark picture{filter:invert(1) hue-rotate(180deg);}
      @media (max-width:520px){
        #wc-power-fab{left:14px;bottom:16px;width:50px;height:50px;font-size:19px;}
        #wc-power-panel{left:10px;bottom:78px;width:calc(100vw - 20px);}
      }
    `;
    document.head.appendChild(style);
  }

  /* ---------- FAB + panel scaffold ---------- */

  function updateFabBadge() {
    const badge = document.getElementById("wc-power-streak-badge");
    if (badge) badge.textContent = String(read(LS.streak, { count: 0 }).count || "");
  }

  function buildFab() {
    const fab = document.createElement("button");
    fab.id = "wc-power-fab";
    fab.type = "button";
    fab.setAttribute("aria-label", "Open WebConnect Power Hub");
    fab.innerHTML = `<i class="fas fa-bolt" aria-hidden="true"></i><span id="wc-power-streak-badge" class="wc-streak-badge"></span>`;

    const panel = document.createElement("div");
    panel.id = "wc-power-panel";

    document.body.appendChild(fab);
    document.body.appendChild(panel);

    // Clicks inside the panel must never bubble to the document-level
    // "click outside to close" handler below — otherwise a click on a
    // tab/button that re-renders the panel's innerHTML detaches the
    // original target node, which would make panel.contains(e.target)
    // report false and incorrectly close the panel mid-interaction.
    panel.addEventListener("click", e => e.stopPropagation());
    fab.addEventListener("click", e => e.stopPropagation());

    fab.addEventListener("click", () => {
      panel.classList.toggle("open");
      if (panel.classList.contains("open")) renderPanel();
    });

    document.addEventListener("click", () => {
      panel.classList.remove("open");
    });

    updateFabBadge();
  }

  /* ---------- panel rendering ---------- */

  let activeTab = null;

  function renderPanel(forceTab) {
    const panel = document.getElementById("wc-power-panel");
    if (!panel) return;
    const tab = forceTab || activeTab || read(LS.panel, "jump");
    activeTab = tab;
    write(LS.panel, tab);

    const streak = read(LS.streak, { count: 0, best: 0 });

    panel.innerHTML = `
      <div class="wc-power-head">
        <div><strong>⚡ Power Hub</strong><small>Quick tools for this site</small></div>
        <button type="button" id="wc-power-close" aria-label="Close">&times;</button>
      </div>
      <div class="wc-power-tabs">
        <button data-tab="jump" class="${tab === "jump" ? "active" : ""}">Jump</button>
        <button data-tab="favorites" class="${tab === "favorites" ? "active" : ""}">Saved</button>
        <button data-tab="notes" class="${tab === "notes" ? "active" : ""}">Notes</button>
        <button data-tab="tools" class="${tab === "tools" ? "active" : ""}">Tools</button>
      </div>
      <div class="wc-power-body" id="wc-power-body"></div>
    `;

    panel.querySelector("#wc-power-close").addEventListener("click", () => panel.classList.remove("open"));
    panel.querySelectorAll(".wc-power-tabs button").forEach(btn => {
      btn.addEventListener("click", () => renderPanel(btn.dataset.tab));
    });

    const body = panel.querySelector("#wc-power-body");

    if (tab === "jump") {
      body.innerHTML = `
        <input type="text" class="wc-power-search" id="wc-jump-search" placeholder="Search 120+ categories…">
        <ul class="wc-power-list" id="wc-jump-list"></ul>
      `;
      const list = body.querySelector("#wc-jump-list");
      const input = body.querySelector("#wc-jump-search");
      const draw = (query) => {
        const q = (query || "").toLowerCase().trim();
        const items = (q ? CATEGORIES.filter(c => c.label.toLowerCase().includes(q)) : CATEGORIES).slice(0, 40);
        list.innerHTML = items.length
          ? items.map(c => `<li><a href="${ROOT}${c.url}"><i class="fas fa-arrow-right" aria-hidden="true" style="margin-right:6px;color:#0f9f79;"></i>${esc(c.label)}</a></li>`).join("")
          : `<div class="wc-power-empty">No category matches that search.</div>`;
      };
      draw("");
      input.addEventListener("input", () => draw(input.value));
      setTimeout(() => input.focus(), 50);
    }

    if (tab === "favorites") {
      const list = favorites();
      const saved = isCurrentPageSaved();
      body.innerHTML = `
        <button type="button" class="wc-tool-btn" id="wc-save-page">
          <i class="fas ${saved ? "fa-star" : "fa-star"}" aria-hidden="true"></i>
          ${saved ? "Remove this page from Saved" : "Save this page"}
        </button>
        <ul class="wc-power-list">
          ${list.length ? list.map(f => `
            <li>
              <a href="${esc(f.url)}">${esc(f.name)}</a>
              <button class="wc-remove" data-id="${esc(favId(f))}" aria-label="Remove"><i class="fas fa-trash" aria-hidden="true"></i></button>
            </li>
          `).join("") : `<div class="wc-power-empty">Nothing saved yet. Save pages to find them instantly later.</div>`}
        </ul>
      `;
      body.querySelector("#wc-save-page").addEventListener("click", toggleCurrentPage);
      body.querySelectorAll(".wc-remove").forEach(btn => {
        btn.addEventListener("click", () => {
          write(LS.favorites, favorites().filter(f => favId(f) !== btn.dataset.id));
          renderPanel("favorites");
          updateFabBadge();
        });
      });
    }

    if (tab === "notes") {
      const list = notes();
      body.innerHTML = `
        <div class="wc-power-row" style="margin-bottom:10px;">
          <textarea id="wc-note-input" placeholder="Jot a quick note, link or reminder…"></textarea>
          <button class="wc-add" id="wc-note-add" type="button">Add</button>
        </div>
        <div class="wc-power-list" style="max-height:230px;">
          ${list.length ? list.map(n => `
            <div class="wc-power-note">
              ${esc(n.text)}
              <time>${new Date(n.at).toLocaleString()}</time>
              <button class="wc-remove" data-id="${n.id}" style="position:absolute;top:6px;right:6px;" aria-label="Delete note"><i class="fas fa-times" aria-hidden="true"></i></button>
            </div>
          `).join("") : `<div class="wc-power-empty">No notes yet — this is your private scratchpad.</div>`}
        </div>
      `;
      body.querySelector("#wc-note-add").addEventListener("click", () => {
        const ta = body.querySelector("#wc-note-input");
        addNote(ta.value);
        ta.value = "";
      });
      body.querySelectorAll(".wc-remove").forEach(btn => {
        btn.addEventListener("click", () => removeNote(Number(btn.dataset.id)));
      });
    }

    if (tab === "tools") {
      const dark = read(LS.theme, false);
      const recent = read(LS.recent, []);
      body.innerHTML = `
        <div class="wc-power-stats">
          <div class="wc-power-stat"><strong>${streak.count || 0}</strong><span>Day streak</span></div>
          <div class="wc-power-stat"><strong>${streak.best || 0}</strong><span>Best streak</span></div>
          <div class="wc-power-stat"><strong>${favorites().length}</strong><span>Saved</span></div>
        </div>
        <button class="wc-tool-btn" id="wc-tool-theme"><i class="fas fa-circle-half-stroke"></i>${dark ? "Switch to light mode" : "Switch to dark mode"}</button>
        <button class="wc-tool-btn" id="wc-tool-copy"><i class="fas fa-link"></i>Copy this page link</button>
        <button class="wc-tool-btn" id="wc-tool-share"><i class="fas fa-share-nodes"></i>Share this page</button>
        <button class="wc-tool-btn" id="wc-tool-random"><i class="fas fa-shuffle"></i>Surprise category</button>
        ${window.__wcCanInstall ? `<button class="wc-tool-btn" id="wc-tool-install"><i class="fas fa-mobile-screen-button"></i>Install WebConnect app</button>` : ""}
        ${recent.length ? `
          <div style="font-size:11px;font-weight:800;color:#60758b;margin:10px 0 6px;text-transform:uppercase;">Recently viewed</div>
          <ul class="wc-power-list">
            ${recent.slice(0, 6).map(r => `<li><a href="${esc(r.url)}">${esc(r.name)}</a></li>`).join("")}
          </ul>` : ""}
      `;
      body.querySelector("#wc-tool-theme").addEventListener("click", () => { toggleTheme(); renderPanel("tools"); });
      body.querySelector("#wc-tool-copy").addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(location.href); } catch (e) {}
      });
      body.querySelector("#wc-tool-share").addEventListener("click", () => {
        if (navigator.share) {
          navigator.share({ title: document.title, url: location.href }).catch(() => {});
        } else {
          navigator.clipboard?.writeText(location.href);
        }
      });
      body.querySelector("#wc-tool-random").addEventListener("click", () => {
        const pick = CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)];
        if (pick) location.href = ROOT + pick.url;
      });
      body.querySelector("#wc-tool-install")?.addEventListener("click", async () => {
        await window.wcTriggerInstall?.();
        renderPanel("tools");
      });
    }
  }

  document.addEventListener("wc:install-available", () => {
    if (activeTab === "tools") renderPanel("tools");
  });

  /* ---------- init ---------- */

  function init() {
    injectStyles();
    applyTheme();
    buildFab();
    updateStreak();
    updateFabBadge();
    trackRecent();
    maybeShowTip();

    document.addEventListener("keydown", e => {
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && k === "k") {
        e.preventDefault();
        const panel = document.getElementById("wc-power-panel");
        if (panel) {
          panel.classList.add("open");
          renderPanel("jump");
        }
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();


/* =========================================================
   WEBCONNECT 2.0 — APP SHELL (v1)
   Installable PWA + offline support + connectivity awareness.
   Purely additive: injects <link>/<meta> tags and a service
   worker registration via JS, so no per-page HTML had to change.
   ========================================================= */
(function () {
  "use strict";

  if (window.__wcAppShellLoaded) return;
  window.__wcAppShellLoaded = true;

  const srcAttr =
    document.currentScript?.getAttribute("src") || "";
  const ROOT = srcAttr.startsWith("../") ? "../" : "";

  /* ---------- manifest + icons (idempotent) ---------- */

  function ensureHeadTag(selectorCheck, build) {
    if (document.querySelector(selectorCheck)) return;
    document.head.appendChild(build());
  }

  function injectAppMeta() {
    ensureHeadTag('link[rel="manifest"]', () => {
      const link = document.createElement("link");
      link.rel = "manifest";
      link.href = `${ROOT}manifest.webmanifest`;
      return link;
    });

    ensureHeadTag('link[rel="apple-touch-icon"]', () => {
      const link = document.createElement("link");
      link.rel = "apple-touch-icon";
      link.href = `${ROOT}icons/icon-192.png`;
      return link;
    });

    ensureHeadTag('meta[name="mobile-web-app-capable"]', () => {
      const meta = document.createElement("meta");
      meta.name = "mobile-web-app-capable";
      meta.content = "yes";
      return meta;
    });

    ensureHeadTag('meta[name="apple-mobile-web-app-status-bar-style"]', () => {
      const meta = document.createElement("meta");
      meta.name = "apple-mobile-web-app-status-bar-style";
      meta.content = "default";
      return meta;
    });
  }

  /* ---------- service worker ---------- */

  function registerServiceWorker() {
    if (!("serviceWorker" in navigator)) return;
    if (location.protocol !== "https:" && location.hostname !== "localhost") return;
    // Resolves to "/service-worker.js" from any depth, so scope is site-wide.
    const swUrl = new URL(`${ROOT}service-worker.js`, location.href).pathname;
    navigator.serviceWorker.register(swUrl).catch(() => {
      /* hosting may not support SW (e.g. file://) — fail silently */
    });
  }

  /* ---------- "Add to Home Screen" capture ---------- */

  window.__wcCanInstall = false;
  let deferredPrompt = null;

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredPrompt = event;
    window.__wcCanInstall = true;
    document.dispatchEvent(new CustomEvent("wc:install-available"));
  });

  window.wcTriggerInstall = async function () {
    if (!deferredPrompt) return { outcome: "unavailable" };
    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice.catch(() => ({ outcome: "dismissed" }));
    deferredPrompt = null;
    window.__wcCanInstall = false;
    return choice;
  };

  window.addEventListener("appinstalled", () => {
    window.__wcCanInstall = false;
  });

  /* ---------- online / offline toast ---------- */

  function injectConnectivityStyles() {
    if (document.getElementById("wc-connectivity-styles")) return;
    const style = document.createElement("style");
    style.id = "wc-connectivity-styles";
    style.textContent = `
      .wc-connectivity-toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,140%);
        background:#101828;color:#fff;padding:10px 18px;border-radius:999px;font-size:12.5px;
        font-weight:600;display:flex;align-items:center;gap:8px;z-index:2147483100;
        box-shadow:0 14px 34px rgba(0,0,0,.3);transition:transform .3s ease;}
      .wc-connectivity-toast.show{transform:translate(-50%,0);}
      .wc-connectivity-toast.offline{background:#7c2d2d;}
      .wc-connectivity-toast.online{background:#0f6b4f;}
      .wc-connectivity-toast i{font-size:13px;}
    `;
    document.head.appendChild(style);
  }

  let connectivityTimer = null;
  function showConnectivityToast(isOnline) {
    injectConnectivityStyles();
    let toast = document.getElementById("wc-connectivity-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "wc-connectivity-toast";
      toast.className = "wc-connectivity-toast";
      document.body.appendChild(toast);
    }
    toast.classList.remove("online", "offline");
    toast.classList.add(isOnline ? "online" : "offline");
    toast.innerHTML = isOnline
      ? `<i class="fas fa-wifi" aria-hidden="true"></i><span>Back online</span>`
      : `<i class="fas fa-plug-circle-xmark" aria-hidden="true"></i><span>You're offline — cached pages still work</span>`;
    requestAnimationFrame(() => toast.classList.add("show"));
    clearTimeout(connectivityTimer);
    connectivityTimer = setTimeout(() => toast.classList.remove("show"), isOnline ? 3000 : 6000);
  }

  function watchConnectivity() {
    window.addEventListener("offline", () => showConnectivityToast(false));
    window.addEventListener("online", () => showConnectivityToast(true));
  }

  function init() {
    injectAppMeta();
    registerServiceWorker();
    watchConnectivity();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
