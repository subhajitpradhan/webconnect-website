(function () {
  const STORE = {
    recentSites: "wc_recent_sites_v2",
    recentCategories: "wc_recent_categories_v2",
    favorites: "wc_favorite_sites_v2",
    favoriteCategories: "wc_favorite_categories_v2",
    searches: "wc_recent_searches_v2",
    stats: "wc_stats_v2",
    streak: "wc_daily_streak_v2",
    activity: "wc_activity_v2",
    profile: "wc_user_profile_v2",
    collections: "wc_saved_collections_v2"
  };

  const categoryPreviews = {
    "ai.html": ["ChatGPT", "Gemini", "Claude", "Perplexity", "Poe"],
    "jobs.html": ["LinkedIn", "Naukri", "Indeed", "Internshala", "Remote OK"],
    "education.html": ["FreeCodeCamp", "W3Schools", "Coursera", "Khan Academy", "NPTEL"],
    "govt.html": ["DigiLocker", "UMANG", "Aadhaar", "Passport Seva", "Income Tax"],
    "developer.html": ["GitHub", "MDN", "Stack Overflow", "CodePen", "Vercel"],
    "coding.html": ["LeetCode", "HackerRank", "GeeksforGeeks", "FreeCodeCamp", "CodeChef"],
    "tools.html": ["Canva", "Notion", "Figma", "TinyPNG", "Remove.bg"],
    "scholarships.html": ["Scholarships.gov.in", "Buddy4Study", "Swayam", "NPTEL", "NSP"],
    "internships.html": ["Internshala", "LinkedIn", "Wellfound", "Indeed", "Remote OK"],
    "resume-builder.html": ["Canva", "Resume.io", "Zety", "Novoresume", "LinkedIn"],
    "interview-prep.html": ["Pramp", "InterviewBit", "LeetCode", "Glassdoor", "GeeksforGeeks"],
    "freelancing.html": ["Upwork", "Fiverr", "Freelancer", "Toptal", "PeoplePerHour"],
    "finance.html": ["Groww", "Zerodha", "Paytm", "PhonePe", "Razorpay"],
    "news.html": ["BBC", "NDTV", "The Hindu", "Reuters", "Indian Express"],
    "shopping.html": ["Amazon", "Flipkart", "Myntra", "Meesho", "Nykaa"],
    "health.html": ["Practo", "1mg", "PharmEasy", "Healthline", "Apollo 24/7"],
    "banking.html": ["SBI", "HDFC Bank", "ICICI Bank", "Paytm", "Google Pay"],
    "all.html": ["AI Tools", "Jobs", "Education", "Developer", "Govt Services"]
  };

  const qualityBadges = ["Verified", "Trending", "Editor Pick", "New"];

  const siteCatalog = [
    ["ChatGPT", "https://chat.openai.com", "AI Tools", ["ai", "write", "code", "chatbot", "website"], ["Verified", "Trending"]],
    ["Gemini", "https://gemini.google.com", "AI Tools", ["ai", "google", "research", "chat"], ["Verified"]],
    ["Claude", "https://claude.ai", "AI Tools", ["ai", "writing", "coding", "assistant"], ["Editor Pick"]],
    ["Perplexity", "https://perplexity.ai", "AI Tools", ["ai", "search", "research", "answer"], ["Trending"]],
    ["Poe", "https://poe.com", "AI Tools", ["ai", "bots", "chat"], ["New"]],
    ["LinkedIn", "https://linkedin.com", "Jobs", ["job", "career", "network", "hiring"], ["Verified", "Trending"]],
    ["Naukri", "https://naukri.com", "Jobs", ["job", "career", "india", "fresher"], ["Verified"]],
    ["Indeed", "https://indeed.com", "Jobs", ["job", "career", "hiring"], ["Verified"]],
    ["Internshala", "https://internshala.com", "Jobs", ["internship", "student", "job", "fresher"], ["Editor Pick"]],
    ["Wellfound", "https://wellfound.com", "Jobs", ["startup", "internship", "job", "remote"], ["Trending"]],
    ["Remote OK", "https://remoteok.com", "Jobs", ["remote", "job", "work"], ["Trending"]],
    ["FreeCodeCamp", "https://freecodecamp.org", "Education", ["learn", "coding", "python", "web", "free"], ["Verified", "Editor Pick"]],
    ["W3Schools", "https://w3schools.com", "Education", ["learn", "coding", "web", "python", "html", "css"], ["Verified"]],
    ["Codecademy", "https://codecademy.com", "Education", ["learn", "coding", "python", "course"], ["Trending"]],
    ["Python.org", "https://python.org", "Developer", ["python", "docs", "learn", "download"], ["Verified"]],
    ["Coursera", "https://coursera.org", "Education", ["course", "learn", "certificate"], ["Verified"]],
    ["Khan Academy", "https://khanacademy.org", "Education", ["learn", "school", "math"], ["Editor Pick"]],
    ["GitHub", "https://github.com", "Developer", ["code", "website", "project", "git"], ["Verified", "Trending"]],
    ["CodePen", "https://codepen.io", "Developer", ["website", "frontend", "html", "css", "code"], ["Editor Pick"]],
    ["MDN", "https://developer.mozilla.org", "Developer", ["web", "docs", "javascript", "html", "css"], ["Verified"]],
    ["Stack Overflow", "https://stackoverflow.com", "Developer", ["code", "debug", "developer"], ["Verified"]],
    ["Resume.io", "https://resume.io", "Jobs", ["resume", "cv", "career"], ["Editor Pick"]],
    ["Zety", "https://zety.com", "Jobs", ["resume", "cv", "career"], ["Verified"]],
    ["Canva", "https://canva.com", "Tools", ["design", "presentation", "image"], ["Trending"]],
    ["Figma", "https://figma.com", "Design", ["design", "ui", "prototype"], ["Verified"]],
    ["Notion", "https://notion.so", "Productivity", ["notes", "productivity", "docs"], ["Editor Pick"]],
    ["Amazon", "https://amazon.in", "Shopping", ["shopping", "buy"], ["Verified"]],
    ["Flipkart", "https://flipkart.com", "Shopping", ["shopping", "buy"], ["Verified"]],
    ["DigiLocker", "https://digilocker.gov.in", "Govt Services", ["government", "documents", "india"], ["Verified"]],
    ["UMANG", "https://web.umang.gov.in", "Govt Services", ["government", "services", "india"], ["Verified"]]
  ].map(([name, url, category, tags, badges]) => ({ name, url, category, tags, badges }));

  const intentRules = [
    { intent: "learn-python", words: ["learn python", "python course", "python coding", "pyhton", "pyton"], picks: ["FreeCodeCamp", "W3Schools", "Codecademy", "Python.org"] },
    { intent: "jobs", words: ["need a job", "find job", "job", "jobs", "career", "naukri", "hiring", "fresher"], picks: ["LinkedIn", "Naukri", "Indeed", "Internshala"] },
    { intent: "internship", words: ["need internship", "find internship", "internship", "intern", "training"], picks: ["Internshala", "LinkedIn", "Wellfound"] },
    { intent: "resume", words: ["resume", "cv", "make resume", "resume builder"], picks: ["Resume.io", "Canva", "Zety", "LinkedIn"] },
    { intent: "create-website", words: ["create website", "make website", "build website", "web design", "frontend", "website banana"], picks: ["ChatGPT", "GitHub", "CodePen", "MDN"] },
    { intent: "learn-coding", words: ["learn coding", "coding course", "coding website", "programming", "code sikho"], picks: ["FreeCodeCamp", "W3Schools", "GeeksforGeeks", "LeetCode"] },
    { intent: "ai-tools", words: ["ai", "chatbot", "write with ai", "research ai", "image ai"], picks: ["ChatGPT", "Gemini", "Claude", "Perplexity"] }
  ];

  const synonyms = {
    career: ["job", "jobs", "hiring", "fresher", "work"],
    job: ["career", "hiring", "naukri", "vacancy"],
    coding: ["programming", "code", "developer", "software", "web"],
    course: ["learn", "tutorial", "class", "education"],
    website: ["web", "site", "frontend", "html"],
    ai: ["artificial intelligence", "chatbot", "assistant", "prompt"],
    govt: ["government", "official", "portal", "service"]
  };

  const profileModels = {
    developer: {
      label: "Developer",
      categories: ["developer", "coding", "ai tools", "tools", "design"],
      keywords: ["developer", "coding", "github", "code", "python", "api", "mdn", "leetcode", "website", "frontend"],
      priority: ["developer.html", "coding.html", "ai.html", "tools.html", "education.html"]
    },
    student: {
      label: "Student",
      categories: ["education", "scholarships", "universities", "courses", "exams"],
      keywords: ["education", "learn", "course", "scholarship", "university", "exam", "student", "python", "freecodecamp"],
      priority: ["education.html", "scholarships.html", "coding.html", "ai.html", "jobs.html"]
    },
    jobSeeker: {
      label: "Job Seeker",
      categories: ["jobs", "internships", "resume", "interview", "freelancing"],
      keywords: ["job", "jobs", "internship", "resume", "career", "linkedin", "naukri", "interview", "remote"],
      priority: ["jobs.html", "internships.html", "resume-builder.html", "interview-prep.html", "freelancing.html"]
    },
    aiUser: {
      label: "AI Enthusiast",
      categories: ["ai tools", "developer", "tools", "productivity"],
      keywords: ["ai", "chatgpt", "gemini", "claude", "perplexity", "prompt", "automation"],
      priority: ["ai.html", "developer.html", "tools.html", "education.html", "jobs.html"]
    },
    dailyUser: {
      label: "Daily User",
      categories: ["shopping", "news", "govt services", "banking", "health"],
      keywords: ["shopping", "news", "govt", "banking", "health", "finance", "amazon", "digilocker"],
      priority: ["govt.html", "shopping.html", "news.html", "finance.html", "health.html"]
    }
  };

  let lastTrackedSearch = "";

  function read(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function upsertList(key, item, limit) {
    const list = read(key, []);
    const id = item.url || item.href || item.name;
    const next = [item, ...list.filter(old => (old.url || old.href || old.name) !== id)].slice(0, limit);
    write(key, next);
    return next;
  }

  function incrementMap(map, key, amount = 1) {
    const clean = normalize(key);
    if (!clean) return;
    map[clean] = (map[clean] || 0) + amount;
  }

  function trackActivity(type, value, amount = 1) {
    const activity = read(STORE.activity, { sites: {}, categories: {}, searches: {}, interests: {}, timeSpent: 0, updatedAt: 0 });
    if (type === "site") incrementMap(activity.sites, value, amount);
    if (type === "category") incrementMap(activity.categories, value, amount);
    if (type === "search") incrementMap(activity.searches, value, amount);
    if (type === "interest") incrementMap(activity.interests, value, amount);
    if (type === "time") activity.timeSpent = (activity.timeSpent || 0) + amount;
    activity.updatedAt = Date.now();
    write(STORE.activity, activity);
    return activity;
  }

  function activityText() {
    const activity = read(STORE.activity, { sites: {}, categories: {}, searches: {}, interests: {} });
    return [
      ...Object.entries(activity.sites || {}).map(([key, value]) => `${key} `.repeat(Math.min(value, 8))),
      ...Object.entries(activity.categories || {}).map(([key, value]) => `${key} `.repeat(Math.min(value, 8))),
      ...Object.entries(activity.searches || {}).map(([key, value]) => `${key} `.repeat(Math.min(value, 6))),
      ...Object.entries(activity.interests || {}).map(([key, value]) => `${key} `.repeat(Math.min(value, 8)))
    ].join(" ");
  }

  function getUserProfile() {
    const haystack = normalize(activityText());
    const scores = Object.entries(profileModels).map(([key, profile]) => {
      const categoryScore = profile.categories.reduce((sum, item) => sum + (haystack.includes(normalize(item)) ? 16 : 0), 0);
      const keywordScore = profile.keywords.reduce((sum, item) => sum + (haystack.includes(normalize(item)) ? 12 : 0), 0);
      return { key, ...profile, score: categoryScore + keywordScore };
    }).sort((a, b) => b.score - a.score);
    const profile = scores[0]?.score > 0 ? scores[0] : { key: "dailyUser", ...profileModels.dailyUser, score: 0 };
    write(STORE.profile, { key: profile.key, label: profile.label, score: profile.score, updatedAt: Date.now() });
    return profile;
  }

  function textDistance(a, b) {
    a = String(a || "");
    b = String(b || "");
    const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        matrix[i][j] = b.charAt(i - 1) === a.charAt(j - 1)
          ? matrix[i - 1][j - 1]
          : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
      }
    }
    return matrix[b.length][a.length];
  }

  function normalize(text) {
    return String(text || "").toLowerCase().replace(/[^a-z0-9\s.]/g, " ").replace(/\s+/g, " ").trim();
  }

  function expandQuery(query) {
    const clean = normalize(query);
    const parts = new Set(clean.split(" ").filter(Boolean));
    Object.entries(synonyms).forEach(([key, values]) => {
      if (clean.includes(key) || values.some(value => clean.includes(value))) {
        parts.add(key);
        values.forEach(value => value.split(" ").forEach(word => parts.add(word)));
      }
    });
    return [...parts];
  }

  function detectIntent(query) {
    const q = normalize(query);
    return intentRules
      .map(rule => ({
        ...rule,
        score: rule.words.reduce((sum, word) => sum + (q.includes(normalize(word)) ? 35 : 0), 0)
      }))
      .sort((a, b) => b.score - a.score)[0];
  }

  function scoreSite(site, query) {
    const q = normalize(query);
    const words = expandQuery(query);
    const haystack = normalize(`${site.name} ${site.category} ${site.tags?.join(" ") || ""} ${site.url}`);
    let score = 0;
    if (normalize(site.name) === q) score += 1000;
    if (normalize(site.name).startsWith(q)) score += 650;
    if (haystack.includes(q)) score += 420;
    words.forEach(word => {
      if (normalize(site.name).includes(word)) score += 90;
      if (normalize(site.category).includes(word)) score += 70;
      if ((site.tags || []).some(tag => normalize(tag).includes(word))) score += 65;
      if (haystack.includes(word)) score += 25;
      const close = normalize(site.name).split(" ").some(part => textDistance(part, word) <= 2);
      if (close && word.length > 3) score += 55;
    });
    if ((site.badges || []).includes("Verified")) score += 10;
    if ((site.badges || []).includes("Trending")) score += 8;
    return score;
  }

  function mergedCatalog() {
    const map = new Map();
    siteCatalog.forEach(site => map.set(site.url, site));
    const directorySites = typeof websites !== "undefined" && Array.isArray(websites) ? websites : [];
    if (directorySites.length) {
      directorySites.forEach(site => {
        if (!site?.url || map.has(site.url)) return;
        map.set(site.url, {
          name: site.name,
          url: site.url,
          category: site.category || "Website",
          tags: [site.category || ""],
          badges: [qualityBadges[Math.abs(site.name.length + site.url.length) % qualityBadges.length]]
        });
      });
    }
    return [...map.values()];
  }

  function openSite(site) {
    recordVisit(site);
    window.location.href = site.url;
  }

  function recordVisit(site) {
    if (!site?.url) return;
    upsertList(STORE.recentSites, { name: site.name, url: site.url, category: site.category || "Website", at: Date.now() }, 12);
    const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [] });
    stats.websites = (stats.websites || 0) + 1;
    write(STORE.stats, stats);
    trackActivity("site", site.name, 2);
    trackActivity("category", site.category || "Website", 2);
    (site.tags || []).forEach(tag => trackActivity("interest", tag, 1));
    renderProductHub();
  }

  window.recordSmartVisit = function (site) {
    recordVisit(site);
  };

  window.isFavorite = function (url) {
    return read(STORE.favorites, []).some(item => item.url === url);
  };

  window.toggleFavorite = function (site) {
    const list = read(STORE.favorites, []);
    const exists = list.some(item => item.url === site.url);
    const next = exists
      ? list.filter(item => item.url !== site.url)
      : [{ name: site.name, url: site.url, category: site.category || "Website", at: Date.now() }, ...list].slice(0, 20);
    write(STORE.favorites, next);
    const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [] });
    stats.favorites = next.length;
    write(STORE.stats, stats);
    if (!exists) {
      trackActivity("site", site.name, 2);
      trackActivity("category", site.category || "Website", 1);
    }
    renderProductHub();
    return !exists;
  };

  function recordCategory(card) {
    const title = card.querySelector(".wc-card-title")?.textContent || card.textContent.trim();
    const href = card.getAttribute("href") || "";
    upsertList(STORE.recentCategories, { name: title, href, at: Date.now() }, 8);
    const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [] });
    stats.categories = [...new Set([...(stats.categories || []), href || title])];
    write(STORE.stats, stats);
    trackActivity("category", title, 3);
    trackActivity("interest", href.replace(".html", ""), 2);
    renderProductHub();
  }

  function updateStreak() {
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const streak = read(STORE.streak, { last: "", count: 0 });
    if (streak.last === today) return streak;
    const next = { last: today, count: streak.last === yesterday ? streak.count + 1 : 1 };
    write(STORE.streak, next);
    return next;
  }

  function dailyIndex(length, salt = "") {
    const d = new Date();
    const seed = Number(`${d.getFullYear()}${d.getMonth() + 1}${d.getDate()}`) + salt.length;
    return seed % Math.max(length, 1);
  }

  function createProductHub() {
    if (document.querySelector(".wc-product-hub")) return;
    const priority = document.querySelector(".home-priority") || document.querySelector(".hero");
    if (!priority) return;
    const hub = document.createElement("section");
    hub.className = "wc-product-hub";
    hub.innerHTML = `
      <div class="wc-hub-head">
        <div>
          <span class="section-kicker">Daily Hub</span>
          <h2>Start Faster Today</h2>
        </div>
        <div class="wc-hub-actions">
          <span class="wc-profile-pill" id="wcProfilePill">Learning profile</span>
          <button type="button" class="wc-command-btn" data-open-command>Ctrl K</button>
        </div>
      </div>
      <div class="wc-insight-row" id="wcInsightRow"></div>
      <div class="wc-hub-grid">
        <article class="wc-hub-panel wc-quick-launch">
          <div class="wc-panel-title"><strong>Quick Launch</strong><button type="button" data-random-site>Random Explore</button></div>
          <div id="wcQuickLaunch" class="wc-site-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Recently Visited</strong><button type="button" data-clear-recent>Clear</button></div>
          <div id="wcRecentlyVisited" class="wc-site-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Continue Exploring</strong><button type="button" data-pin-categories>Pin</button></div>
          <div id="wcContinueExploring" class="wc-site-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Popular Today</strong><span>Live picks</span></div>
          <div id="wcPopularToday" class="wc-site-list"></div>
        </article>
        <article class="wc-hub-panel wc-wide">
          <div class="wc-panel-title"><strong>Recommended For You</strong><span>Auto personalized</span></div>
          <div id="wcSmartSuggestions" class="wc-site-list horizontal"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Recent Searches</strong><span>Search hints</span></div>
          <div id="wcRecentSearches" class="wc-search-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Recommended Categories</strong><span>From profile</span></div>
          <div id="wcRecommendedCategories" class="wc-site-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Saved Collections</strong><span>Auto grouped</span></div>
          <div id="wcSavedCollections" class="wc-collection-list"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Website Of The Day</strong><span>Useful pick</span></div>
          <div id="wcDailyPick" class="wc-daily-pick"></div>
        </article>
        <article class="wc-hub-panel">
          <div class="wc-panel-title"><strong>Hidden Gems</strong><span>Underrated</span></div>
          <div id="wcHiddenGems" class="wc-site-list"></div>
        </article>
      </div>
    `;
    priority.after(hub);

    hub.querySelector("[data-open-command]")?.addEventListener("click", () => window.toggleCommandPalette?.(true));
    hub.querySelector("[data-random-site]")?.addEventListener("click", () => {
      const sites = mergedCatalog();
      openSite(sites[Math.floor(Math.random() * sites.length)]);
    });
    hub.querySelector("[data-clear-recent]")?.addEventListener("click", () => {
      write(STORE.recentSites, []);
      renderProductHub();
    });
    hub.querySelector("[data-pin-categories]")?.addEventListener("click", () => {
      const categories = read(STORE.recentCategories, []);
      write(STORE.favoriteCategories, categories.slice(0, 6));
      renderProductHub();
    });
  }

  function siteButton(site, compact = false) {
    const badges = (site.badges || ["Verified"]).slice(0, compact ? 1 : 2).map(badge => `<span>${badge}</span>`).join("");
    return `
      <button type="button" class="wc-site-row" data-open-site="${site.url}">
        <span class="wc-favicon"><img src="https://www.google.com/s2/favicons?sz=64&domain=${site.url}" alt=""></span>
        <span><strong>${site.name}</strong><small>${site.category || "Website"}</small></span>
        <em>${badges}</em>
      </button>
    `;
  }

  function renderList(id, items, emptyText) {
    const box = document.getElementById(id);
    if (!box) return;
    box.innerHTML = items.length ? items.map(item => siteButton(item, true)).join("") : `<div class="wc-empty">${emptyText}</div>`;
  }

  function getActivityPopular(catalog, limit = 5) {
    const activity = read(STORE.activity, { sites: {}, categories: {}, searches: {}, interests: {} });
    const ranked = catalog
      .map(site => {
        const siteScore = activity.sites?.[normalize(site.name)] || 0;
        const categoryScore = activity.categories?.[normalize(site.category)] || 0;
        const interestScore = (site.tags || []).reduce((sum, tag) => sum + (activity.interests?.[normalize(tag)] || 0), 0);
        return { ...site, score: siteScore * 8 + categoryScore * 3 + interestScore * 2 };
      })
      .filter(site => site.score > 0)
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
    return ranked.slice(0, limit);
  }

  function recommendedCategoryLinks(profile) {
    const known = {
      "ai.html": "AI Tools",
      "jobs.html": "Jobs",
      "education.html": "Education",
      "developer.html": "Developer",
      "coding.html": "Coding",
      "tools.html": "Tools",
      "scholarships.html": "Scholarships",
      "internships.html": "Internships",
      "resume-builder.html": "Resume Builder",
      "interview-prep.html": "Interview Prep",
      "freelancing.html": "Freelancing",
      "govt.html": "Govt Services",
      "shopping.html": "Shopping",
      "news.html": "News",
      "finance.html": "Finance",
      "health.html": "Health & Fitness"
    };
    return (profile.priority || []).map(href => ({ href, name: known[href] || href.replace(".html", "") }));
  }

  function buildCollections(profile, favoriteSites, recentSites) {
    const source = [...favoriteSites, ...recentSites];
    const groups = new Map();
    source.forEach(site => {
      const key = site.category || "Saved";
      if (!groups.has(key)) groups.set(key, []);
      if (!groups.get(key).some(item => item.url === site.url)) groups.get(key).push(site);
    });
    const collections = [...groups.entries()]
      .map(([name, items]) => ({ name, count: items.length, query: `${name} ${profile.label}` }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 4);
    if (!collections.length) {
      collections.push({ name: `${profile.label} Starter`, count: recommendedCategoryLinks(profile).length, query: profile.label });
    }
    write(STORE.collections, collections);
    return collections;
  }

  function getSmartContext() {
    const catalog = mergedCatalog();
    const profile = getUserProfile();
    const recentSites = read(STORE.recentSites, []);
    const recentCategories = read(STORE.recentCategories, []);
    const favoriteSites = read(STORE.favorites, []);
    const recentSearches = read(STORE.searches, []);
    const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [], timeSpent: 0 });
    const popular = getActivityPopular(catalog, 5);
    const fallbackPopular = ["ChatGPT", "LinkedIn", "FreeCodeCamp", "GitHub", "Canva"].map(name => catalog.find(site => site.name === name)).filter(Boolean);
    const discoveries = catalog.filter(site => !recentSites.some(recent => recent.url === site.url));
    const daily = discoveries[dailyIndex(discoveries.length, "hero")] || catalog[dailyIndex(catalog.length, "hero")];
    const mostVisitedCategory = Object.entries(read(STORE.activity, { categories: {} }).categories || {})
      .sort((a, b) => b[1] - a[1])[0]?.[0] || profile.label;
    return {
      catalog,
      profile,
      recentSites,
      recentCategories,
      favoriteSites,
      recentSearches,
      stats,
      popular: popular.length ? popular : fallbackPopular,
      daily,
      mostVisitedCategory
    };
  }

  function enhancePremiumHeader() {
    const header = document.querySelector("body.home-page > header");
    const nav = document.getElementById("navbar");
    if (!header || !nav || header.dataset.wcPremiumReady === "true") return;
    header.dataset.wcPremiumReady = "true";
    header.classList.add("wc-premium-header");

    const navCenter = nav.querySelector(".nav-center");
    if (navCenter) {
      navCenter.innerHTML = `
        <a href="index.html">Home</a>
        <a href="features.html">Features</a>
        <a href="about.html">About</a>
        <a href="contact.html">Contact</a>
      `;
    }

    const navRight = nav.querySelector(".nav-right");
    if (navRight) {
      navRight.innerHTML = `<a href="auth.html" class="auth-link">Login / Register</a>`;
    }

    const setHeaderState = () => {
      const isScrolled = window.scrollY > 24;
      header.classList.toggle("is-shrunk", isScrolled);
      header.classList.toggle("scrolled", isScrolled);
    };
    setHeaderState();
    window.addEventListener("scroll", setHeaderState, { passive: true });
  }

  function renderHeroSmartStrip() {
    const strip = document.getElementById("wcHeroSmartStrip");
    const welcome = document.getElementById("heroWelcome");
    if (!strip || !welcome) return;
    const ctx = getSmartContext();
    const firstRecent = ctx.recentSites[0];
    const firstCategory = ctx.recentCategories[0];
    const suggestions = getSmartResults(`${ctx.profile.label} ${ctx.recentSearches[0]?.query || "useful websites"}`, 3);
    welcome.textContent = `Welcome back ${ctx.profile.label}`;

    strip.innerHTML = `
      <article>
        <span>Continue Exploring</span>
        <strong>${firstCategory?.name || firstRecent?.name || "Start with categories"}</strong>
        <button type="button" ${firstCategory?.href ? `data-open-page="${firstCategory.href}"` : "data-focus-search"}>${firstCategory || firstRecent ? "Continue" : "Search"}</button>
      </article>
      <article>
        <span>Website Of The Day</span>
        <strong>${ctx.daily?.name || "WebConnect Pick"}</strong>
        <button type="button" ${ctx.daily ? `data-open-site="${ctx.daily.url}"` : "data-focus-search"}>Open</button>
      </article>
      <article class="wc-hero-suggestions">
        <span>Smart Suggestions</span>
        <div>${suggestions.map(site => `<button type="button" data-open-site="${site.url}">${site.name}</button>`).join("")}</div>
      </article>
    `;
  }

  function enhanceSmartFooter() {
    const footer = document.querySelector("body.home-page .footer");
    if (!footer) return;
    const ctx = getSmartContext();

    if (!footer.querySelector(".wc-smart-footer")) {
      const smart = document.createElement("section");
      smart.className = "wc-smart-footer";
      smart.innerHTML = `
        <article><span>Most Visited Category</span><strong id="wcFooterTopCategory"></strong></article>
        <article><span>Popular Today</span><div id="wcFooterPopular"></div></article>
        <article><span>Recently Added</span><div id="wcFooterRecentAdded"></div></article>
        <article><span>Trending Searches</span><div id="wcFooterTrending"></div></article>
      `;
      const stats = footer.querySelector(".footer-stats");
      footer.insertBefore(smart, stats || footer.firstChild);
    }

    const topCategory = footer.querySelector("#wcFooterTopCategory");
    if (topCategory) topCategory.textContent = ctx.mostVisitedCategory.replace(/\b\w/g, char => char.toUpperCase());

    const popular = footer.querySelector("#wcFooterPopular");
    if (popular) popular.innerHTML = ctx.popular.slice(0, 3).map(site => `<button type="button" data-open-site="${site.url}">${site.name}</button>`).join("");

    const added = footer.querySelector("#wcFooterRecentAdded");
    if (added) added.innerHTML = ["Poe", "Wellfound", "Resume.io"].map(query => `<button type="button" data-run-query="${query}">${query}</button>`).join("");

    const trending = footer.querySelector("#wcFooterTrending");
    if (trending) {
      const items = ctx.recentSearches.length ? ctx.recentSearches.slice(0, 4).map(item => item.query) : ["AI Tools", "Python", "Jobs", "Scholarships"];
      trending.innerHTML = items.map(query => `<button type="button" data-run-query="${query}">${query}</button>`).join("");
    }

    const footerStats = footer.querySelector(".footer-stats");
    if (footerStats) {
      footerStats.innerHTML = `
        <div class="stat-box"><h3>1000+</h3><p>Websites</p></div>
        <div class="stat-box"><h3>100+</h3><p>Categories</p></div>
        <div class="stat-box"><h3>${ctx.stats.websites || 0}</h3><p>Your Opens</p></div>
        <div class="stat-box"><h3>${ctx.stats.searches || 0}</h3><p>Your Searches</p></div>
      `;
    }

    const footerContainer = footer.querySelector(".footer-container");
    if (footerContainer && !footer.querySelector(".wc-footer-actions")) {
      const actions = document.createElement("div");
      actions.className = "footer-col wc-footer-actions";
      actions.innerHTML = `
        <h4>Actions</h4>
        <button type="button" data-focus-search>Smart Search</button>
        <a href="https://forms.gle/Hv5tt4BdUoFBD1AF6" target="_blank" rel="noopener">Feedback</a>
        <a href="contact.html">Suggest Website</a>
      `;
      footerContainer.appendChild(actions);
    }

    if (!footer.querySelector(".wc-footer-social")) {
      const social = document.createElement("div");
      social.className = "wc-footer-social";
      social.innerHTML = `
        <a href="https://github.com/subhajitpradhan" target="_blank" rel="noopener" aria-label="GitHub"><i class="fab fa-github"></i></a>
        <a href="https://youtube.com/@subhajitt.09" target="_blank" rel="noopener" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
        <a href="https://www.linkedin.com/in/subhajit-pradhan-92a88b33a/" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
        <a href="mailto:pradhansubhajit606@gmail.com" aria-label="Email"><i class="fas fa-envelope"></i></a>
      `;
      const bottom = footer.querySelector(".footer-bottom-bar");
      footer.insertBefore(social, bottom || footer.querySelector(".footer-bottom"));
    }

    const updated = footer.querySelector(".last-updated, .footer-pill");
    if (updated) {
      updated.innerHTML = `<span class="live-dot"></span> Last Updated : <span> ${new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })} </span>`;
    }
  }

  function renderProductHub() {
    if (!document.body.classList.contains("home-page")) return;
    createProductHub();
    const streak = updateStreak();
    const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [] });
    const recentSites = read(STORE.recentSites, []);
    const recentCategories = read(STORE.recentCategories, []);
    const favoriteSites = read(STORE.favorites, []);
    const recentSearches = read(STORE.searches, []);
    const catalog = mergedCatalog();
    const profile = getUserProfile();
    const profileQuery = `${profile.label} ${profile.keywords.slice(0, 4).join(" ")}`;
    const fallbackPopular = ["ChatGPT", "LinkedIn", "FreeCodeCamp", "GitHub", "Canva"].map(name => catalog.find(site => site.name === name)).filter(Boolean);
    const popular = getActivityPopular(catalog, 5);
    const hidden = ["Perplexity", "CodePen", "MDN", "Notion"].map(name => catalog.find(site => site.name === name)).filter(Boolean);
    const discoveries = catalog.filter(site => !recentSites.some(recent => recent.url === site.url));
    const daily = discoveries[dailyIndex(discoveries.length, "daily")] || catalog[dailyIndex(catalog.length, "daily")];
    const suggestionQuery = recentSearches[0]?.query || recentSites[0]?.category || profileQuery;
    const suggestions = getSmartResults(`${suggestionQuery} ${profileQuery}`, 4);

    const profilePill = document.getElementById("wcProfilePill");
    if (profilePill) profilePill.textContent = `${profile.label} mode`;

    const insight = document.getElementById("wcInsightRow");
    if (insight) {
      const badges = [
        stats.websites >= 100 ? "Explorer" : "Starter",
        recentSites.filter(site => /AI/i.test(site.category)).length >= 50 ? "AI Master" : "AI Ready",
        recentSites.filter(site => /Education|Learning/i.test(site.category)).length >= 50 ? "Learner" : "Learning"
      ];
      insight.innerHTML = `
        <div><strong>${streak.count} Day Streak</strong><small>Daily visits tracked</small></div>
        <div><strong>${profile.label}</strong><small>Auto profile</small></div>
        <div><strong>${stats.categories?.length || 0}</strong><small>Categories explored</small></div>
        <div><strong>${stats.websites || 0}</strong><small>Websites visited</small></div>
        <div><strong>${Math.max(favoriteSites.length, stats.favorites || 0)}</strong><small>Favorites saved</small></div>
        <div><strong>${stats.searches || 0}</strong><small>Searches performed</small></div>
        <div><strong>${Math.floor((stats.timeSpent || 0) / 60)} min</strong><small>Time spent</small></div>
        <div><strong>${badges.join(" · ")}</strong><small>Achievement badges</small></div>
      `;
    }

    renderList("wcQuickLaunch", favoriteSites.length ? favoriteSites : (popular.length ? popular : fallbackPopular).slice(0, 4), "Pin websites from search to launch them here.");
    renderList("wcRecentlyVisited", recentSites.slice(0, 4), "Open any website and it will appear here.");
    const continueBox = document.getElementById("wcContinueExploring");
    if (continueBox) {
      continueBox.innerHTML = recentCategories.length
        ? recentCategories.slice(0, 5).map(cat => `<a class="wc-category-row" href="${cat.href}"><strong>${cat.name}</strong><small>Continue category</small></a>`).join("")
        : `<div class="wc-empty">Open a category to continue from here.</div>`;
    }
    renderList("wcPopularToday", popular.length ? popular : fallbackPopular, "Popular picks are loading.");
    renderList("wcSmartSuggestions", suggestions, "Search once to unlock better suggestions.");
    renderList("wcHiddenGems", hidden, "Hidden gems are loading.");
    const searchBox = document.getElementById("wcRecentSearches");
    if (searchBox) {
      searchBox.innerHTML = recentSearches.length
        ? recentSearches.slice(0, 6).map(item => `<button type="button" data-run-query="${item.query}">${item.query}</button>`).join("")
        : `<div class="wc-empty">Searches will become quick hints here.</div>`;
    }
    const recommendedCategories = document.getElementById("wcRecommendedCategories");
    if (recommendedCategories) {
      recommendedCategories.innerHTML = recommendedCategoryLinks(profile).slice(0, 5)
        .map(cat => `<a class="wc-category-row" href="${cat.href}"><strong>${cat.name}</strong><small>${profile.label} pick</small></a>`)
        .join("");
    }
    const collectionsBox = document.getElementById("wcSavedCollections");
    if (collectionsBox) {
      collectionsBox.innerHTML = buildCollections(profile, favoriteSites, recentSites)
        .map(collection => `<button type="button" data-run-query="${collection.query}"><strong>${collection.name}</strong><small>${collection.count} saved signals</small></button>`)
        .join("");
    }
    const pick = document.getElementById("wcDailyPick");
    if (pick && daily) {
      pick.innerHTML = `${siteButton(daily)}<button type="button" class="wc-open-all" data-copy-site="${daily.url}">Copy Website Link</button>`;
    }
    personalizeCategoryCards();
    renderHeroSmartStrip();
    enhanceSmartFooter();
  }

  function enhanceCategoryCards() {
    const cards = [...document.querySelectorAll("body.home-page .categories .grid .card")];
    cards.forEach((card, index) => {
      if (card.dataset.wcPreviewReady === "true") return;
      const href = card.getAttribute("href") || "";
      const icon = card.querySelector("span")?.textContent.trim() || "🌐";
      const label = card.textContent.replace(icon, "").trim() || "Category";
      const items = categoryPreviews[href] || ["Top Sites", "Useful Links", "Quick Picks", "Verified", "More"];
      card.dataset.wcPreviewReady = "true";
      card.innerHTML = `
        <div class="wc-card-top">
          <span class="wc-card-icon">${icon}</span>
          <div><strong class="wc-card-title">${label}</strong><small>${items.length} quick picks</small></div>
          <button type="button" class="wc-pin-category" aria-label="Favorite ${label}">☆</button>
        </div>
        <ul class="wc-preview-list">
          ${items.slice(0, 5).map(item => `<li>${item}</li>`).join("")}
        </ul>
        <div class="wc-card-actions">
          <span>View All</span>
          <button type="button" data-share-category>Share</button>
          <button type="button" data-open-all>Open All</button>
        </div>
      `;
      card.addEventListener("click", event => {
        const action = event.target.closest("button");
        if (!action) {
          recordCategory(card);
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        if (action.matches(".wc-pin-category")) {
          const saved = upsertList(STORE.favoriteCategories, { name: label, href, at: Date.now() }, 12);
          action.textContent = saved.some(item => item.href === href) ? "★" : "☆";
          return;
        }
        if (action.matches("[data-share-category]")) {
          const url = new URL(href, location.href).href;
          if (navigator.share) navigator.share({ title: label, url });
          else navigator.clipboard?.writeText(url);
          return;
        }
        if (action.matches("[data-open-all]")) {
          const query = items.slice(0, 4).join(" ");
          window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        }
      });
      card.style.setProperty("--wc-card-order", index);
    });
    personalizeCategoryCards();
  }

  function personalizeCategoryCards() {
    const grid = document.querySelector("body.home-page .categories .grid");
    if (!grid) return;
    const profile = getUserProfile();
    const priority = new Map((profile.priority || []).map((href, index) => [href, index]));
    [...grid.querySelectorAll(".card")].forEach((card, index) => {
      const href = card.getAttribute("href") || "";
      const title = card.querySelector(".wc-card-title")?.textContent || "";
      const activity = read(STORE.activity, { categories: {}, interests: {} });
      const activityBoost = (activity.categories?.[normalize(title)] || 0) + (activity.interests?.[normalize(href.replace(".html", ""))] || 0);
      const profileRank = priority.has(href) ? priority.get(href) : 100;
      card.style.order = String(profileRank * 10 - activityBoost + index);
      card.dataset.profilePick = profileRank < 5 ? "true" : "false";
    });
  }

  function getSmartResults(query, limit = 8) {
    const intent = detectIntent(query);
    const catalog = mergedCatalog();
    const intentItems = intent && intent.score > 0
      ? intent.picks.map(name => catalog.find(site => normalize(site.name) === normalize(name))).filter(Boolean)
      : [];
    const ranked = catalog
      .map(site => ({ ...site, score: scoreSite(site, query) + (intentItems.some(item => item.url === site.url) ? 500 : 0) }))
      .filter(site => site.score > 0)
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
    const unique = [];
    [...intentItems, ...ranked].forEach(site => {
      if (site && !unique.some(item => item.url === site.url)) unique.push(site);
    });
    return unique.slice(0, limit);
  }

  function upgradeSearch() {
    window.getSearchSuggestions = function (query, limit = 32) {
      const clean = String(query || "").trim();
      if (!clean) return [];
      if (normalize(clean) !== lastTrackedSearch && clean.length > 1) {
        lastTrackedSearch = normalize(clean);
        const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [] });
        stats.searches = (stats.searches || 0) + 1;
        write(STORE.stats, stats);
        upsertList(STORE.searches, { query: clean, at: Date.now() }, 10);
        trackActivity("search", clean, 2);
        expandQuery(clean).forEach(word => trackActivity("interest", word, 1));
      }

      const results = getSmartResults(clean, limit).map(site => ({
        name: site.name,
        url: site.url,
        category: `${site.category} · ${(site.badges || ["Verified"]).join(" · ")}`,
        type: site.url.includes(".html") ? "page" : "website",
        score: site.score || 1
      }));

      if (/^[a-z0-9][a-z0-9-]*(\.[a-z0-9-]+)+/i.test(clean)) {
        results.unshift({ name: `Open ${clean}`, url: clean.startsWith("http") ? clean : `https://${clean}`, category: "Direct Website", type: "website", score: 999 });
      }
      results.push({ name: `Search Google for "${clean}"`, url: `https://www.google.com/search?q=${encodeURIComponent(clean)}`, category: "Google Search", type: "google", score: 1 });
      renderProductHub();
      return results;
    };

    window.renderCommandResults = function (query) {
      const results = document.getElementById("commandResults");
      if (!results) return;
      const items = getSmartResults(query || "popular", 9);
      results.innerHTML = items.map(site => `
        <button type="button" data-open-site="${site.url}">
          <strong>${site.name}</strong>
          <small>${site.category} · ${(site.badges || ["Verified"])[0]}</small>
        </button>
      `).join("");
    };
  }

  function improveAssistant() {
    const originalSend = window.sendMessage;
    window.sendMessage = function () {
      const input = document.getElementById("userInput");
      const msg = input?.value?.trim() || "";
      if (!msg) return originalSend?.();
      const picks = getSmartResults(msg, 4);
      if (picks.length && typeof window.addMessage === "function") {
        window.addMessage("You", msg);
        input.value = "";
        const profile = getUserProfile();
        const cards = picks.map(site => `
          <button class="bot-mini-card" type="button" data-open-site="${site.url}">
            <strong>${site.name}</strong><small>${site.category}</small>
          </button>
        `).join("");
        trackActivity("search", msg, 2);
        expandQuery(msg).forEach(word => trackActivity("interest", word, 1));
        window.addMessage("Bot", `I matched this to your goal and ${profile.label} profile:<div class="bot-mini-grid">${cards}</div>`);
        return;
      }
      return originalSend?.();
    };
  }

  function wireGlobalActions() {
    document.addEventListener("click", event => {
      const siteButtonNode = event.target.closest("[data-open-site]");
      if (siteButtonNode) {
        const url = siteButtonNode.dataset.openSite;
        const site = mergedCatalog().find(item => item.url === url) || { name: siteButtonNode.textContent.trim(), url, category: "Website" };
        openSite(site);
        return;
      }
      const copy = event.target.closest("[data-copy-site]");
      if (copy) {
        navigator.clipboard?.writeText(copy.dataset.copySite);
      }
      const queryButton = event.target.closest("[data-run-query]");
      if (queryButton) {
        const query = queryButton.dataset.runQuery || "";
        const input = document.getElementById("searchInput");
        if (input) {
          input.value = query;
          input.focus();
          window.showSuggestions?.();
        }
      }
      const focusSearch = event.target.closest("[data-focus-search]");
      if (focusSearch) {
        document.getElementById("searchInput")?.focus();
      }
      const openPage = event.target.closest("[data-open-page]");
      if (openPage) {
        window.location.href = openPage.dataset.openPage;
      }
    });

    document.addEventListener("keydown", event => {
      if (event.key === "/" && !event.target.matches("input, textarea")) {
        event.preventDefault();
        document.getElementById("searchInput")?.focus();
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        window.toggleCommandPalette?.(true);
      }
    });
  }

  function addLoadingPolish() {
    document.documentElement.style.scrollBehavior = "smooth";
    document.body.classList.add("wc-loaded");
  }

  function initTimeTracking() {
    const startedAt = Date.now();
    let savedSeconds = 0;

    function saveTime(force = false) {
      const seconds = Math.max(0, Math.floor((Date.now() - startedAt) / 1000) - savedSeconds);
      if (seconds < 10 && !force) return;
      savedSeconds += seconds;
      const stats = read(STORE.stats, { websites: 0, searches: 0, favorites: 0, categories: [], timeSpent: 0 });
      stats.timeSpent = (stats.timeSpent || 0) + seconds;
      write(STORE.stats, stats);
      trackActivity("time", "session", seconds);
    }

    window.addEventListener("beforeunload", () => saveTime(true));
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") saveTime(true);
    });
    window.setInterval(() => {
      saveTime();
      renderProductHub();
    }, 30000);
  }

  document.addEventListener("DOMContentLoaded", () => {
    updateStreak();
    enhancePremiumHeader();
    enhanceCategoryCards();
    createProductHub();
    renderProductHub();
    upgradeSearch();
    improveAssistant();
    wireGlobalActions();
    addLoadingPolish();
    initTimeTracking();
    renderHeroSmartStrip();
    enhanceSmartFooter();
  });
})();
