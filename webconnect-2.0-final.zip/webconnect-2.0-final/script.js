// TOGGLE
// ================= CHAT TOGGLE (RESTORED) =================
const toggle = document.getElementById("chat-toggle");
const chat = document.getElementById("chat-container");

function addChatIntroMessage() {
  const messages = document.getElementById("chat-messages");
  if (!messages || messages.dataset.introAdded) return;

  const intro = document.createElement("div");
  intro.className = "chat-msg bot-msg";
  intro.innerHTML = `
    <div class="msg-text">
      Hi, I am WebConnect AI. Search websites, ask for categories, type "AI tools", "jobs", "government services", "coding", or "best study resources" and I will guide you fast.
      <div class="bot-actions">
        <button class="bot-action" onclick="quickMsg('ai')">AI Tools</button>
        <button class="bot-action" onclick="quickMsg('jobs')">Jobs</button>
        <button class="bot-action" onclick="quickMsg('education')">Education</button>
      </div>
    </div>
  `;
  messages.appendChild(intro);
  messages.dataset.introAdded = "true";
}

if (toggle && chat) {
  toggle.onclick = () => {
    if (chat.style.display === "grid" || chat.style.display === "flex") {
      chat.style.display = "none";
    } else {
      chat.style.display = "grid";
      localStorage.removeItem("chatHidden");
      addChatIntroMessage();
    }
  };
}

// ================= CLOSE BUTTON =================
document.addEventListener("DOMContentLoaded", () => {
  const closeBtn = document.getElementById("closeChat");

  if (closeBtn) {
    closeBtn.onclick = function () {
      const chatContainer = document.getElementById("chat-container");
      if (chatContainer) chatContainer.style.display = "none";
      localStorage.setItem("chatHidden", "true");
    };
  }

  const chatContainer = document.getElementById("chat-container");
  if (chatContainer && localStorage.getItem("chatHidden") === "true") {
    chatContainer.style.display = "none";
  }
});


// ================= COMPLETE WEBSITE MAP =================
const pages = {

  // MAIN
  "all": "all.html",
  "hospital": "hospitals.html",
  "university": "universities.html",
  "college": "universities.html",
  "exam": "exams.html",
  "education": "education.html",
  "job": "jobs.html",
  "govt": "govt.html",

  // TECH
  "ai": "ai.html",
  "developer": "developer.html",
  "coding": "coding.html",
  "cloud": "cloud.html",
  "cyber": "cyber.html",
  "tools": "tools.html",

  // WORK
  "freelancing": "freelancing.html",
  "finance": "finance.html",
  "productivity": "productivity.html",
  "communication": "communication.html",

  // MEDIA
  "news": "news.html",
  "ebooks": "ebooks.html",

  // LIFE
  "shopping": "shopping.html",
  "travel": "travel.html",
  "health": "health.html",
  "fitness": "health.html",
  "sports": "sports.html",

  // ENTERTAINMENT
  "social": "social.html",
  "entertainment": "entertainment.html",
  "games": "games.html",
  "gaming": "games.html",
  "design": "design.html",

  // ===== STUDENT & CAREER =====
  "scheme": "government-schemes.html",
  "scholarship": "scholarships.html",
  "internship": "internships.html",
  "remote": "remote-jobs.html",
  "resume": "resume-builder.html",
  "interview": "interview-prep.html",
  "result": "results.html",
  "admit": "admit-cards.html",
  "paper": "question-papers.html",
  "certificate": "certifications.html",

  // ===== EDUCATION =====
  "course": "online-courses.html",
  "tutorial": "tutorials.html",
  "research": "research.html",
  "learning": "start-learning.html",
  "competitive": "competitive-programming.html",
  "algorithm": "algorithms.html",
  "data": "data-structures.html",
  "system": "system-design.html",
  "testing": "testing.html",
  "devops": "devops.html",
  "api": "apis.html",

  // ===== GOVERNMENT =====
  "portal": "government-portals.html",
  "utility": "public-utilities.html",
  "police": "police-services.html",
  "legal": "legal-help.html",
  "bank": "banking.html",
  "insurance": "insurance.html",
  "real estate": "real-estate.html",
  "maps": "maps-navigation.html",
  "weather": "weather.html",
  "local": "local-services.html",
  "delivery": "delivery-services.html",

  // ===== TECH ADVANCED =====
  "opensource": "opensource.html",
  "download": "downloads.html",
  "template": "templates.html",
  "ui": "ui-ux.html",
  "photo": "photo-editing.html",
  "video": "video-editing.html",
  "animation": "animation.html",
  "3d": "3d-design.html",
  "printing": "printing.html",
  "blockchain": "blockchain.html",
  "iot": "iot.html",
  "robot": "robotics.html",
  "electronics": "electronics.html",
  "hardware": "hardware.html",
  "network": "networking.html",
  "ar": "ar-vr.html",

  // ===== BUSINESS =====
  "startup": "startups.html",
  "business": "business.html",
  "stock": "stock-market.html",
  "crypto": "crypto.html",
  "economics": "economics.html",

  // ===== SUBJECTS =====
  "science": "science.html",
  "math": "mathematics.html",
  "history": "history.html",
  "geography": "geography.html",
  "language": "languages.html",
  "astronomy": "astronomy.html",
  "environment": "environment.html",
  "agriculture": "agriculture.html",

  // ===== MEDIA =====
  "image": "images.html",
  "photography": "photography.html",
  "videography": "videography.html",
  "music": "music.html",
  "podcast": "podcasts.html",
  "book": "books.html",
  "blog": "blogging.html",
  "vlog": "vlogging.html",
  "art": "art-craft.html",
  "meme": "memes.html",
  "quote": "quotes.html",

  // ===== LIFE =====
  "kids": "kids.html",
  "parent": "parenting.html",
  "cooking": "cooking.html",
  "food": "food.html",
  "lifestyle": "lifestyle.html",
  "fashion": "fashion.html",
  "home": "home-decor.html",
  "diy": "diy.html",
  "community": "communities.html",
  "forum": "forums.html",
  "event": "events.html",
  "ngo": "ngo.html",
  "donation": "donations.html",
  "spiritual": "religion-spiritual.html",
  "personality": "personality-development.html",
  "soft skills": "soft-skills.html",
  "speaking": "public-speaking.html",
  "motivation": "motivation.html",





  // 🔍 Search
  "google": "https://google.com",
  "bing": "https://bing.com",
  "duckduckgo": "https://duckduckgo.com",

  // 📱 Social Media
  "youtube": "https://youtube.com",
  "instagram": "https://instagram.com",
  "facebook": "https://facebook.com",
  "twitter": "https://twitter.com",
  "x": "https://twitter.com",
  "linkedin": "https://linkedin.com",
  "snapchat": "https://snapchat.com",
  "reddit": "https://reddit.com",
  "discord": "https://discord.com",
  "telegram": "https://web.telegram.org",
  "whatsapp": "https://web.whatsapp.com",

  // 🤖 AI Tools
  "chatgpt": "https://chat.openai.com",
  "gemini": "https://gemini.google.com",
  "claude": "https://claude.ai",
  "perplexity": "https://perplexity.ai",
  "midjourney": "https://midjourney.com",
  "runway": "https://runwayml.com",

  // 💼 Jobs
  "naukri": "https://naukri.com",
  "indeed": "https://indeed.com",
  "glassdoor": "https://glassdoor.com",
  "internshala": "https://internshala.com",

  // 🎓 Education
  "coursera": "https://coursera.org",
  "udemy": "https://udemy.com",
  "khan academy": "https://khanacademy.org",
  "unacademy": "https://unacademy.com",
  "byjus": "https://byjus.com",
  "edx": "https://edx.org",

  // 💻 Developer
  "github": "https://github.com",
  "stackoverflow": "https://stackoverflow.com",
  "geeksforgeeks": "https://geeksforgeeks.org",
  "w3schools": "https://w3schools.com",
  "freecodecamp": "https://freecodecamp.org",

  // 🛒 Shopping
  "amazon": "https://amazon.in",
  "flipkart": "https://flipkart.com",
  "myntra": "https://myntra.com",
  "ajio": "https://ajio.com",
  "meesho": "https://meesho.com",
  "nykaa": "https://nykaa.com",

  // 🎬 Entertainment
  "netflix": "https://netflix.com",
  "hotstar": "https://hotstar.com",
  "prime video": "https://primevideo.com",
  "sony liv": "https://sonyliv.com",
  "zee5": "https://zee5.com",

  // 💰 Finance
  "paytm": "https://paytm.com",
  "phonepe": "https://phonepe.com",
  "gpay": "https://pay.google.com",
  "google pay": "https://pay.google.com",
  "groww": "https://groww.in",
  "zerodha": "https://zerodha.com",

  // ✈️ Travel
  "makemytrip": "https://makemytrip.com",
  "goibibo": "https://goibibo.com",
  "irctc": "https://irctc.co.in",
  "booking": "https://booking.com",
  "oyo": "https://oyo.com",

  // 🍔 Food
  "zomato": "https://zomato.com",
  "swiggy": "https://swiggy.com",

  // 🧰 Tools
  "canva": "https://canva.com",
  "figma": "https://figma.com",
  "notion": "https://notion.so",
  "zoom": "https://zoom.us",
"meet": "https://meet.google.com",




// ===== EXTRA POPULAR SITES =====

// 🔍 SEARCH & UTILITIES
"yahoo": "https://yahoo.com",
"ask": "https://ask.com",
"startpage": "https://startpage.com",
"ecosia": "https://ecosia.org",

// 📱 SOCIAL
"pinterest": "https://pinterest.com",
"threads": "https://threads.net",
"koo": "https://kooapp.com",
"tumblr": "https://tumblr.com",
"vk": "https://vk.com",

// 🤖 AI TOOLS
"bard": "https://gemini.google.com",
"deepseek": "https://deepseek.com",
"character ai": "https://character.ai",
"janitor ai": "https://janitorai.com",
"blackbox": "https://blackbox.ai",
"copy ai": "https://copy.ai",
"jasper": "https://jasper.ai",
"writesonic": "https://writesonic.com",
"quillbot": "https://quillbot.com",
"grammarly": "https://grammarly.com",

// 💼 JOBS
"monster": "https://monster.com",
"shine": "https://shine.com",
"timesjobs": "https://timesjobs.com",
"foundit": "https://foundit.in",
"wellfound": "https://wellfound.com",
"remote ok": "https://remoteok.com",

// 🎓 EDUCATION
"swayam": "https://swayam.gov.in",
"nptel": "https://nptel.ac.in",
"brilliant": "https://brilliant.org",
"codecademy": "https://codecademy.com",
"skillshare": "https://skillshare.com",
"udacity": "https://udacity.com",

// 💻 DEV
"codepen": "https://codepen.io",
"codesandbox": "https://codesandbox.io",
"stackblitz": "https://stackblitz.com",
"replit": "https://replit.com",
"leetcode": "https://leetcode.com",
"hackerrank": "https://hackerrank.com",

// 🛒 SHOPPING
"ebay": "https://ebay.com",
"etsy": "https://etsy.com",
"aliexpress": "https://aliexpress.com",
"tatacliq": "https://tatacliq.com",
"croma": "https://croma.com",
"reliance digital": "https://reliancedigital.in",

// 🎬 OTT
"spotify": "https://spotify.com",
"gaana": "https://gaana.com",
"jiosaavn": "https://jiosaavn.com",
"soundcloud": "https://soundcloud.com",
"mx player": "https://mxplayer.in",

// 💰 FINANCE
"coinbase": "https://coinbase.com",
"binance": "https://binance.com",
"upstox": "https://upstox.com",
"razorpay": "https://razorpay.com",
"phone pe": "https://phonepe.com",

// ✈️ TRAVEL
"skyscanner": "https://skyscanner.com",
"kayak": "https://kayak.com",
"redbus": "https://redbus.in",
"yatra": "https://yatra.com",

// 🍔 FOOD
"ubereats": "https://ubereats.com",
"dominos": "https://dominos.co.in",
"pizza hut": "https://pizzahut.co.in",

// 🧰 TOOLS
"removebg": "https://remove.bg",
"tinypng": "https://tinypng.com",
"photopea": "https://photopea.com",
"pixlr": "https://pixlr.com",
"cleanup": "https://cleanup.pictures",

// ☁️ CLOUD
"drive": "https://drive.google.com",
"dropbox": "https://dropbox.com",
"onedrive": "https://onedrive.live.com",

// 📧 EMAIL
"gmail": "https://mail.google.com",
"outlook": "https://outlook.live.com",
"protonmail": "https://proton.me",

// 📰 NEWS
"ndtv": "https://ndtv.com",
"bbc": "https://bbc.com",
"toi": "https://timesofindia.com",
"ht": "https://hindustantimes.com",
"indian express": "https://indianexpress.com",

// 🎮 GAMING
"steam": "https://store.steampowered.com",
"epic games": "https://epicgames.com",
"roblox": "https://roblox.com",
"twitch": "https://twitch.tv",

// 🏥 HEALTH
"practo": "https://practo.com",
"1mg": "https://1mg.com",
"pharmeasy": "https://pharmeasy.in",
"apollo": "https://apollo247.com",

// 📚 BOOKS
"gutenberg": "https://gutenberg.org",
"pdfdrive": "https://pdfdrive.com",

// 🧠 PRODUCTIVITY
"trello": "https://trello.com",
"slack": "https://slack.com",
"asana": "https://asana.com",
"clickup": "https://clickup.com",

// 🎨 DESIGN
"behance": "https://behance.net",
"dribbble": "https://dribbble.com",
"unsplash": "https://unsplash.com",
"pexels": "https://pexels.com",

// 🌐 EXTRA
"speedtest": "https://speedtest.net",
"downdetector": "https://downdetector.com",
"archive": "https://web.archive.org"














};

// ================= HUMAN-LIKE CHATBOT =================
const botProfile = {
  name: "WebConnect Assistant",
  creator: "Subhajit Pradhan",
  site: "WebConnect 2.0"
};

const chatSuggestions = [
  { label: "AI tools", query: "best ai tools" },
  { label: "Jobs", query: "jobs" },
  { label: "Study help", query: "education" },
  { label: "About site", query: "about webconnect" }
];

const chatSmartPrompts = [
  { label: "AI tools", prompt: "best AI tools for work" },
  { label: "Job path", prompt: "make a job preparation plan" },
  { label: "Study plan", prompt: "make a study roadmap" },
  { label: "Coding help", prompt: "best coding resources" },
  { label: "Govt links", prompt: "open government services" }
];

const chatLanguageNames = {
  hinglish: "Hinglish",
  en: "English",
  hi: "Hindi",
  bn: "Bengali",
  or: "Odia",
  ta: "Tamil",
  te: "Telugu",
  mr: "Marathi",
  gu: "Gujarati",
  es: "Spanish",
  fr: "French",
  de: "German"
};

function getChatLanguage() {
  return localStorage.getItem("webconnect_chat_language") || "hinglish";
}

function botSay(lines, actions = "") {
  const lang = getChatLanguage();
  return (lines[lang] || lines.en || lines.hinglish || Object.values(lines)[0]) + actions;
}

function setChatLanguage(lang) {
  localStorage.setItem("webconnect_chat_language", lang);
  const select = document.getElementById("chatLanguage");
  if (select) select.value = lang;

  addMessage("Bot", botSay({
    hinglish: `Done. Ab main ${chatLanguageNames[lang]} style me reply karne ki koshish karunga.`,
    en: `Done. I will now try to reply in ${chatLanguageNames[lang]}.`,
    hi: `ठीक है। अब मैं ${chatLanguageNames[lang]} में जवाब देने की कोशिश करूंगा।`,
    bn: `ঠিক আছে। এখন আমি ${chatLanguageNames[lang]} ভাষায় উত্তর দেওয়ার চেষ্টা করব।`,
    or: `ଠିକ ଅଛି। ଏବେ ମୁଁ ${chatLanguageNames[lang]} ଭାଷାରେ ଉତ୍ତର ଦେବାକୁ ଚେଷ୍ଟା କରିବି।`,
    ta: `சரி. இனிமேல் ${chatLanguageNames[lang]} மொழியில் பதில் சொல்ல முயற்சிப்பேன்.`,
    te: `సరే. ఇకపై ${chatLanguageNames[lang]} లో సమాధానం ఇవ్వడానికి ప్రయత్నిస్తాను.`,
    mr: `ठीक आहे. आता मी ${chatLanguageNames[lang]} मध्ये उत्तर देण्याचा प्रयत्न करेन.`,
    gu: `બરાબર. હવે હું ${chatLanguageNames[lang]} માં જવાબ આપવાનો પ્રયત્ન કરીશ.`,
    es: `Listo. Ahora intentaré responder en ${chatLanguageNames[lang]}.`,
    fr: `D'accord. Je vais maintenant essayer de répondre en ${chatLanguageNames[lang]}.`,
    de: `Okay. Ich werde jetzt versuchen, auf ${chatLanguageNames[lang]} zu antworten.`
  }));
}

function escapeHTML(text) {
  return String(text).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

function titleCase(text) {
  return text
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, char => char.toUpperCase());
}

function randomReply(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getUserName() {
  return localStorage.getItem("webconnect_user_name") || "";
}

function rememberUserName(message) {
  const match = message.match(/(?:my name is|call me|mera naam|naam hai)\s+([a-zA-Z ]{2,30})/i);
  if (!match) return "";

  const name = match[1].trim().split(/\s+/).slice(0, 3).join(" ");
  localStorage.setItem("webconnect_user_name", name);
  return name;
}

function makeAction(label, value, type = "page") {
  return `<button class="bot-action" type="button" onclick="${type === "url" ? `window.location.href='${value}'` : `quickMsg('${value}')`}">${label}</button>`;
}

function actionRow(actions) {
  return `<div class="bot-actions">${actions.join("")}</div>`;
}

function findPageMatch(msg) {
  if (typeof pages === "undefined") return null;

  if (pages[msg]) return { key: msg, url: pages[msg] };

  for (let key in pages) {
    if (msg.includes(key) || key.includes(msg)) {
      return { key, url: pages[key] };
    }
  }

  return null;
}

function findWebsiteMatch(msg) {
  if (typeof websites === "undefined") return null;

  return websites.find(site => {
    const name = site.name.toLowerCase();
    const category = site.category.toLowerCase();
    return name === msg || msg.includes(name) || name.includes(msg) || msg.includes(category);
  });
}

function recommendationReply(type) {
  const bundles = {
    ai: ["ChatGPT", "Gemini", "Perplexity", "Claude", "Leonardo AI"],
    job: ["LinkedIn", "Naukri", "Indeed", "Internshala", "Remote OK"],
    study: ["Coursera", "Khan Academy", "NPTEL", "Swayam", "MIT OpenCourseWare"],
    coding: ["GitHub", "Stack Overflow", "FreeCodeCamp", "W3Schools", "GeeksforGeeks"],
    design: ["Canva", "Figma", "Pixlr", "Behance", "Dribbble"],
    shopping: ["Amazon", "Flipkart", "Myntra", "Meesho", "Nykaa"]
  };

  const picks = bundles[type] || bundles.ai;
  const cards = picks.map(name => {
    const site = websites.find(item => item.name.toLowerCase() === name.toLowerCase());
    const url = site ? site.url : `https://www.google.com/search?q=${encodeURIComponent(name)}`;
    return `<button class="bot-mini-card" type="button" onclick="window.location.href='${url}'"><strong>${name}</strong><small>Open resource</small></button>`;
  }).join("");

  return `Bilkul. ${titleCase(type)} ke liye ye resources kaafi useful rahenge:<div class="bot-mini-grid">${cards}</div>`;
}

function smartPlanReply(type) {
  const plans = {
    study: {
      title: "Study roadmap",
      steps: ["Goal choose karo", "Course/tutorial open karo", "Daily practice set karo", "Exam/results resources save karo"],
      actions: [makeAction("Courses", "online-courses"), makeAction("Tutorials", "tutorials"), makeAction("Exams", "exams")]
    },
    job: {
      title: "Career roadmap",
      steps: ["Resume polish karo", "Job boards shortlist karo", "Interview prep start karo", "Remote/internship options compare karo"],
      actions: [makeAction("Resume", "resume"), makeAction("Jobs", "jobs"), makeAction("Interview", "interview")]
    },
    coding: {
      title: "Coding roadmap",
      steps: ["Docs aur basics revise karo", "DSA/practice platform open karo", "GitHub project banao", "Developer tools use karo"],
      actions: [makeAction("Coding", "coding"), makeAction("DSA", "data"), makeAction("Developer", "developer")]
    },
    daily: {
      title: "Daily shortcut path",
      steps: ["Govt/services page open karo", "Banking/maps/weather shortcuts save karo", "Useful tools recent me rakho"],
      actions: [makeAction("Govt", "govt"), makeAction("Banking", "bank"), makeAction("Weather", "weather")]
    }
  };
  const plan = plans[type] || plans.study;
  return `<b>${plan.title}</b><div class="bot-thinking-card">${plan.steps.map((step, index) => `<span><b>${index + 1}</b>${step}</span>`).join("")}</div>${actionRow(plan.actions)}`;
}

function safeMathAnswer(msg) {
  const expression = msg
    .replace(/what is|calculate|solve|kitna|kya hai|equals|=/gi, "")
    .replace(/plus/gi, "+")
    .replace(/minus/gi, "-")
    .replace(/times|multiply|into/gi, "*")
    .replace(/divide|divided by/gi, "/")
    .trim();

  if (!/^[\d+\-*/().\s%]+$/.test(expression) || !/\d/.test(expression)) return "";

  try {
    const result = Function(`"use strict"; return (${expression})`)();
    if (!Number.isFinite(result)) return "";
    return botSay({
      hinglish: `Answer: <b>${result}</b>`,
      en: `Answer: <b>${result}</b>`,
      hi: `उत्तर: <b>${result}</b>`,
      bn: `উত্তর: <b>${result}</b>`,
      or: `ଉତ୍ତର: <b>${result}</b>`,
      ta: `பதில்: <b>${result}</b>`,
      te: `సమాధానం: <b>${result}</b>`,
      mr: `उत्तर: <b>${result}</b>`,
      gu: `જવાબ: <b>${result}</b>`,
      es: `Respuesta: <b>${result}</b>`,
      fr: `Réponse : <b>${result}</b>`,
      de: `Antwort: <b>${result}</b>`
    });
  } catch (error) {
    return "";
  }
}

function generalQuestionReply(original, msg) {
  const math = safeMathAnswer(msg);
  if (math) return math;

  if (/(time|samay|समय|date|today|aaj|आज)/.test(msg)) {
    const now = new Date();
    return botSay({
      hinglish: `Abhi time hai <b>${now.toLocaleTimeString()}</b> aur date hai <b>${now.toLocaleDateString()}</b>.`,
      en: `The current time is <b>${now.toLocaleTimeString()}</b> and today's date is <b>${now.toLocaleDateString()}</b>.`,
      hi: `अभी समय <b>${now.toLocaleTimeString()}</b> है और तारीख <b>${now.toLocaleDateString()}</b> है।`,
      bn: `এখন সময় <b>${now.toLocaleTimeString()}</b> এবং আজকের তারিখ <b>${now.toLocaleDateString()}</b>।`,
      or: `ବର୍ତ୍ତମାନ ସମୟ <b>${now.toLocaleTimeString()}</b> ଏବଂ ତାରିଖ <b>${now.toLocaleDateString()}</b>।`,
      ta: `இப்போது நேரம் <b>${now.toLocaleTimeString()}</b>, தேதி <b>${now.toLocaleDateString()}</b>.`,
      te: `ప్రస్తుత సమయం <b>${now.toLocaleTimeString()}</b>, తేదీ <b>${now.toLocaleDateString()}</b>.`,
      mr: `आत्ता वेळ <b>${now.toLocaleTimeString()}</b> आणि तारीख <b>${now.toLocaleDateString()}</b> आहे.`,
      gu: `હમણાં સમય <b>${now.toLocaleTimeString()}</b> અને તારીખ <b>${now.toLocaleDateString()}</b> છે.`,
      es: `La hora actual es <b>${now.toLocaleTimeString()}</b> y la fecha es <b>${now.toLocaleDateString()}</b>.`,
      fr: `Il est <b>${now.toLocaleTimeString()}</b> et la date est <b>${now.toLocaleDateString()}</b>.`,
      de: `Die aktuelle Uhrzeit ist <b>${now.toLocaleTimeString()}</b> und das Datum ist <b>${now.toLocaleDateString()}</b>.`
    });
  }

  const facts = [
    {
      test: /(capital of india|india capital|bharat ki rajdhani|भारत की राजधानी)/,
      answer: {
        hinglish: "India ki capital <b>New Delhi</b> hai.",
        en: "The capital of India is <b>New Delhi</b>.",
        hi: "भारत की राजधानी <b>नई दिल्ली</b> है."
      }
    },
    {
      test: /(what is ai|ai kya hai|artificial intelligence)/,
      answer: {
        hinglish: "<b>AI</b> ya Artificial Intelligence computer systems ko learning, reasoning aur problem-solving jaise tasks karne ki ability deta hai.",
        en: "<b>AI</b>, or Artificial Intelligence, lets computer systems perform tasks like learning, reasoning, and problem-solving.",
        hi: "<b>AI</b> यानी Artificial Intelligence कंप्यूटर सिस्टम को सीखने, सोचने और समस्या हल करने जैसे काम करने में मदद करता है."
      }
    },
    {
      test: /(what is html|html kya hai)/,
      answer: {
        hinglish: "<b>HTML</b> website ka structure banata hai. Headings, paragraphs, links, images aur sections HTML se define hote hain.",
        en: "<b>HTML</b> builds the structure of a website: headings, paragraphs, links, images, and sections.",
        hi: "<b>HTML</b> वेबसाइट का structure बनाता है: headings, paragraphs, links, images और sections."
      }
    },
    {
      test: /(what is css|css kya hai)/,
      answer: {
        hinglish: "<b>CSS</b> website ko style deta hai: colors, layout, spacing, fonts, animations aur responsive design.",
        en: "<b>CSS</b> styles a website: colors, layout, spacing, fonts, animations, and responsive design.",
        hi: "<b>CSS</b> वेबसाइट को style देता है: colors, layout, spacing, fonts, animations और responsive design."
      }
    },
    {
      test: /(what is javascript|javascript kya hai|js kya hai)/,
      answer: {
        hinglish: "<b>JavaScript</b> website me interaction add karta hai, jaise search, chatbot, buttons, animations aur dynamic content.",
        en: "<b>JavaScript</b> adds interaction to websites, like search, chatbots, buttons, animations, and dynamic content.",
        hi: "<b>JavaScript</b> वेबसाइट में interaction add करता है, जैसे search, chatbot, buttons और animations."
      }
    }
  ];

  const fact = facts.find(item => item.test.test(msg));
  if (fact) return botSay(fact.answer);

  if (/(who is|what is|where is|why|how|kaun|kya|kaha|kab|kaise)/.test(msg)) {
    const query = encodeURIComponent(original);
    return botSay({
      hinglish: "Is question ka exact offline answer mere paas nahi hai, par main tumhare liye reliable search open kar sakta hoon.",
      en: "I do not have an exact offline answer for that, but I can open a reliable search for you.",
      hi: "इसका exact offline जवाब मेरे पास नहीं है, लेकिन मैं आपके लिए search खोल सकता हूँ।",
      bn: "এর সঠিক offline উত্তর আমার কাছে নেই, তবে আমি আপনার জন্য search খুলতে পারি।",
      or: "ଏହାର ସଠିକ offline ଉତ୍ତର ମୋ ପାଖରେ ନାହିଁ, କିନ୍ତୁ search ଖୋଲିପାରିବି।",
      ta: "இதற்கான சரியான offline பதில் என்னிடம் இல்லை, ஆனால் search திறக்க முடியும்.",
      te: "దీనికి ఖచ్చితమైన offline సమాధానం నా దగ్గర లేదు, కానీ search తెరవగలను.",
      mr: "याचे exact offline उत्तर माझ्याकडे नाही, पण मी search उघडू शकतो.",
      gu: "આનો exact offline જવાબ મારી પાસે નથી, પણ હું search ખોલી શકું છું.",
      es: "No tengo una respuesta offline exacta, pero puedo abrir una búsqueda confiable.",
      fr: "Je n'ai pas de réponse hors ligne exacte, mais je peux ouvrir une recherche fiable.",
      de: "Ich habe keine genaue Offline-Antwort, kann aber eine zuverlässige Suche öffnen."
    }, actionRow([
      makeAction("Google", `https://www.google.com/search?q=${query}`, "url"),
      makeAction("Wikipedia", `https://en.wikipedia.org/wiki/Special:Search?search=${query}`, "url")
    ]));
  }

  return "";
}

function getReply(message) {
  const original = message.trim();
  const msg = original.toLowerCase();
  const rememberedName = rememberUserName(original);
  const name = rememberedName || getUserName();
  const greetingName = name ? ` ${escapeHTML(name)}` : "";

  if (/(language|bhasha|भाषा|lang)/.test(msg)) {
    return botSay({
      hinglish: "Language dropdown chat header me hai. Wahan se Hinglish, English, Hindi, Bengali, Odia, Tamil, Telugu, Marathi, Gujarati, Spanish, French ya German select kar sakte ho.",
      en: "The language dropdown is in the chat header. You can choose Hinglish, English, Hindi, Bengali, Odia, Tamil, Telugu, Marathi, Gujarati, Spanish, French, or German.",
      hi: "Language dropdown chat header में है। वहाँ से भाषा select कर सकते हो।"
    });
  }

  if (rememberedName) {
    return botSay({
      hinglish: `Nice to meet you${greetingName}. Main yaad rakhunga. Ab batao, tumhe websites explore karni hain, study resources chahiye, ya career help?`,
      en: `Nice to meet you${greetingName}. I will remember your name. Would you like websites, study resources, or career help?`,
      hi: `आपसे मिलकर अच्छा लगा${greetingName}. मैं आपका नाम याद रखूंगा। वेबसाइट, study resources या career help चाहिए?`
    }, actionRow([
      makeAction("Study", "education"),
      makeAction("Jobs", "jobs"),
      makeAction("AI Tools", "ai")
    ]));
  }

  if (/(hi|hello|hey|namaste|hii|helo|hy)\b/.test(msg)) {
    return randomReply([
      `Hey${greetingName}, main yahin hoon. Tum bas batao kya find karna hai, main direct route dikha dunga.`,
      `Hi${greetingName}. WebConnect me AI, jobs, study, tools, shopping, govt services sab organized hai. Kahan chalna hai?`,
      `Hello${greetingName}. Aaj kya explore karein: learning, career, coding, ya useful daily websites?`
    ]) + actionRow(chatSuggestions.map(item => makeAction(item.label, item.query)));
  }

  if (/(kaise ho|how are you|kya haal|feel|feeling)/.test(msg)) {
    return "Main kaafi ready mode me hoon. Real feelings mere paas human jaise nahi hain, par tumhare liye helpful, calm aur responsive rehne ki full koshish karunga.";
  }

  if (/(thanks|thank you|shukriya|dhanyavad|nice|good|great)/.test(msg)) {
    return randomReply([
      "Always. Tumhara flow smooth rahe, wahi goal hai.",
      "Most welcome. Next kya improve ya explore karna hai?",
      "Happy to help. Chalo, next step batao."
    ]);
  }

  if (/(about|webconnect|website|ye site|is site|features|kya hai)/.test(msg)) {
    return `<b>${botProfile.site}</b> ek smart website directory hai jahan best websites, tools aur resources categories me organized hain. Isme search, voice search, trending sites, Smart Hub, favorites, recent visits, daily picks, category filters aur quick command search bhi hai.${actionRow([
      makeAction("Features", "features"),
      makeAction("All Categories", "all"),
      makeAction("More", "more")
    ])}`;
  }

  if (/(creator|developer|owner|kisne banaya|made|banaya)/.test(msg)) {
    return `Ye website <b>${botProfile.creator}</b> ne banayi hai. Footer me social links bhi diye gaye hain jahan se tum creator se connect kar sakte ho.${actionRow([
      makeAction("About", "about"),
      makeAction("Contact", "contact")
    ])}`;
  }

  if (/(help|guide|kaise use|use kaise|how to use)/.test(msg)) {
    return `Simple hai: search box me keyword type karo, categories browse karo, Smart Hub se shortcuts lo, favorite save karo, ya mujhe message bhejo. Main page open karne, website suggest karne aur WebConnect explain karne me help kar sakta hoon.${actionRow([
      makeAction("AI Tools", "ai"),
      makeAction("Jobs", "jobs"),
      makeAction("Education", "education"),
      makeAction("Govt Services", "govt")
    ])}`;
  }

  if (/(plan|roadmap|routine|prepare|preparation|kaise start|start kaise)/.test(msg)) {
    if (/(job|career|intern|resume|remote|interview)/.test(msg)) return smartPlanReply("job");
    if (/(code|coding|developer|programming|dsa|web dev)/.test(msg)) return smartPlanReply("coding");
    if (/(govt|government|bank|weather|daily|service)/.test(msg)) return smartPlanReply("daily");
    return smartPlanReply("study");
  }

  if (/(best|suggest|recommend|resource|tools|chahiye|batao)/.test(msg)) {
    if (/(job|career|intern|resume|remote)/.test(msg)) return recommendationReply("job");
    if (/(study|education|course|exam|student|learn)/.test(msg)) return recommendationReply("study");
    if (/(code|coding|developer|programming|web dev)/.test(msg)) return recommendationReply("coding");
    if (/(design|photo|video|ui|ux|canva|figma)/.test(msg)) return recommendationReply("design");
    if (/(shop|shopping|buy)/.test(msg)) return recommendationReply("shopping");
    return recommendationReply("ai");
  }

  if (/(sad|tension|stress|problem|confused|pareshan|low feel)/.test(msg)) {
    return "Samajh raha hoon. Thoda slow lete hain. Tum mujhe bas ek word batao: study, job, coding, AI, ya personal productivity. Main tumhe next clear step de dunga.";
  }

  const generalAnswer = generalQuestionReply(original, msg);
  if (generalAnswer) return generalAnswer;

  const page = findPageMatch(msg);
  if (page) {
    return `Mil gaya: <b>${titleCase(page.key)}</b>. Main is page ko open kar sakta hoon.${actionRow([
      makeAction(`Open ${titleCase(page.key)}`, page.key)
    ])}`;
  }

  const site = findWebsiteMatch(msg);
  if (site) {
    return `Mujhe <b>${site.name}</b> mila. Category: ${site.category}.${actionRow([
      makeAction(`Open ${site.name}`, site.url, "url")
    ])}`;
  }

  if (typeof getSearchSuggestions === "function") {
    const smartMatches = getSearchSuggestions(original, 4).filter(item => item.type !== "google");
    if (smartMatches.length) {
      return `Maine tumhare query ke liye smart matches nikale hain. Inme se direct open kar sakte ho:${actionRow(
        smartMatches.map(item => makeAction(item.name.slice(0, 24), item.url, "url"))
      )}`;
    }
  }

  return `Iska exact match mujhe WebConnect me nahi mila, par main Google search open kar sakta hoon ya tum simpler keyword try kar sakte ho: AI, jobs, coding, education, shopping.${actionRow([
    makeAction("Search Google", `https://www.google.com/search?q=${encodeURIComponent(original)}`, "url"),
    makeAction("AI Tools", "ai"),
    makeAction("More Categories", "more")
  ])}`;
}

function sendMessage() {
  const input = document.getElementById("userInput");
  const raw = input.value.trim();
  if (!raw) return;

  addMessage("You", escapeHTML(raw));
  input.value = "";
  showTyping(raw);

  const delay = Math.min(1500, Math.max(650, raw.length * 22));
  setTimeout(() => {
    removeTyping();
    addMessage("Bot", getReply(raw));
  }, delay);
}

function addMessage(sender, text) {
  const box = document.getElementById("chat-messages");
  if (!box) return;

  const div = document.createElement("div");
  div.classList.add("chat-msg", sender === "You" ? "user-msg" : "bot-msg");

  const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  div.innerHTML = `<div class="msg-text">${text}</div><span class="msg-time">${time}</span>`;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function getThinkingLabel(message = "") {
  const msg = String(message).toLowerCase();
  if (/(job|resume|career|intern|remote)/.test(msg)) return "Checking career paths";
  if (/(study|exam|course|learn|student)/.test(msg)) return "Building a study route";
  if (/(code|coding|developer|ai|tool|api)/.test(msg)) return "Scanning useful tools";
  if (/(govt|government|bank|weather|map|service)/.test(msg)) return "Finding daily shortcuts";
  return "Thinking through your request";
}

function showTyping(message = "") {
  const box = document.getElementById("chat-messages");
  if (!box || document.getElementById("typing")) return;

  const t = document.createElement("div");
  t.id = "typing";
  t.className = "chat-msg bot-msg typing-msg";
  t.innerHTML = `
    <div class="thinking-copy">
      <strong>WebConnect AI is thinking</strong>
      <small>${getThinkingLabel(message)}</small>
    </div>
    <div class="thinking-dots"><i></i><i></i><i></i></div>
  `;
  box.appendChild(t);
  box.scrollTop = box.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById("typing");
  if (t) t.remove();
}

const userInputEl = document.getElementById("userInput");
if (userInputEl) {
  userInputEl.addEventListener("keypress", function(e) {
    if (e.key === "Enter") sendMessage();
  });
}

function runChatPrompt(prompt) {
  const input = document.getElementById("userInput");
  if (!input) return;
  input.value = prompt;
  sendMessage();
}

function renderChatSmartPrompts() {
  const box = document.getElementById("suggestions-box");
  if (!box || box.dataset.ready === "true") return;

  box.dataset.ready = "true";
  box.innerHTML = chatSmartPrompts
    .map(item => `<button type="button" onclick="runChatPrompt('${item.prompt.replace(/'/g, "\\'")}')">${item.label}</button>`)
    .join("");
}

document.addEventListener("DOMContentLoaded", () => {
  const box = document.getElementById("chat-messages");
  const select = document.getElementById("chatLanguage");
  const input = document.getElementById("userInput");
  renderChatSmartPrompts();
  if (select) select.value = getChatLanguage();
  if (input) {
    input.placeholder = botSay({
      hinglish: "Kuch bhi poochho...",
      en: "Ask anything...",
      hi: "कुछ भी पूछें...",
      bn: "যেকোনো কিছু জিজ্ঞাসা করুন...",
      or: "କିଛି ବି ପଚାରନ୍ତୁ...",
      ta: "எதையும் கேளுங்கள்...",
      te: "ఏదైనా అడగండి...",
      mr: "काहीही विचारा...",
      gu: "કંઈપણ પૂછો...",
      es: "Pregunta lo que quieras...",
      fr: "Posez n'importe quelle question...",
      de: "Frag etwas..."
    });
  }
  if (!box || box.dataset.ready === "true") return;

  box.dataset.ready = "true";
  const name = getUserName();
  const intro = botSay({
    hinglish: `Hi${name ? " " + escapeHTML(name) : ""}, main WebConnect Assistant hoon. Tum mujhse normal questions, maths, time/date, website ke baare me, tools, jobs, study resources ya kisi category ka shortcut pooch sakte ho.`,
    en: `Hi${name ? " " + escapeHTML(name) : ""}, I am WebConnect Assistant. You can ask normal questions, math, time/date, website info, tools, jobs, study resources, or category shortcuts.`,
    hi: `नमस्ते${name ? " " + escapeHTML(name) : ""}, मैं WebConnect Assistant हूँ। आप normal questions, maths, time/date, website info, tools, jobs, study resources या category shortcuts पूछ सकते हैं।`
  });
  addMessage("Bot", intro + actionRow(chatSuggestions.map(item => makeAction(item.label, item.query))));
  box.dataset.introAdded = "true";
});
function quickMsg(type) {
  const cleanType = String(type).toLowerCase().trim();
  addMessage("You", escapeHTML(type));

  let page = pages[cleanType];
  if (!page) {
    for (let key in pages) {
      if (cleanType.includes(key) || key.includes(cleanType)) {
        page = pages[key];
        type = key;
        break;
      }
    }
  }

  if (page) {
    addMessage("Bot", `Opening <b>${titleCase(type)}</b> for you.`);
    setTimeout(() => {
      window.location.href = page;
    }, 450);
  } else {
    addMessage("Bot", getReply(cleanType));
  }
}



// ================= VOICE INPUT =================
const micBtn = document.getElementById("mic-btn");

if (micBtn && 'webkitSpeechRecognition' in window) {

  const recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.lang = "en-IN"; // Hinglish support

  micBtn.onclick = () => {
    recognition.start();
    micBtn.innerText = "🎙️";
    micBtn.title = "Listening...";
    micBtn.classList.add("is-listening");
  };

  recognition.onresult = (event) => {
    const speech = event.results[0][0].transcript;

    document.getElementById("userInput").value = speech;

    micBtn.innerText = "🎤";
    micBtn.title = "Voice search";
    micBtn.classList.remove("is-listening");

    sendMessage(); // auto send
  };

  recognition.onerror = () => {
    micBtn.innerText = "🎤";
    micBtn.title = "Voice search";
    micBtn.classList.remove("is-listening");
    alert("Voice error, try again");
  };

  recognition.onend = () => {
    micBtn.innerText = "🎤";
    micBtn.title = "Voice search";
    micBtn.classList.remove("is-listening");
  };

} else if (micBtn) {
  micBtn.style.display = "none";
}











let activeSuggestionIndex = -1;
let currentSearchSuggestions = [];
let cachedSearchPool = null;
const searchSuggestionCache = new Map();

function normalizeSearchText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[-_]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const FIREBASE_ANALYTICS_CONFIG = {
  apiKey: "AIzaSyDSm0RTj_-tvldd0WvL8n13hTYRQPaqN0Q",
  authDomain: "webconnect-c3fa0.firebaseapp.com",
  projectId: "webconnect-c3fa0",
  storageBucket: "webconnect-c3fa0.firebasestorage.app",
  messagingSenderId: "939049509561",
  appId: "1:939049509561:web:d66398762d6c6c0e427168",
  measurementId: "G-MPWM1BG4E7"
};

function getAnalyticsDb() {
  if (typeof firebase === "undefined" || !firebase.firestore) return null;
  if (!firebase.apps.length) {
    firebase.initializeApp(FIREBASE_ANALYTICS_CONFIG);
  }
  return firebase.firestore();
}

async function trackAnalyticsEvent(payload) {
  const db = getAnalyticsDb();
  if (!db) return;
  try {
    await db.collection("analytics_events").add({
      ...payload,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  } catch (error) {
    console.warn("Search analytics failed", error);
  }
}

function niceSearchName(value) {
  return String(value || "")
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\.html$/, "")
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, char => char.toUpperCase());
}

function getSearchDomain(url) {
  if (!url) return "";
  if (url.includes(".html")) return url;

  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url.replace(/^https?:\/\//, "").replace(/^www\./, "");
  }
}

function escapeSearchHtml(value) {
  return String(value || "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}

const megaResourceCategories = [
  "AI tools", "coding", "developer docs", "government services", "scholarships",
  "jobs", "internships", "remote jobs", "resume builder", "interview prep",
  "online courses", "tutorials", "cyber security", "cloud computing", "DevOps",
  "banking", "insurance", "health services", "maps", "weather", "shopping",
  "finance", "stock market", "business", "startups", "design tools", "photo editing",
  "video editing", "productivity", "research", "science", "mathematics", "history",
  "language learning", "books", "news", "sports", "travel", "food delivery",
  "legal help", "public utilities", "open source", "templates", "APIs",
  "hospitals", "universities", "admit cards", "question papers", "results",
  "certifications", "competitive programming", "data structures", "system design",
  "testing", "downloads", "UI UX", "animation", "3D design", "blockchain",
  "IoT", "robotics", "electronics", "hardware", "networking", "AR VR",
  "local services", "delivery services", "police services", "government portals",
  "real estate", "crypto", "economics", "astronomy", "environment", "agriculture",
  "images", "photography", "videography", "music", "podcasts", "blogging",
  "vlogging", "art craft", "memes", "quotes", "kids", "parenting", "cooking",
  "fashion", "home decor", "DIY", "communities", "forums", "events", "NGO",
  "donations", "religion spiritual", "personality development", "soft skills",
  "public speaking", "motivation"
];

const megaResourceIntents = [
  "best", "official", "free", "top", "beginner", "advanced", "India", "global",
  "tools", "platforms", "resources", "guide", "portal", "directory", "learning",
  "practice", "download", "compare", "latest", "student", "career", "creator",
  "developer", "mobile friendly", "safe", "verified"
];

function getMegaResourcePaths() {
  const paths = [];
  megaResourceCategories.forEach(category => {
    megaResourceIntents.forEach(intent => {
      megaResourceIntents.forEach(secondIntent => {
        if (intent === secondIntent) return;
        const name = `${niceSearchName(intent)} ${niceSearchName(category)} ${niceSearchName(secondIntent)}`;
        const query = `${intent} ${category} ${secondIntent}`;
        paths.push({
          name,
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
          category: "Smart Resource Path",
          type: "mega"
        });
      });
    });
  });
  return paths.slice(0, 10000);
}

let cachedMegaResourcePaths = null;

const alwaysIndexedPages = [
  "index.html", "all.html", "popular.html", "features.html", "about.html", "contact.html",
  "ai.html", "jobs.html", "education.html", "developer.html", "govt.html", "more.html",
  "hospitals.html", "universities.html", "exams.html", "government-schemes.html",
  "scholarships.html", "internships.html", "remote-jobs.html", "freelancing.html",
  "freelance-tools.html", "career-guidance.html", "resume-builder.html", "interview-prep.html",
  "results.html", "admit-cards.html", "question-papers.html", "certifications.html",
  "online-courses.html", "tutorials.html", "research.html", "start-learning.html",
  "competitive-programming.html", "algorithms.html", "data-structures.html", "system-design.html",
  "testing.html", "devops.html", "apis.html", "open-data.html", "government-portals.html",
  "public-utilities.html", "health-services.html", "police-services.html", "legal-help.html",
  "banking.html", "insurance.html", "real-estate.html", "maps-navigation.html", "weather.html",
  "local-services.html", "delivery-services.html", "opensource.html", "downloads.html",
  "templates.html", "ui-ux.html", "photo-editing.html", "video-editing.html", "animation.html",
  "3d-design.html", "printing.html", "blockchain.html", "iot.html", "robotics.html",
  "electronics.html", "hardware.html", "networking.html", "ar-vr.html", "startups.html",
  "business.html", "stock-market.html", "crypto.html", "economics.html", "science.html",
  "mathematics.html", "history.html", "geography.html", "languages.html", "astronomy.html",
  "environment.html", "agriculture.html", "images.html", "photography.html", "videography.html",
  "music.html", "podcasts.html", "podcasting-tools.html", "books.html", "ebooks.html",
  "blogging.html", "vlogging.html", "art-craft.html", "memes.html", "quotes.html",
  "kids.html", "parenting.html", "cooking.html", "food.html", "lifestyle.html", "fashion.html",
  "home-decor.html", "diy.html", "communities.html", "forums.html", "events.html", "ngo.html",
  "donations.html", "religion-spiritual.html", "personality-development.html", "soft-skills.html",
  "public-speaking.html", "motivation.html", "shopping.html", "travel.html", "health.html",
  "sports.html", "social.html", "entertainment.html", "games.html", "design.html", "tools.html",
  "cloud.html", "coding.html", "cyber.html", "finance.html", "productivity.html", "communication.html",
  "news.html", "resources/help.html", "resources/updates.html", "resources/privacy.html",
  "resources/terms.html", "resources/sitemap.html"
];

function highlightSearchMatch(text, query) {
  const safeText = escapeSearchHtml(text);
  const cleanQuery = normalizeSearchText(query);
  if (!cleanQuery) return safeText;

  const index = normalizeSearchText(text).indexOf(cleanQuery);
  if (index < 0) return safeText;

  const original = String(text || "");
  return `${escapeSearchHtml(original.slice(0, index))}<mark>${escapeSearchHtml(original.slice(index, index + cleanQuery.length))}</mark>${escapeSearchHtml(original.slice(index + cleanQuery.length))}`;
}

function getSearchPool() {
  if (cachedSearchPool) return cachedSearchPool;

  const pool = [];
  const seen = new Set();

  function addSearchItem(item) {
    if (!item || !item.url) return;
    const key = String(item.url).toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    const isPage = item.url.includes(".html");
    pool.push({
      name: item.name || niceSearchName(item.url),
      url: item.url,
      category: item.category || (isPage ? "WebConnect Page" : "Website"),
      type: item.type || (isPage ? "page" : "website"),
      source: item.source || item,
      searchText: normalizeSearchText(`${item.name || niceSearchName(item.url)} ${item.category || ""} ${item.url} ${getSearchDomain(item.url)}`)
    });
  }

  if (typeof websites !== "undefined") {
    websites.forEach(site => {
      addSearchItem({
        name: site.name || niceSearchName(site.url),
        url: site.url,
        category: site.category || (site.url.includes(".html") ? "Pages" : "Website"),
        type: site.url.includes(".html") ? "page" : "website",
        source: site
      });
    });
  }

  if (typeof pages !== "undefined") {
    Object.entries(pages).forEach(([name, url]) => {
      addSearchItem({
        name: niceSearchName(name),
        url,
        category: url.includes(".html") ? "WebConnect Page" : "Popular Website",
        type: url.includes(".html") ? "page" : "website"
      });
    });
  }

  alwaysIndexedPages.forEach(url => {
    addSearchItem({
      name: niceSearchName(url),
      url,
      category: "WebConnect Page",
      type: "page"
    });
  });

  cachedSearchPool = pool;
  return cachedSearchPool;
}

function scoreSearchItem(item, query) {
  const q = normalizeSearchText(query);
  const name = normalizeSearchText(item.name);
  const category = normalizeSearchText(item.category);
  const domain = normalizeSearchText(getSearchDomain(item.url));
  const haystack = item.searchText || `${name} ${category} ${domain}`;
  const words = q.split(" ").filter(Boolean);

  if (!q) return 0;
  if (name === q) return 1000;
  if (domain === q || domain.startsWith(`${q}.`)) return 920;
  if (name.startsWith(q)) return 860;
  if (category === q) return 835;
  if (domain.startsWith(q)) return 800;
  if (category.startsWith(q)) return 760;
  if (haystack.includes(q)) return 680;
  if (words.every(word => haystack.includes(word))) return 560;
  if (words.some(word => name.startsWith(word) || category.startsWith(word))) return 390;
  if (words.some(word => haystack.includes(word))) return 240;

  return Math.max(
    fuzzySearchScore(name, q),
    fuzzySearchScore(category, q) - 12,
    fuzzySearchScore(domain, q) - 18
  );
}

function fuzzySearchScore(text, query) {
  if (!text || !query || query.length < 2) return 0;
  let queryIndex = 0;
  let gapPenalty = 0;

  for (let textIndex = 0; textIndex < text.length && queryIndex < query.length; textIndex += 1) {
    if (text[textIndex] === query[queryIndex]) {
      queryIndex += 1;
    } else if (queryIndex > 0) {
      gapPenalty += 1;
    }
  }

  if (queryIndex !== query.length) return 0;
  return Math.max(90, 210 - gapPenalty * 9 - Math.max(0, text.length - query.length));
}

function readSearchStore(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch (error) {
    return fallback;
  }
}

function getSearchPopularityBoost(item, popularity) {
  const name = normalizeSearchText(item.name);
  const category = normalizeSearchText(item.category);
  return ((popularity.hero.searches?.[name] || 0) + (popularity.activity.searches?.[name] || 0)) * 18 +
    ((popularity.hero.categories?.[category] || 0) + (popularity.activity.categories?.[category] || 0)) * 10 +
    (popularity.activity.sites?.[name] || 0) * 14;
}

function getRecentSearchSuggestionItems(query) {
  const q = normalizeSearchText(query);
  return readSearchStore("wc_recent_searches_v2", [])
    .map(item => item.query)
    .filter(Boolean)
    .filter(item => scoreSearchItem({ name: item, category: "Recent Search", url: "" }, q) > 0)
    .slice(0, 4)
    .map((item, index) => ({
      name: item,
      url: `https://www.google.com/search?q=${encodeURIComponent(item)}`,
      category: "Recent Search",
      type: "recent",
      score: 970 - index
    }));
}

function getSearchSuggestions(query, limit = 32) {
  const q = normalizeSearchText(query);
  if (!q) return [];
  const directUrl = getDirectUrlFromQuery(query);
  const cacheKey = `${q}::${limit}`;
  if (searchSuggestionCache.has(cacheKey)) return searchSuggestionCache.get(cacheKey);

  const popularity = {
    hero: readSearchStore("wc_hero_search_intel_v1", { searches: {}, categories: {} }),
    activity: readSearchStore("wc_activity_v2", { searches: {}, categories: {}, sites: {} })
  };

  const results = getSearchPool()
    .map(item => ({ ...item, score: scoreSearchItem(item, q) + getSearchPopularityBoost(item, popularity) }))
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .slice(0, limit);

  getRecentSearchSuggestionItems(query).reverse().forEach(item => {
    const exists = results.some(result => normalizeSearchText(result.name) === normalizeSearchText(item.name));
    if (!exists) results.unshift(item);
  });

  if (directUrl) {
    results.unshift({
      name: `Open ${directUrl.replace(/^https?:\/\//, "")}`,
      url: directUrl,
      category: "Direct Website",
      type: "website",
      score: 990
    });
  }

  results.push({
    name: `Search Google for "${query.trim()}"`,
    url: `https://www.google.com/search?q=${encodeURIComponent(query.trim())}`,
    category: "Google Search",
    type: "google",
    score: 1
  });

  searchSuggestionCache.set(cacheKey, results);
  if (searchSuggestionCache.size > 80) {
    searchSuggestionCache.delete(searchSuggestionCache.keys().next().value);
  }

  return results;
}

function getDirectUrlFromQuery(query) {
  const clean = String(query || "")
    .trim()
    .replace(/^open\s+/i, "")
    .replace(/^go\s+to\s+/i, "");

  if (!clean || /\s/.test(clean)) return "";
  if (/^https?:\/\//i.test(clean)) return clean;
  if (/^[a-z0-9][a-z0-9-]*(\.[a-z0-9-]+)+([/?#].*)?$/i.test(clean)) {
    return `https://${clean}`;
  }
  return "";
}

function openSearchResult(item) {
  if (!item) return;

  const smartItem = {
    name: item.name,
    url: item.url,
    category: item.category
  };

  if (typeof trackHeroSearchPopularity === "function") {
    trackHeroSearchPopularity(item.name, smartItem);
  }

  if (typeof recordSmartVisit === "function" && item.type !== "google") {
    recordSmartVisit(smartItem);
  }

  if (typeof openSmartSite === "function" && item.type !== "google") {
    openSmartSite(smartItem);
    return;
  }

  window.location.href = item.url;
}

function showSuggestions() {
  const input = document.getElementById("searchInput");
  const box = document.getElementById("suggestionBox");
  if (!input || !box) return;

  const query = input.value.trim();
  box.innerHTML = "";
  activeSuggestionIndex = -1;
  currentSearchSuggestions = getSearchSuggestions(query);

  if (!query || !currentSearchSuggestions.length) {
    box.style.display = "none";
    return;
  }

  currentSearchSuggestions.forEach((item, index) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `suggestion-item ${item.type === "google" ? "google-suggestion" : ""}`;
    row.dataset.index = index;

    const icon = item.type === "page" ? "📄" : item.type === "google" ? "🔎" : "🌐";
    const action = item.type === "google" ? "Search" : item.type === "page" ? "Open page" : "Open site";
    const favText = typeof isFavorite === "function" && isFavorite(item.url) ? "★" : "☆";

    row.innerHTML = `
      <span class="suggestion-icon">${icon}</span>
      <span class="suggestion-copy">
        <strong>${highlightSearchMatch(item.name, query)}</strong>
        <small>${escapeSearchHtml(item.category)} · ${escapeSearchHtml(getSearchDomain(item.url))}</small>
      </span>
      <span class="suggestion-action">${action}</span>
    `;

    if (item.type !== "google") {
      const fav = document.createElement("span");
      fav.className = "suggestion-fav";
      fav.textContent = favText;
      fav.onclick = event => {
        event.stopPropagation();
        if (typeof toggleFavorite === "function") {
          toggleFavorite({ name: item.name, url: item.url, category: item.category });
          fav.textContent = isFavorite(item.url) ? "★" : "☆";
        }
      };
      row.appendChild(fav);
    }

    row.onclick = () => openSearchResult(item);
    box.appendChild(row);
  });

  box.style.display = "grid";
}

function updateActiveSuggestion(nextIndex) {
  const box = document.getElementById("suggestionBox");
  if (!box) return;

  const rows = [...box.querySelectorAll(".suggestion-item")];
  if (!rows.length) return;

  activeSuggestionIndex = (nextIndex + rows.length) % rows.length;
  rows.forEach((row, index) => row.classList.toggle("active", index === activeSuggestionIndex));
  rows[activeSuggestionIndex].scrollIntoView({ block: "nearest" });
}

function searchWebsite() {
  const input = document.getElementById("searchInput");
  if (!input) return;

  const query = input.value.trim();
  if (!query) return;
  if (typeof trackAnalyticsEvent === "function") {
    trackAnalyticsEvent({ type: "search", page: "index.html", query });
  }

  const selected = activeSuggestionIndex >= 0
    ? currentSearchSuggestions[activeSuggestionIndex]
    : getSearchSuggestions(query, 1)[0];

  openSearchResult(selected || {
    name: query,
    url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
    category: "Google Search",
    type: "google"
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("searchInput");
  const box = document.getElementById("suggestionBox");
  if (!input || !box) return;

  input.addEventListener("input", showSuggestions);
  input.addEventListener("focus", showSuggestions);
  input.addEventListener("keydown", event => {
    if (box.style.display === "none") return;

    if (event.key === "ArrowDown") {
      event.preventDefault();
      updateActiveSuggestion(activeSuggestionIndex + 1);
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      updateActiveSuggestion(activeSuggestionIndex - 1);
    }

    if (event.key === "Enter" && activeSuggestionIndex >= 0) {
      event.preventDefault();
      openSearchResult(currentSearchSuggestions[activeSuggestionIndex]);
    }

    if (event.key === "Escape") {
      box.style.display = "none";
    }
  });

  document.addEventListener("click", event => {
    if (!event.target.closest(".search-wrapper")) {
      box.style.display = "none";
    }
  });
});

// ===== MASTER WEBSITE DATABASE =====
const trendingWebsites = [

  // AI
  {name:"ChatGPT",url:"https://chat.openai.com"},
  {name:"Gemini AI",url:"https://gemini.google.com"},
  {name:"Claude AI",url:"https://claude.ai"},
  {name:"Perplexity",url:"https://perplexity.ai"},
  {name:"Notion AI",url:"https://notion.so"},
  {name:"Grammarly",url:"https://grammarly.com"},
  {name:"Quillbot",url:"https://quillbot.com"},
  {name:"Canva AI",url:"https://canva.com"},
  {name:"Copy.ai",url:"https://copy.ai"},
  {name:"Jasper",url:"https://jasper.ai"},

  // Shopping
  {name:"Amazon",url:"https://amazon.in"},
  {name:"Flipkart",url:"https://flipkart.com"},
  {name:"Myntra",url:"https://myntra.com"},
  {name:"Ajio",url:"https://ajio.com"},
  {name:"Nykaa",url:"https://nykaa.com"},
  {name:"Meesho",url:"https://meesho.com"},
  {name:"Reliance Digital",url:"https://reliancedigital.in"},
  {name:"Croma",url:"https://croma.com"},
  {name:"Tata Cliq",url:"https://tatacliq.com"},
  {name:"Snapdeal",url:"https://snapdeal.com"},

  // Social
  {name:"YouTube",url:"https://youtube.com"},
  {name:"Instagram",url:"https://instagram.com"},
  {name:"Facebook",url:"https://facebook.com"},
  {name:"Twitter",url:"https://twitter.com"},
  {name:"Snapchat",url:"https://snapchat.com"},
  {name:"WhatsApp",url:"https://web.whatsapp.com"},
  {name:"Telegram",url:"https://telegram.org"},
  {name:"LinkedIn",url:"https://linkedin.com"},
  {name:"Pinterest",url:"https://pinterest.com"},
  {name:"Reddit",url:"https://reddit.com"},

  // Entertainment
  {name:"Netflix",url:"https://netflix.com"},
  {name:"Hotstar",url:"https://hotstar.com"},
  {name:"Prime Video",url:"https://primevideo.com"},
  {name:"ZEE5",url:"https://zee5.com"},
  {name:"SonyLIV",url:"https://sonyliv.com"},
  {name:"Spotify",url:"https://spotify.com"},
  {name:"JioSaavn",url:"https://jiosaavn.com"},
  {name:"Gaana",url:"https://gaana.com"},
  {name:"SoundCloud",url:"https://soundcloud.com"},

  // Education
  {name:"Coursera",url:"https://coursera.org"},
  {name:"Udemy",url:"https://udemy.com"},
  {name:"Khan Academy",url:"https://khanacademy.org"},
  {name:"Unacademy",url:"https://unacademy.com"},
  {name:"BYJU'S",url:"https://byjus.com"},
  {name:"GeeksforGeeks",url:"https://geeksforgeeks.org"},
  {name:"W3Schools",url:"https://w3schools.com"},
  {name:"FreeCodeCamp",url:"https://freecodecamp.org"},
  {name:"LeetCode",url:"https://leetcode.com"},
  {name:"HackerRank",url:"https://hackerrank.com"},

  // Tools
  {name:"Google",url:"https://google.com"},
  {name:"Wikipedia",url:"https://wikipedia.org"},
  {name:"Zoom",url:"https://zoom.us"},
  {name:"Google Meet",url:"https://meet.google.com"},
  {name:"Microsoft Teams",url:"https://teams.microsoft.com"},
  {name:"Slack",url:"https://slack.com"},
  {name:"Figma",url:"https://figma.com"},
  {name:"Canva",url:"https://canva.com"},
  {name:"Notion",url:"https://notion.so"},
  {name:"Trello",url:"https://trello.com"},

  // Payments + Travel + Food
  {name:"Paytm",url:"https://paytm.com"},
  {name:"PhonePe",url:"https://phonepe.com"},
  {name:"Google Pay",url:"https://pay.google.com"},
  {name:"IRCTC",url:"https://irctc.co.in"},
  {name:"MakeMyTrip",url:"https://makemytrip.com"},
  {name:"Goibibo",url:"https://goibibo.com"},
  {name:"RedBus",url:"https://redbus.in"},
  {name:"Ola",url:"https://olacabs.com"},
  {name:"Uber",url:"https://uber.com"},
  {name:"Swiggy",url:"https://swiggy.com"},
  {name:"Zomato",url:"https://zomato.com"}
];


// ===== EXTRACT NAMES =====
const allTrending = trendingWebsites.map(w => w.name);


// ===== VARIABLES =====
let currentItems = [];
let currentIndex = 0;
let trendingRefreshSeed = 0;

let itemInterval;
let setIntervalId;

const container = document.getElementById("trendingContainer");
const searchInput = document.getElementById("searchInput");
const trendingRefreshBtn = document.getElementById("trendingRefreshBtn");


// ===== FAVICON =====
function getFavicon(url) {
  return `https://www.google.com/s2/favicons?sz=64&domain=${url}`;
}

const smartTrendingCategories = [
  { name: "Trending Now", query: "trending now", href: "all.html", keywords: ["popular", "today", "daily"] },
  { name: "Most Popular", query: "popular websites", href: "popular.html", keywords: ["popular", "top", "best"] },
  { name: "Student Favorites", query: "student learning resources", href: "education.html", keywords: ["student", "exam", "study", "scholarship"] },
  { name: "AI Tools", query: "AI Tools", href: "ai.html", keywords: ["ai", "chatgpt", "automation"] },
  { name: "Developer Resources", query: "Developer Tools", href: "developer.html", keywords: ["developer", "coding", "github", "api"] },
  { name: "Government Services", query: "Govt Services", href: "govt.html", keywords: ["govt", "government", "portal", "services"] },
  { name: "Jobs & Careers", query: "Jobs", href: "jobs.html", keywords: ["job", "career", "internship", "remote"] },
  { name: "Learning Resources", query: "Learning Resources", href: "online-courses.html", keywords: ["learning", "course", "tutorial"] },
  { name: "Finance Tools", query: "Finance", href: "finance.html", keywords: ["finance", "stock", "banking", "payment"] },
  { name: "Daily Essentials", query: "Daily Services", href: "public-utilities.html", keywords: ["weather", "maps", "health", "banking"] },
  { name: "Creator Tools", query: "Creator Tools", href: "design.html", keywords: ["design", "video", "photo", "content"] }
];

const smartTrendingBundles = [
  { label: "AI", words: ["AI Tools", "ChatGPT", "Gemini", "Perplexity", "Claude", "Canva AI", "Prompt Tools"] },
  { label: "Career", words: ["Jobs", "Remote Jobs", "Internships", "Resume Builder", "Interview Prep", "LinkedIn"] },
  { label: "Study", words: ["Scholarships", "Online Courses", "Python", "Exams", "Question Papers", "NPTEL"] },
  { label: "Developer", words: ["Developer Tools", "GitHub", "APIs", "Cloud", "DevOps", "System Design"] },
  { label: "Daily", words: ["Weather", "Banking", "Maps", "Govt Services", "News", "Health"] },
  { label: "Shopping", words: ["Amazon", "Flipkart", "Deals", "Fashion", "Electronics", "Food Delivery"] },
  { label: "Creator", words: ["Canva", "Figma", "Photo Editing", "Video Editing", "Music", "Templates"] }
];

function readTrendingStore(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch (error) {
    return fallback;
  }
}

function normalizeTrend(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function findTrendingSite(name) {
  const clean = normalizeTrend(name);
  const localSite = typeof websites !== "undefined"
    ? websites.find(site => normalizeTrend(site.name) === clean || normalizeTrend(site.name).includes(clean))
    : null;
  return localSite || trendingWebsites.find(site => normalizeTrend(site.name) === clean);
}

function getRecentTrendingQueries() {
  return readTrendingStore("wc_recent_searches_v2", [])
    .map(item => item.query)
    .filter(Boolean)
    .slice(0, 4);
}

function getTrendingPopularity() {
  const heroIntel = readTrendingStore("wc_hero_search_intel_v1", { searches: {}, categories: {} });
  const activity = readTrendingStore("wc_activity_v2", { searches: {}, categories: {}, sites: {} });
  return {
    searches: { ...(activity.searches || {}), ...(heroIntel.searches || {}) },
    categories: { ...(activity.categories || {}), ...(heroIntel.categories || {}) },
    sites: activity.sites || {}
  };
}

function scoreTrendingSite(site, popularity, index) {
  const nameKey = normalizeTrend(site.name);
  const categoryKey = normalizeTrend(site.category || "");
  return 70 - index +
    (popularity.sites?.[nameKey] || 0) * 9 +
    (popularity.categories?.[categoryKey] || 0) * 5 +
    (popularity.searches?.[nameKey] || 0) * 7;
}

function seededTrendValue(text, seed) {
  return normalizeTrend(text).split("").reduce((sum, char) => sum + char.charCodeAt(0), 0) + seed * 37;
}

function getTimeAwareTrendingBundles() {
  const hour = new Date().getHours();
  const priority = hour < 11
    ? ["Study", "Daily", "AI"]
    : hour < 17
      ? ["Career", "Developer", "AI"]
      : hour < 21
        ? ["Creator", "Shopping", "Daily"]
        : ["Entertainment", "AI", "Study"];

  return smartTrendingBundles
    .map((bundle, index) => ({
      ...bundle,
      score: (priority.includes(bundle.label) ? 90 : 30) - index +
        (seededTrendValue(bundle.label, trendingRefreshSeed) % 19)
    }))
    .sort((a, b) => b.score - a.score);
}

function buildCategoryKeywordItems(popularity) {
  const bundles = getTimeAwareTrendingBundles().slice(0, 4);
  return bundles.flatMap((bundle, bundleIndex) => {
    const offset = (trendingRefreshSeed + bundleIndex) % bundle.words.length;
    return [...bundle.words.slice(offset), ...bundle.words.slice(0, offset)]
      .slice(0, 3)
      .map((word, index) => {
        const site = findTrendingSite(word);
        return {
          name: word,
          url: site?.url || `https://www.google.com/search?q=${encodeURIComponent(word)}`,
          label: bundle.label,
          type: site ? "site" : "keyword",
          score: 125 - bundleIndex * 8 - index + (popularity.searches?.[normalizeTrend(word)] || 0) * 8
        };
      });
  });
}

function buildSmartTrendingItems() {
  const popularity = getTrendingPopularity();
  const recentItems = getRecentTrendingQueries().map((query, index) => ({
    name: query,
    url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
    label: "Recent",
    type: "recent",
    score: 170 - index
  }));

  const categoryItems = smartTrendingCategories.map((category, index) => {
    const keyScore = category.keywords.reduce((sum, key) => sum + (popularity.searches?.[normalizeTrend(key)] || 0), 0);
    return {
      name: category.name,
      url: category.href,
      query: category.query,
      label: "Smart Category",
      type: "category",
      score: 130 - index + keyScore * 6 + (popularity.categories?.[normalizeTrend(category.name)] || 0) * 5 +
        (seededTrendValue(category.name, trendingRefreshSeed) % 12)
    };
  });

  const siteSource = typeof websites !== "undefined" && websites.length ? websites : trendingWebsites;
  const siteItems = siteSource
    .slice(0, 260)
    .map((site, index) => ({
      name: site.name,
      url: site.url,
      label: site.category || "Popular",
      type: "site",
      score: scoreTrendingSite(site, popularity, index) + (seededTrendValue(site.name, trendingRefreshSeed) % 26)
    }))
    .sort((a, b) => b.score - a.score)
    .slice(trendingRefreshSeed % 5, (trendingRefreshSeed % 5) + 14);

  const seen = new Set();
  return [...recentItems, ...buildCategoryKeywordItems(popularity), ...categoryItems, ...siteItems]
    .filter(item => {
      const key = normalizeTrend(item.name);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .slice(0, window.matchMedia("(max-width: 560px)").matches ? 7 : 10);
}


// ===== RENDER =====
function renderItems(items = currentItems) {
  if (!container) return;

  currentItems = items;
  container.innerHTML = "";

  currentItems.forEach((item, index) => {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "trend-chip";
    chip.title = `${item.name} - ${item.label}`;

    if (index === currentIndex) chip.classList.add("active");

    const site = item.type === "site" ? findTrendingSite(item.name) : null;
    const icon = site?.url
      ? `<img src="${getFavicon(site.url)}" class="chip-icon" alt="">`
      : `<span class="chip-icon chip-letter">${item.name.charAt(0)}</span>`;

    chip.innerHTML = `
      ${icon}
      <span>${item.name}</span>
    `;

    chip.onclick = () => handleClick(item);
    container.appendChild(chip);
  });
}


// ===== ROTATION =====
function rotateItem() {
  if (!currentItems.length) return;
  currentIndex = (currentIndex + 1) % currentItems.length;
  renderItems();
}

function refreshSmartTrending() {
  trendingRefreshSeed += 1;
  currentItems = buildSmartTrendingItems();
  currentIndex = 0;
  renderItems();
}

function manualRefreshSmartTrending() {
  refreshSmartTrending();
  container?.classList.add("is-refreshing");
  trendingRefreshBtn?.classList.add("is-spinning");
  window.setTimeout(() => {
    container?.classList.remove("is-refreshing");
    trendingRefreshBtn?.classList.remove("is-spinning");
  }, 520);
}


// ===== CLICK =====
function handleClick(item) {
  const site = item.type === "site" || item.type === "keyword" ? findTrendingSite(item.name) : null;

  if (site) {
    if (typeof trackHeroSearchPopularity === "function") {
      trackHeroSearchPopularity(site.name, site);
    }
    if (typeof recordSmartVisit === "function") {
      recordSmartVisit({
        name: site.name,
        url: site.url,
        category: site.category || "Trending"
      });
    }
    window.location.href = site.url;
    return;
  }

  if (typeof trackHeroSearchPopularity === "function") {
    trackHeroSearchPopularity(item.query || item.name, { category: item.label || "Trending" });
  }

  if (item.type === "category" && item.url) {
    window.location.href = item.url;
    return;
  }

  if (item.type === "keyword" && item.url) {
    window.location.href = item.url;
    return;
  }

  if (searchInput) {
    searchInput.value = item.name;
    searchInput.focus();
    if (typeof showSuggestions === "function") showSuggestions();
  }
}


// ===== START =====
function startSystem() {
  clearInterval(itemInterval);
  clearInterval(setIntervalId);
  refreshSmartTrending();
  itemInterval = setInterval(rotateItem, 8000);
  setIntervalId = setInterval(refreshSmartTrending, 24000);
}


// ===== INIT =====
if (container) {
  startSystem();

  container.addEventListener("mouseenter", () => {
    clearInterval(itemInterval);
    clearInterval(setIntervalId);
  });

  container.addEventListener("mouseleave", startSystem);
  window.addEventListener("storage", refreshSmartTrending);
  searchInput?.addEventListener("input", () => requestAnimationFrame(refreshSmartTrending));
  trendingRefreshBtn?.addEventListener("click", manualRefreshSmartTrending);
  window.renderHeroTrending = refreshSmartTrending;
  window.refreshTrendingSuggestions = manualRefreshSmartTrending;
}







const trending = document.getElementById("trending");

// duplicate content for smooth infinite loop
if (trending) {
  trending.innerHTML += trending.innerHTML;
}








window.addEventListener("scroll", function () {
  const header = document.querySelector("header");
  if (!header) return;
  header.classList.toggle("scrolled", window.scrollY > 50);
});





function togglePassword(){
  const pass = document.getElementById("password");
  const icon = document.getElementById("eyeIcon");
  if (!pass || !icon) return;

  if(pass.type === "password"){
    pass.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    pass.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
}














