(function () {
  "use strict";

  const STORE = {
    favorites: "wc_platform_favorites_v1",
    recentSearches: "wc_recent_searches_v2"
  };

  const quickActions = [
    ["AI Tools", "ai.html", "fas fa-wand-magic-sparkles"],
    ["Jobs", "jobs.html", "fas fa-briefcase"],
    ["Education", "education.html", "fas fa-graduation-cap"],
    ["Government", "govt.html", "fas fa-landmark"],
    ["Coding", "coding.html", "fas fa-code"],
    ["Finance", "finance.html", "fas fa-chart-line"],
    ["Shopping", "shopping.html", "fas fa-bag-shopping"],
    ["News", "news.html", "fas fa-newspaper"]
  ];

  const categoryPills = [
    ["AI", "ai.html"], ["Jobs", "jobs.html"], ["Education", "education.html"], ["Govt", "govt.html"],
    ["Coding", "coding.html"], ["Finance", "finance.html"], ["Shopping", "shopping.html"], ["News", "news.html"],
    ["Developer", "developer.html"], ["Tools", "tools.html"], ["Health", "health.html"], ["More", "allCategoriesHub"]
  ];

  const popularQueries = ["AI Tools", "Jobs", "Scholarships", "Python", "Govt Services", "Finance", "News", "Shopping"];
  const corrections = {
    "chat gpt": "ChatGPT",
    chatgptt: "ChatGPT",
    pyhton: "Python",
    goverment: "Government",
    govenment: "Government",
    shcolarship: "Scholarships",
    scholorship: "Scholarships",
    jbs: "Jobs",
    eduction: "Education",
    finace: "Finance",
    youtub: "YouTube",
    instgram: "Instagram"
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  function read(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function safeText(value) {
    return String(value || "").replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[char]));
  }

  function normalize(value) {
    return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }

  function allSites() {
    const map = new Map();
    const list = typeof websites !== "undefined" && Array.isArray(websites)
      ? websites
      : (Array.isArray(window.websites) ? window.websites : []);
    list.forEach(site => {
      if (!site?.name || !site?.url) return;
      map.set(site.url, {
        name: site.name,
        url: site.url,
        category: site.category || "Website",
        description: site.description || `${site.name} is listed in ${site.category || "WebConnect"}.`,
        badges: inferBadges(site)
      });
    });
    return [...map.values()];
  }

  function inferBadges(site) {
    const text = normalize(`${site.name} ${site.category} ${site.url}`);
    const badges = [];
    if (/google|github|openai|microsoft|coursera|wikipedia|linkedin|gov|edu|nptel|swayam/.test(text)) badges.push("Verified");
    if (/chatgpt|ai|jobs|youtube|amazon|github|news|course|shopping|finance/.test(text)) badges.push("Trending");
    if (/chatgpt|github|coursera|linkedin|canva|figma|digilocker|naukri/.test(text)) badges.push("Featured");
    return badges.length ? badges : ["Verified"];
  }

  function countByCategory() {
    const counts = {};
    allSites().forEach(site => {
      const key = normalize(site.category);
      counts[key] = (counts[key] || 0) + 1;
    });
    return counts;
  }

  function favoriteId(site) {
    return site.url || site.name;
  }

  function favorites() {
    return read(STORE.favorites, []);
  }

  function isFavorite(site) {
    const id = favoriteId(site);
    return favorites().some(item => favoriteId(item) === id);
  }

  function toggleFavoriteSite(site) {
    const list = favorites();
    const id = favoriteId(site);
    const next = isFavorite(site)
      ? list.filter(item => favoriteId(item) !== id)
      : [{ name: site.name, url: site.url, category: site.category || "Website", at: Date.now() }, ...list].slice(0, 30);
    write(STORE.favorites, next);
    renderFavoritesSection();
    refreshFavoriteButtons();
  }

  function trackRecentSearch(query) {
    const clean = String(query || "").trim();
    if (!clean) return;
    const list = read(STORE.recentSearches, []);
    const next = [{ query: clean, at: Date.now() }, ...list.filter(item => normalize(item.query) !== normalize(clean))].slice(0, 12);
    write(STORE.recentSearches, next);
  }

  function didYouMean(query) {
    const clean = normalize(query);
    if (corrections[clean]) return corrections[clean];
    if (clean.length < 4) return "";
    const candidate = popularQueries.find(item => distance(normalize(item), clean) <= 2);
    return candidate || "";
  }

  function distance(a, b) {
    const dp = Array.from({ length: b.length + 1 }, (_, i) => [i]);
    for (let j = 0; j <= a.length; j++) dp[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        dp[i][j] = b[i - 1] === a[j - 1] ? dp[i - 1][j - 1] : Math.min(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j]) + 1;
      }
    }
    return dp[b.length][a.length];
  }

  function highlight(text, query) {
    const source = safeText(text);
    const q = String(query || "").trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (!q) return source;
    return source.replace(new RegExp(`(${q})`, "ig"), "<mark>$1</mark>");
  }

  function scoreSite(site, query, filter) {
    const q = normalize(query);
    const haystack = normalize(`${site.name} ${site.category} ${site.description} ${(site.badges || []).join(" ")}`);
    let score = 0;
    if (!q) score += 12;
    if (normalize(site.name) === q) score += 400;
    if (normalize(site.name).startsWith(q)) score += 220;
    if (haystack.includes(q)) score += 120;
    q.split(" ").filter(Boolean).forEach(word => {
      if (haystack.includes(word)) score += 28;
    });
    if (filter !== "all") {
      if (filter === "verified" && !site.badges.includes("Verified")) return -1;
      if (filter === "featured" && !site.badges.includes("Featured")) return -1;
      if (filter === "trending" && !site.badges.includes("Trending")) return -1;
      if (filter === "popular" && !/ai|jobs|education|shopping|news|finance/i.test(site.category)) return -1;
      if (!["verified", "featured", "trending", "popular", "newest"].includes(filter) && normalize(site.category) !== normalize(filter)) return -1;
    }
    if (site.badges.includes("Featured")) score += 22;
    if (site.badges.includes("Verified")) score += 14;
    if (site.badges.includes("Trending")) score += 12;
    if (filter === "newest") score += Math.max(0, 80 - site.name.length);
    return score;
  }

  function searchResults(query, filter = "all", limit = 12) {
    return allSites()
      .map(site => ({ ...site, score: scoreSite(site, query, filter) }))
      .filter(site => site.score >= 0)
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      .slice(0, limit);
  }

  function ensureLoader() {
    if ($("#wcPageLoader")) return;
    const loader = document.createElement("div");
    loader.id = "wcPageLoader";
    loader.innerHTML = `
      <div class="wc-loader-card">
        <img src="logo.svg" alt="">
        <strong>WebConnect 2.0</strong>
        <span>Preparing your smart directory</span>
        <div class="wc-loader-track"><i></i></div>
        <small id="wcLoaderProgress">0%</small>
      </div>
    `;
    document.body.prepend(loader);
    let progress = 0;
    const timer = window.setInterval(() => {
      progress = Math.min(progress + Math.ceil(Math.random() * 18), 94);
      $("#wcLoaderProgress") && ($("#wcLoaderProgress").textContent = `${progress}%`);
      loader.style.setProperty("--progress", `${progress}%`);
    }, 90);
    window.addEventListener("load", () => {
      window.clearInterval(timer);
      loader.style.setProperty("--progress", "100%");
      $("#wcLoaderProgress") && ($("#wcLoaderProgress").textContent = "100%");
      window.setTimeout(() => {
        loader.classList.add("is-hidden");
        document.body.classList.add("wc-pro-ready");
      }, 260);
    }, { once: true });
  }

  function ensureQuickActions() {
    if ($("#wcQuickActions")) return;
    const dock = document.createElement("aside");
    dock.id = "wcQuickActions";
    dock.className = "wc-quick-actions is-closed";
    dock.innerHTML = `
      <button class="wc-quick-toggle" type="button" aria-expanded="false" aria-label="Open quick actions">
        <i class="fas fa-bolt"></i><span>Quick Actions</span>
      </button>
      <div class="wc-quick-panel">
        ${quickActions.map(([label, href, icon]) => `<a href="${href}"><i class="${icon}"></i><span>${label}</span></a>`).join("")}
      </div>
    `;
    document.body.appendChild(dock);
    $(".wc-quick-toggle", dock).addEventListener("click", () => {
      const open = dock.classList.toggle("is-open");
      dock.classList.toggle("is-closed", !open);
      $(".wc-quick-toggle", dock).setAttribute("aria-expanded", String(open));
    });
  }

  function ensureBackToTop() {
    let btn = $("#wcBackToTop");
    if (!btn) {
      btn = document.createElement("button");
      btn.id = "wcBackToTop";
      btn.type = "button";
      btn.setAttribute("aria-label", "Back to top");
      btn.innerHTML = `<i class="fas fa-arrow-up"></i>`;
      document.body.appendChild(btn);
      btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
    }
    const update = () => btn.classList.toggle("is-visible", window.scrollY > 420);
    update();
    window.addEventListener("scroll", update, { passive: true });
  }

  function ensureHeroPills() {
    if ($("#wcHeroCategoryPills")) return;
    const target = $(".search-wrapper") || $(".trending");
    if (!target) return;
    const pills = document.createElement("nav");
    pills.id = "wcHeroCategoryPills";
    pills.className = "wc-hero-pills";
    pills.setAttribute("aria-label", "Category shortcuts");
    pills.innerHTML = categoryPills.map(([label, href]) => {
      const isAnchor = !href.endsWith(".html");
      return `<button type="button" data-${isAnchor ? "scroll" : "href"}="${href}">${label}</button>`;
    }).join("");
    target.insertAdjacentElement("afterend", pills);
    pills.addEventListener("click", event => {
      const button = event.target.closest("button");
      if (!button) return;
      if (button.dataset.href) window.location.href = button.dataset.href;
      if (button.dataset.scroll) document.getElementById(button.dataset.scroll)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  function ensureFavoritesSection() {
    if ($("#wcFavoritesSection")) return;
    const section = document.createElement("section");
    section.id = "wcFavoritesSection";
    section.className = "wc-favorites-section reveal-on-scroll";
    section.innerHTML = `
      <div class="section-heading compact">
        <span class="section-kicker">Favorites</span>
        <h2>Your Saved Websites</h2>
        <p>Bookmark useful websites from search and quick previews. Favorites stay saved in this browser.</p>
      </div>
      <div id="wcFavoritesGrid" class="wc-favorites-grid"></div>
    `;
    const categories = $(".categories");
    if (categories) categories.insertAdjacentElement("beforebegin", section);
    else document.querySelector(".hero")?.insertAdjacentElement("afterend", section);
    renderFavoritesSection();
  }

  function renderFavoritesSection() {
    const grid = $("#wcFavoritesGrid");
    if (!grid) return;
    const list = favorites();
    grid.innerHTML = list.length
      ? list.map(siteCard).join("")
      : `<div class="wc-empty-state"><i class="fas fa-bookmark"></i><strong>No favorites yet</strong><span>Search for a website and tap the star to save it here.</span></div>`;
  }

  function siteCard(site) {
    return `
      <article class="wc-site-card" data-preview-url="${safeText(site.url)}">
        <div><strong>${safeText(site.name)}</strong><small>${safeText(site.category || "Website")}</small></div>
        <div class="wc-card-badges"><span>Verified</span></div>
        <div class="wc-site-actions">
          <button type="button" data-fav-url="${safeText(site.url)}" aria-label="Toggle favorite"><i class="fas fa-star"></i></button>
          <a href="${safeText(site.url)}">Open</a>
        </div>
      </article>
    `;
  }

  function enhanceCategoryStats() {
    const counts = countByCategory();
    $$(".categories .card, .home-more-card").forEach(card => {
      const titleNode = $(".wc-card-title", card);
      const label = titleNode?.textContent || card.textContent.trim();
      if (!label) return;
      const href = card.getAttribute("href") || "";
      const key = normalize(label.replace(/more|all/i, "") || href.replace(".html", ""));
      const hrefKey = normalize(href.replace(".html", ""));
      const count = counts[key] || counts[hrefKey] || inferCategoryCount(label);
      card.dataset.siteCount = `${count}+ Sites`;
      if (!card.querySelector(".wc-stat-badge")) {
        const badge = document.createElement("span");
        badge.className = "wc-stat-badge";
        badge.textContent = `${count}+ Sites`;
        card.appendChild(badge);
      } else {
        card.querySelector(".wc-stat-badge").textContent = `${count}+ Sites`;
      }
    });
  }

  function inferCategoryCount(label) {
    if (/ai|education|all|developer|coding|tools/i.test(label)) return 100;
    if (/jobs|govt|finance|shopping|news/i.test(label)) return 75;
    return 40;
  }

  function enhanceHeroCounters() {
    const counters = $$(".hero-proof strong");
    counters.forEach(counter => {
      const raw = counter.textContent;
      const value = parseInt(raw.replace(/\D/g, ""), 10);
      if (!value || counter.dataset.counted) return;
      counter.dataset.counted = "true";
      let current = 0;
      const step = Math.max(1, Math.ceil(value / 32));
      const timer = window.setInterval(() => {
        current = Math.min(value, current + step);
        counter.textContent = raw.includes("+") ? `${current}+` : String(current);
        if (current >= value) {
          counter.textContent = raw;
          window.clearInterval(timer);
        }
      }, 32);
    });
  }

  function enhanceSearch() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    if (!input || !box) return;
    if (!$("#wcSearchFilters")) {
      const filters = document.createElement("div");
      filters.id = "wcSearchFilters";
      filters.className = "wc-search-filters";
      filters.innerHTML = ["all", "popular", "featured", "verified", "trending", "AI", "Jobs", "Education", "Finance"].map((filter, index) =>
        `<button type="button" class="${index === 0 ? "active" : ""}" data-filter="${filter}">${filter}</button>`
      ).join("");
      box.insertAdjacentElement("beforebegin", filters);
      filters.addEventListener("click", event => {
        const button = event.target.closest("button");
        if (!button) return;
        $$("#wcSearchFilters button").forEach(item => item.classList.remove("active"));
        button.classList.add("active");
        renderSearchSuggestions();
      });
    }

    window.showSuggestions = renderSearchSuggestions;
    input.addEventListener("input", renderSearchSuggestions);
    input.addEventListener("focus", renderSearchSuggestions);
  }

  function renderSearchSuggestions() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    if (!input || !box) return;
    const query = input.value.trim();
    const filter = $("#wcSearchFilters .active")?.dataset.filter || "all";
    const recent = read(STORE.recentSearches, []).slice(0, 4);
    const results = searchResults(query || popularQueries[0], filter, 9);
    const mean = query ? didYouMean(query) : "";

    if (!query) {
      box.innerHTML = `
        <div class="wc-suggestion-section"><strong>Recent searches</strong>${recent.length ? recent.map(item => `<button type="button" data-query="${safeText(item.query)}"><i class="fas fa-clock"></i>${safeText(item.query)}</button>`).join("") : `<span>No recent searches yet</span>`}</div>
        <div class="wc-suggestion-section"><strong>Popular searches</strong>${popularQueries.slice(0, 6).map(item => `<button type="button" data-query="${safeText(item)}"><i class="fas fa-fire"></i>${safeText(item)}</button>`).join("")}</div>
      `;
      box.style.display = "grid";
      wireSuggestionClicks();
      return;
    }

    if (!results.length) {
      box.innerHTML = `
        <div class="wc-empty-search">
          <i class="fas fa-magnifying-glass"></i>
          <strong>No exact matches found</strong>
          <span>Try AI Tools, Jobs, Education, Government, Coding, Finance, Shopping, or News.</span>
          <div>${popularQueries.slice(0, 4).map(item => `<button type="button" data-query="${safeText(item)}">${safeText(item)}</button>`).join("")}</div>
        </div>
      `;
      box.style.display = "grid";
      wireSuggestionClicks();
      return;
    }

    box.innerHTML = `
      ${mean && normalize(mean) !== normalize(query) ? `<button class="wc-did-you-mean" type="button" data-query="${safeText(mean)}">Did you mean <b>${safeText(mean)}</b>?</button>` : ""}
      ${results.map(site => `
        <button class="suggestion-item wc-rich-suggestion" type="button" data-open="${safeText(site.url)}">
          <span class="suggestion-icon"><i class="fas fa-globe"></i></span>
          <span class="suggestion-copy">
            <strong>${highlight(site.name, query)}</strong>
            <small>${safeText(site.category)} · ${safeText(site.description)}</small>
            <span class="wc-result-badges">${site.badges.map(badge => `<em>${safeText(badge)}</em>`).join("")}</span>
          </span>
          <span class="suggestion-action">Open</span>
          <span class="suggestion-fav" data-fav="${safeText(site.url)}">${isFavorite(site) ? "★" : "☆"}</span>
        </button>
      `).join("")}
    `;
    box.style.display = "grid";
    wireSuggestionClicks();
  }

  function wireSuggestionClicks() {
    const input = $("#searchInput");
    const box = $("#suggestionBox");
    box.onclick = event => {
      const fav = event.target.closest("[data-fav]");
      if (fav) {
        event.preventDefault();
        event.stopPropagation();
        const site = allSites().find(item => item.url === fav.dataset.fav);
        if (site) toggleFavoriteSite(site);
        fav.textContent = site && isFavorite(site) ? "★" : "☆";
        return;
      }
      const query = event.target.closest("[data-query]")?.dataset.query;
      if (query && input) {
        input.value = query;
        input.focus();
        renderSearchSuggestions();
        return;
      }
      const url = event.target.closest("[data-open]")?.dataset.open;
      if (url) {
        trackRecentSearch(input?.value || url);
        window.location.href = url;
      }
    };
  }

  function refreshFavoriteButtons() {
    $$("[data-fav-url]").forEach(button => {
      const site = allSites().find(item => item.url === button.dataset.favUrl) || { url: button.dataset.favUrl };
      button.classList.toggle("is-saved", isFavorite(site));
    });
  }

  function ensurePreview() {
    if ($("#wcPreviewBubble")) return;
    const bubble = document.createElement("div");
    bubble.id = "wcPreviewBubble";
    bubble.className = "wc-preview-bubble";
    document.body.appendChild(bubble);
    document.addEventListener("mouseover", event => {
      const link = event.target.closest("a[href], [data-preview-url]");
      if (!link) return;
      const url = link.dataset.previewUrl || link.getAttribute("href");
      if (!url || url.startsWith("#") || url.startsWith("mailto:")) return;
      const site = allSites().find(item => item.url === url || item.url.endsWith(url)) || {
        name: link.textContent.trim() || url,
        url,
        category: url.endsWith(".html") ? "WebConnect Page" : "Website",
        description: "Open this resource from WebConnect."
      };
      bubble.innerHTML = `<strong>${safeText(site.name)}</strong><span>${safeText(site.category)}</span><small>${safeText(site.description)}</small>`;
      bubble.classList.add("is-visible");
    });
    document.addEventListener("mousemove", event => {
      bubble.style.left = `${Math.min(event.clientX + 16, window.innerWidth - 290)}px`;
      bubble.style.top = `${Math.min(event.clientY + 16, window.innerHeight - 150)}px`;
    });
    document.addEventListener("mouseout", event => {
      if (event.target.closest("a[href], [data-preview-url]")) bubble.classList.remove("is-visible");
    });
  }

  function enhanceDailyHub() {
    const hub = $(".wc-product-hub");
    if (!hub || $("#wcDailyUpgrade")) return;
    const sites = searchResults("AI jobs education finance", "all", 6);
    const panel = document.createElement("section");
    panel.id = "wcDailyUpgrade";
    panel.className = "wc-daily-upgrade";
    panel.innerHTML = `
      <div><strong>Today's Featured Websites</strong><span>Auto-updated recommendations from popular and verified resources.</span></div>
      <div class="wc-daily-featured">${sites.slice(0, 4).map(site => `<a href="${safeText(site.url)}"><b>${safeText(site.name)}</b><small>${safeText(site.category)}</small></a>`).join("")}</div>
    `;
    hub.appendChild(panel);
  }

  function improveFooter() {
    const footer = $(".footer");
    const container = $(".footer-container", footer);
    if (!footer || !container) return;
    container.classList.add("wc-footer-polished");
    const ensureCol = (className, title, links) => {
      if ($(`.${className}`, container)) return;
      const col = document.createElement("div");
      col.className = `footer-col ${className}`;
      col.innerHTML = `<h4>${title}</h4>${links.map(([label, href]) => `<a href="${href}">${label}</a>`).join("")}`;
      container.appendChild(col);
    };
    ensureCol("wc-footer-quick-links", "Quick Links", [["Home", "index.html"], ["Features", "features.html"], ["About", "about.html"], ["Contact", "contact.html"]]);
    ensureCol("wc-footer-popular-categories", "Popular Categories", [["AI Tools", "ai.html"], ["Jobs", "jobs.html"], ["Education", "education.html"], ["Government", "govt.html"], ["Finance", "finance.html"]]);
  }

  function hardenChatbot() {
    const chat = $("#chat-container");
    if (!chat) return;
    chat.classList.remove("wc-chat-clean");
    const messages = $("#chat-messages");
    if (messages && !messages.dataset.cleanObserver) {
      messages.dataset.cleanObserver = "true";
      const observer = new MutationObserver(() => {
        messages.scrollTop = messages.scrollHeight;
      });
      observer.observe(messages, { childList: true, subtree: true });
    }
  }

  function performancePolish() {
    $$("img").forEach(img => {
      img.loading = "lazy";
      img.decoding = "async";
    });
    document.documentElement.classList.add("wc-universal-theme");
  }

  function smartErrorHandling() {
    document.addEventListener("click", event => {
      const favButton = event.target.closest("[data-fav-url]");
      if (favButton) {
        event.preventDefault();
        const site = allSites().find(item => item.url === favButton.dataset.favUrl) || {
          name: favButton.closest(".wc-site-card")?.querySelector("strong")?.textContent || "Saved Website",
          url: favButton.dataset.favUrl,
          category: "Website"
        };
        toggleFavoriteSite(site);
        return;
      }

      const link = event.target.closest("a[href]");
      if (!link) return;
      const href = link.getAttribute("href");
      if (!href || href.startsWith("http") || href.startsWith("#") || href.startsWith("mailto:")) return;
      if (!href.endsWith(".html") && !href.includes("/")) return;
      window.setTimeout(() => {
        try { localStorage.setItem("wc_last_navigation_attempt", href); } catch {}
      }, 0);
    });
  }

  function init() {
    ensureLoader();
    // Kept disabled for a cleaner, less crowded home experience.
    // Extra floating/navigation widgets are disabled to keep the homepage focused.
    enhanceSearch();
    enhanceCategoryStats();
    enhanceHeroCounters();
    // Hover preview overlays add noise on category cards, so they stay disabled.
    improveFooter();
    hardenChatbot();
    performancePolish();
    smartErrorHandling();
    window.setTimeout(() => {
      enhanceCategoryStats();
    }, 550);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
