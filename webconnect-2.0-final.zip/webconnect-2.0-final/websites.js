const websites = [

  // Social Media
  { name: "YouTube", url: "https://www.youtube.com", category: "social" },
  { name: "Instagram", url: "https://www.instagram.com", category: "social" },
  { name: "Facebook", url: "https://www.facebook.com", category: "social" },
  { name: "Twitter", url: "https://www.twitter.com", category: "social" },
  { name: "LinkedIn", url: "https://www.linkedin.com", category: "social" },

  // Shopping
  { name: "Amazon", url: "https://www.amazon.in", category: "shopping" },
  { name: "Flipkart", url: "https://www.flipkart.com", category: "shopping" },
  { name: "Myntra", url: "https://www.myntra.com", category: "shopping" },

  // Education
  { name: "Coursera", url: "https://www.coursera.org", category: "education" },
  { name: "Udemy", url: "https://www.udemy.com", category: "education" },
  { name: "Khan Academy", url: "https://www.khanacademy.org", category: "education" },

  // AI Tools
  { name: "ChatGPT", url: "https://chat.openai.com", category: "ai" },
  { name: "Gemini", url: "https://gemini.google.com", category: "ai" },
  { name: "Midjourney", url: "https://www.midjourney.com", category: "ai" },

  // News
  { name: "BBC", url: "https://www.bbc.com", category: "news" },
  { name: "NDTV", url: "https://www.ndtv.com", category: "news" },
  { name: "Times of India", url: "https://timesofindia.indiatimes.com", category: "news" }

];